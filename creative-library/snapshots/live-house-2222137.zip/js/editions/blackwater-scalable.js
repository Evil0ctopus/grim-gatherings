// Generated from the Blackwater master; node tools/author-blackwater.mjs.
export default {
  "3": {
    "schemaVersion": 2,
    "fixedPlayerCount": 3,
    "discloseKiller": false,
    "clueRouting": "rotating",
    "edition": {
      "family": "blackwater-scalable",
      "id": "blackwater-scalable-3-players",
      "playerCount": 3,
      "revision": 1
    },
    "title": "The Barber of Blackwater Row",
    "atmosphere": "victorian",
    "setting": "Blackwater Row, a riverside town of workshops, narrow lanes and gaslit streets in the late nineteenth century.",
    "intro": "Evening settles over Blackwater Row. Three neighbors help the town investigator compare the supplied accounts: Xander Hale, the woodworker; Marla Quinn, the baker's assistant; and Jasper Crowe, the tavern musician. The host reads every recorded witness account before the players respond. Other named people remain in the evidence even when they are not playable. Discuss only the chapter just heard; nobody invents a history, witnesses a new discovery or improvises a private part.",
    "hiddenThread": "Receipt 47 recurs in every victim's disturbed records and finally names the Mayor's old imprisonment order against Benjamin Barker.",
    "coverageRepeatNote": "The trio covers all six directed pairs in the first two rounds. Later repeats add released evidence or explicitly correct an unsupported earlier inference. Each supplemental reader targets every other selected character before repeating, never in consecutive rounds. Separate singleton readings preserve the master loop and evidence timing.",
    "specialMechanics": [
      "Receipt 47 ledger: each murder surfaces another record indexed under receipt 47 (delivery log, tavern scrap, student-record index, night-route page). Compare them across rounds; the Mayor's signed order in Round 7 finally connects the series to the old case."
    ],
    "victim": {
      "name": "Elias Brim",
      "description": "The town baker, known for dependable bread deliveries and careful records."
    },
    "rounds": [
      {
        "title": "Round 1 - The Baker's Murder",
        "narration": "At dawn, delivery porter Finn Moss finds Elias Brim behind his bakery with his throat slashed. The investigator reports one clean, precise cut; the death happened off-screen. Elias supplied nearly every doorstep and recorded deliveries and closing chores in separate books. Finn calls night watchwoman Nell Reed before anyone enters the yard. She records a chain of flour prints from the back door to the wet cobbles. Each right print has a crescent-shaped gap at the heel; the cobbles preserve nothing beyond it. A page is torn from an older delivery log. Its surviving edge carries the date and part of receipt 47, but not a customer name or the purpose of the entry. The closing-duty sheet is intact and is kept for later comparison. These are the findings at this scene, not an identification of the killer. The investigator has collected four separate accounts about the neighbors.  Hear all four before discussing which details establish access and which merely raise suspicion.\n\nThe investigator reads the supporting witness accounts before calling on the selected readers:\n\nWitness background for Marla Quinn: Nell Reed saw Marla Quinn leave the bakery back door at nine, carrying her red-handled scrubbing brush. Nell recognized the brass buckle and crescent-shaped repair in the right heel of her work boots because cobbler Della March had shown her that repair at collection yesterday. Flour was packed into the repaired heel. The shape resembles the yard prints recorded this morning. This ties the boots to bakery work and the doorway, but does not date when each print was made. The closing-duty sheet has not yet been checked against the sighting.\n\nWitness background for Jasper Crowe: Finn Moss saw Jasper Crowe waiting behind the bakery at half past nine, with a blue-strapped instrument case propped against the wall. Finn recognized the musician from the tavern and the case from carrying it after last week's performance. A pale streak ran across its lower corner where it touched a flour sack outside the door. Finn heard him ask Elias for a promised parcel, but did not see a parcel handed over or hear what it contained. Finn left for the delivery cart; he did not witness the death or the musician's departure.\n\nWitness background for Lydia Vance: Della March saw Lydia Vance arguing with Elias at the bakery front counter that morning. She recognized the teacher from collecting her granddaughter from school and saw the same green lesson folder under her arm. Della heard the teacher ask why a bread bill included a household's personal history. Elias folded a paper and refused to answer. The teacher left a chalky thumb mark on the counter when she leaned forward. Della identifies the person and the topic, but heard no threat and never saw the contents of the folded paper.\n\nWitness background for Xander Hale: Della March delivered a wooden chair to Xander Hale's workshop last week and saw Elias at the open door. She recognized both men from their regular work at her market stall. Elias refused to enter and said, \"I will not bring that old receipt here again.\" The woodworker stopped sanding, gripped the chair rail and asked which book Elias meant. Della saw fresh amber shellac on his apron beside the repair cloth, but no weapon. She can identify the reaction and the receipt dispute; she cannot identify the old transaction or turn that reaction into proof of murder.\n\nThe host reads the original neighbors' recorded responses:\nXander Hale's recorded response: \"I heard Nell saw Marla Quinn leave the bakery's back door at nine with her red-handled brush. Her repaired, flour-packed heel resembles those prints. I still need their timing checked.\"\nMarla Quinn's recorded response: \"I heard Finn saw Jasper Crowe behind the bakery at nine-thirty with his blue-strapped case. A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave.\"\nJasper Crowe's recorded response: \"I heard Della saw Lydia Vance argue with Elias that morning, her green lesson folder tucked under her arm. A bread bill held family history. I wonder why he folded that paper.\"\nLydia Vance's recorded response: \"I heard Della saw Elias refuse to enter Xander Hale's workshop over an old receipt. He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon.\"\n\nThe supplied witness accounts support these comparisons:\nNell Reed recorded flour prints with a crescent gap in the right heel.\nDella March recognized the repaired boot from its collection yesterday.\nFinn Moss found Elias and called Nell before anyone entered the yard.\nAda Bell has not supplied a tavern account at this stage.\nOwen Bell has not supplied a classroom account at this stage.\nEdith Shaw has not supplied an office account at this stage.\nTown Investigator reported one precise cut at the bakery.\nDella recognized Lydia through collecting Della's Granddaughter from school.",
        "publicText": "Elias Brim: throat slashed with one precise cut. Finn Moss found the body; Nell Reed recorded flour prints with a crescent gap in the right heel. An old delivery-log page is torn; only receipt 47 survives at its edge. The closing-duty sheet is intact.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "At dawn, delivery porter Finn Moss finds Elias Brim behind his bakery with his throat slashed.",
          "The investigator reports one clean, precise cut; the death happened off-screen.",
          "Elias supplied nearly every doorstep and recorded deliveries and closing chores in separate books."
        ],
        "readingGroups": [
          [
            "xander",
            "marla",
            "jasper"
          ]
        ],
        "chain": [
          "xander",
          "marla",
          "jasper"
        ],
        "coverageRepeat": false
      },
      {
        "title": "Round 2 - The Barkeep's Murder",
        "narration": "The next morning, cleaner Ada Bell finds Ronan Pike slumped over his tavern counter with his throat slashed. The investigator records the same precise cut as at the bakery. Ronan kept accounts of debts and stayed late for private appointments. Ada does not touch the mug beside him; Nell Reed records that it has been wiped and has no usable fingerprints. A thin amber smear remains beneath its handle. No owner has been established for the mug or the smear. Beneath Ronan's account book lies a scrap bearing receipt 47 and four lines of dates. No names or explanation survive on the scrap. The matching number links two sets of records, but does not identify their subject. Ronan's service tally and appointment book are preserved separately so that the last drink served will not be confused with the last visitor admitted. Four witness accounts are ready.  Listen for who saw an object, how they identified its owner and whether their timing actually reaches the death.\n\nThe investigator reads the supporting witness accounts before calling on the selected readers:\n\nWitness background for Jasper Crowe: Ada Bell saw Jasper Crowe put his instrument case on Ronan's counter at ten and leave after the last public drink was served. She recognized the case by its repaired blue strap, which she had sewn herself. He uses amber rosin on his bow; Ada collected a flake from the spot where the case rested. Its color resembles the smear beneath the wiped mug, but color alone cannot establish that they are the same material. Ronan locked the public door afterward; Ada did not watch the side entrance or the later appointments.\n\nWitness background for Lydia Vance: Ada Bell heard Lydia Vance tell Ronan at eight, \"Those are dangerous notes; people did not give you permission to record their families.\" Ada recognized the green lesson folder under the teacher's arm from her school-cleaning rounds. The teacher tapped Ronan's account book, leaving a white powder trace on its dark cover. Ada collected it as a possible chalk transfer, not a laboratory identification. The warning concerns records, but Ada saw no page removed. The teacher walked out through the public door; Ada could not observe who returned later.\n\nWitness background for Xander Hale: Ronan's repair invoice records Xander Hale replacing the tavern shelf last week. Ada Bell identified him from the signed invoice and saw him open a leather tool sleeve stamped with the same workshop address. Inside were sharpening stones Ronan called \"too fine for woodworking\": one was much narrower and smoother than the broad stone used on the shelf chisel. Ada saw him wipe the sleeve with an amber shellac-stained cloth from his repair kit. That establishes ownership of the stones and a second possible source of amber residue; it does not prove who handled the wiped mug on the night of the murder.\n\nWitness background for Marla Quinn: Della March heard Marla Quinn dispute an unpaid flour bill with Ronan outside the tavern at seven. She recognized the baker's assistant by the stamped delivery basket she was carrying. Ronan held a bill with a torn lower corner; the assistant produced a coin receipt, but Della was too far away to compare its amount. She saw the assistant leave with the basket toward the bakery. The argument supplies a specific grievance and an observed departure, not proof of payment or a witnessed return to the counter where Ronan died.\n\nThe host reads the original neighbors' recorded responses:\nXander Hale's recorded response: \"I heard Ada saw Jasper Crowe's blue-strapped case on Ronan's counter at ten. His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors.\"\nMarla Quinn's recorded response: \"I heard Ada heard Lydia Vance warn Ronan about recording families at eight. She touched his book, leaving possible chalk. I can't prove a removed page or a later return.\"\nJasper Crowe's recorded response: \"I read Xander Hale's shelf invoice; Ada saw fine sharpening stones in his address-stamped sleeve. His repair cloth held amber shellac. I see another possible smear source, not proof he touched that mug.\"\nLydia Vance's recorded response: \"I heard Della heard Marla Quinn dispute Ronan's flour bill at seven. She showed a receipt and left toward the bakery. I can't confirm payment or a later return.\"\n\nThe supplied witness accounts support these comparisons:\nNell Reed recorded a wiped mug without usable fingerprints.\nDella March heard Marla dispute the flour bill and leave toward the bakery.\nFinn Moss did not witness the bakery death or the musician leaving.\nAda Bell found Ronan and left the mug untouched.\nOwen Bell has not supplied a classroom account at this stage.\nEdith Shaw has not supplied an office account at this stage.\nTown Investigator reported the same precise cut at the tavern.\nDella's school collection of Della's Granddaughter explains her recognition of Lydia.",
        "publicText": "Ronan Pike: throat slashed with the same precise cut. Ada Bell found him. A wiped mug has no usable fingerprints and an unidentified amber smear beneath its handle. A dated scrap bears receipt 47 but no names. Service and appointment records are preserved.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "The next morning, cleaner Ada Bell finds Ronan Pike slumped over his tavern counter with his throat slashed.",
          "The investigator records the same precise cut as at the bakery.",
          "Ronan kept accounts of debts and stayed late for private appointments."
        ],
        "readingGroups": [
          [
            "xander",
            "jasper",
            "marla"
          ]
        ],
        "chain": [
          "xander",
          "jasper",
          "marla"
        ],
        "coverageRepeat": false
      },
      {
        "title": "Round 3 - The Schoolteacher's Murder",
        "narration": "Before sunrise, caretaker Owen Bell finds senior teacher Harper Wren in her classroom with her throat slashed, the same precise cut again. Harper taught most of the town's children and kept family records as carefully as lesson plans. Owen locks the room and fetches Nell Reed. She records a broad chalk smear across the desk and a narrow drag line through it, running from the student-record book toward its open drawer. A page is missing from that book. Its remaining index cites receipt 47; a margin note says, \"Copy kept with the original order.\" Neither the order's owner nor its location is recorded here. Owen also hands over the fundraiser attendance sheet and Harper's lesson diary, both intact. Three disturbed records now share a number. That is a link worth following, not yet an explanation.  Compare observed visits with the traces on the desk, and keep the identity of any missing document separate from guesses about it.\n\nThe investigator reads the supporting witness accounts before calling on the selected readers:\n\nWitness background for Lydia Vance: Owen Bell saw Lydia Vance enter Harper's classroom at six carrying her green lesson folder. He recognized her name written inside its cover when she left it beside the register. A broad chalk mark on the folder's edge matches the height of the smeared desk; Owen had watched her lean it there while discussing pupil privacy. Her warning was, \"A family record should not become a weapon.\" This explains regular access and a possible source of chalk transfer, but Owen left at seven and cannot account for the classroom overnight.\n\nWitness background for Xander Hale: Owen Bell recalls Harper pointing out Xander Hale's narrow whetstone while the woodworker repaired her drawer rail last Tuesday. Owen saw the stone in a leather sleeve stamped with the workshop's address; he checked that address on the repair invoice. Harper said he \"used to work with blades in another trade\" but did not name it. Owen also saw fresh blue chalk on the woodworker's cuff after measuring the rail with Harper's chalk line. That gives an ordinary source for the cuff mark, not an explanation of the missing page or the earlier blade skills.\n\nWitness background for Marla Quinn: Owen Bell signed for Marla Quinn's six-o'clock bread delivery to Harper on the morning before the death. He recognized the baker's stamped basket and the repaired brass-buckled boots described in Round 1. The delivery docket, signed by Harper, specifies the classroom door rather than the school kitchen. Owen saw the assistant wait while Harper opened the student-record drawer to find payment. This gives a witnessed reason for knowing Harper's schedule and seeing the drawer. Neither the flour on the boots nor that access proves a visit before sunrise on the fatal morning.\n\nWitness background for Jasper Crowe: Owen Bell checked Jasper Crowe's name on the fundraiser attendance sheet at nine the previous evening. He recognized the blue-strapped case and watched the musician leave it beside Harper's desk while stacking chairs. White chalk marked the case corner where it rubbed the desktop, covering part of the pale bakery streak described in Round 1. Owen identifies a source for the transfer and a reason for being in the room. He locked the public school door after the event, but did not remain to watch the classroom's separate yard entrance overnight.\n\nThe host reads the original neighbors' recorded responses:\nXander Hale's recorded response: \"I heard Owen saw Lydia Vance's green folder in Harper's classroom at six, discussing pupil privacy. Its chalk matches the desk height. I worry about access, but Owen left at seven.\"\nMarla Quinn's recorded response: \"I heard Harper said Xander Hale once worked with blades; Owen saw his narrow whetstone during her drawer repair. Chalk explains his cuff mark to me, not missing pages or blade skills.\"\nJasper Crowe's recorded response: \"I read Marla Quinn's signed six-o'clock bread delivery to Harper's classroom door. Owen saw her wait by the open records drawer. I see access, but not a fatal-morning visit.\"\nLydia Vance's recorded response: \"I read Jasper Crowe's nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak. I see how marks transfer, but Owen didn't watch the yard entrance overnight.\"\n\nThe supplied witness accounts support these comparisons:\nNell Reed recorded a chalk smear and narrow drag line through it.\nDella March identified Lydia and the topic of the bakery argument.\nFinn Moss heard a promised parcel requested but saw no handover.\nAda Bell saw the fine stones in an address-stamped sleeve.\nOwen Bell found Harper, locked the classroom and fetched Nell.\nEdith Shaw has not supplied an office account at this stage.\nTown Investigator connected three disturbed records by receipt 47.\nDella's collection of Della's Granddaughter identifies a teacher, not a threat.",
        "publicText": "Harper Wren: throat slashed with the same precise cut. Owen Bell found her; Nell Reed recorded chalk and a drag line beside a disturbed student-record book. Its index cites receipt 47 and a copy kept with an unnamed original order. Attendance and lesson records are intact.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "Before sunrise, caretaker Owen Bell finds senior teacher Harper Wren in her classroom with her throat slashed, the same precise cut again.",
          "Harper taught most of the town's children and kept family records as carefully as lesson plans.",
          "Owen locks the room and fetches Nell Reed."
        ],
        "readingGroups": [
          [
            "xander",
            "marla",
            "jasper"
          ]
        ],
        "chain": [
          "xander",
          "marla",
          "jasper"
        ],
        "coverageRepeat": true
      },
      {
        "title": "Round 4 - Visits and Transferred Marks",
        "narration": "Compare only the findings already read at the bakery, tavern and school. An evening delivery is not a fatal-morning visit; flour, rosin, shellac and chalk have witnessed work-related sources. Receipt 47 links disturbed records but does not yet identify their subject. Correct an accusation that mistakes a work trace or access for a witnessed killing. No new death, name, trade or weapon identification is introduced.",
        "publicText": "Correct earlier inferences using only already released evidence.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "Compare released work traces with the recorded visits.",
          "Correct unsupported accusations without a new discovery."
        ],
        "readingGroups": [
          [
            "xander",
            "jasper",
            "marla"
          ]
        ],
        "chain": [
          "xander",
          "jasper",
          "marla"
        ],
        "coverageRepeat": true
      },
      {
        "title": "Round 5 - The Lamplighter's Murder",
        "narration": "Before the morning market opens, Nell Reed finds Tobias Wick beside an extinguished streetlamp with his throat slashed in the same precise manner. Tobias walked every lane at night and kept route notes about what he saw. Lamp oil has spilled in a perfect circle around the lamp base. Nell records its position before moving the fallen oil flask; the shape of the spill alone cannot identify who was there. A page is torn from Tobias's old route notebook. The surviving index bears receipt 47 and the instruction, \"Retain duplicate with original order.\" Nell gathers the bakery closing-duty sheet, Ronan's appointment book and Harper's lesson diary for comparison with the earlier witness accounts. Their entries can explain a visit or correct a timing assumption, but they are not blanket alibis. The subject of the old records is still missing.  Let each account introduce its own new finding. Then compare the four scenes and ask which traces are ordinary work and which remain unexplained.\n\nThe investigator reads the supporting witness accounts before calling on the selected readers:\n\nWitness background for Marla Quinn: Nell Reed compares Marla Quinn's flour-marked repaired boot from Round 1 with the bakery closing-duty sheet. Elias initialed her nine-o'clock task: scrub the rear threshold, then deliver the waste pail to the market. The entry explains why the crescent heel and flour appeared at the doorway; it is not evidence that the print was made during the killing. Market seller Della March also records that the assistant reported Tobias arguing with an unidentified figure beside the oil stall last night. Della heard the report, not the argument, so she cannot identify that figure.\n\nWitness background for Jasper Crowe: Della March saw Jasper Crowe follow Tobias from the tavern to the market lamp at ten last night. She identified the musician by his blue-strapped case and by the tune he had just played at her stall. Tobias asked him to hold the oil flask while adjusting the wick; Della saw a drop spill onto his right sleeve. The stain therefore has an observed source, not merely an assumed link to lamplighting. Della closed her shutter before Tobias resumed his route. The musician's presence and oil stain establish contact, but not where either man went afterward.\n\nWitness background for Lydia Vance: Nell Reed finds Lydia Vance's warning to Tobias entered in his intact route book: \"Children's family affairs do not belong in street notes.\" The entry describes her green folder and the school gate, where Owen Bell confirms he saw them speak. Nell compares it with Harper's lesson diary, which schedules their weekly meetings to prepare lessons and handle family requests. These sources explain the teacher's meetings and concern about records without supplying an overnight alibi. They do not explain why the older page indexed under receipt 47 was torn out.\n\nWitness background for Xander Hale: Nell Reed saw Xander Hale beneath the workshop lamp yesterday evening, holding a straight razor rather than a woodworking chisel. She recognized him from the shelf-repair invoice she had collected at the tavern and spoke to him face to face. The open blade reflected the lamp; the ivory handle had a triangular chip beside its hinge. He closed it and put it into the address-stamped leather sleeve whose fine stones Ada Bell described in Round 2. Nell can identify the owner, object and distinctive damage, but she did not see an attack. The blade should be compared with the repeated precise cuts, not treated as a confession.\n\nThe host reads the original neighbors' recorded responses:\nXander Hale's recorded response: \"I read Marla Quinn's nine-o'clock closing duty: scrub the rear threshold, then take waste to market. I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone.\"\nMarla Quinn's recorded response: \"I heard Della saw Jasper Crowe follow Tobias to the market lamp at ten. He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward.\"\nJasper Crowe's recorded response: \"I read Lydia Vance's warning to Tobias: children's family affairs don't belong in street notes. Her weekly lesson meetings explain contact to me, not an overnight alibi or receipt 47's torn page.\"\nLydia Vance's recorded response: \"I heard Nell saw Xander Hale's straight razor: ivory handle, triangular chip beside its hinge. It went into his stamped sleeve. I worry about those precise cuts, not a confession.\"\n\nThe supplied witness accounts support these comparisons:\nNell Reed saw the chipped ivory razor enter the stamped sleeve.\nDella March saw Jasper holding the flask before oil spilled on his sleeve.\nFinn Moss left for the delivery cart without witnessing the bakery death.\nAda Bell saw the blue-strapped case on Ronan's counter at ten.\nOwen Bell left at seven without watching the separate yard entrance overnight.\nEdith Shaw has not supplied an office account at this stage.\nTown Investigator preserved the earlier work records for timing comparisons.\nDella's school collection of Della's Granddaughter does not identify a murderer.",
        "publicText": "Tobias Wick: throat slashed with the same precise cut. Nell Reed found him beside an extinguished lamp and a circle of spilled oil. A torn night-route page is indexed under receipt 47. Earlier work and appointment records are ready for comparison, not complete alibis.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "Before the morning market opens, Nell Reed finds Tobias Wick beside an extinguished streetlamp with his throat slashed in the same precise manner.",
          "Tobias walked every lane at night and kept route notes about what he saw.",
          "Lamp oil has spilled in a perfect circle around the lamp base."
        ],
        "readingGroups": [
          [
            "xander",
            "marla",
            "jasper"
          ]
        ],
        "chain": [
          "xander",
          "marla",
          "jasper"
        ],
        "coverageRepeat": true
      },
      {
        "title": "Round 6 - Work Traces and the Identified Tool",
        "narration": "Compare the already released closing-duty sheet, private-appointment records, school visits and Nell's chipped-razor sighting. A work record can explain a trace without supplying an overnight alibi. The identified razor is more specific than an unexplained color or stain, but its sighting is not a confession. Correct earlier accusations based only on flour, chalk or spilled oil. No new death or old identity is introduced.",
        "publicText": "Correct earlier inferences using only already released evidence.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "Compare released work traces with the recorded visits.",
          "Correct unsupported accusations without a new discovery."
        ],
        "readingGroups": [
          [
            "xander",
            "jasper",
            "marla"
          ]
        ],
        "chain": [
          "xander",
          "jasper",
          "marla"
        ],
        "coverageRepeat": true
      },
      {
        "title": "Round 7 - The Mayor's Murder",
        "narration": "Office clerk Edith Shaw finds Mayor Aldric Thorne in his office chair with his throat slashed, the same precise cut. A polished straight razor lies on the desk, its ivory handle chipped beside the hinge. Edith calls Nell Reed and identifies the locked cabinet from which the papers on the desk came; its numbered index and broken wax seal allow the investigator to trace their source. A single old court document, signed by Thorne, orders the imprisonment of BENJAMIN BARKER and bears receipt 47. This is the first time that name enters the investigation. With it are the duplicate records referred to in Harper's index and Tobias's notebook. The investigator reads them aloud: Elias signed a false delivery entry placing Barker at a theft; Ronan signed a fabricated account of a confession; Harper altered a household record to support the charge; Tobias supplied a false night-route sighting. A retained letter from Thorne orders the changes, admits that he wanted Barker's wife and describes using imprisonment to separate them. The household record states that she was taken into Thorne's household under coercion, not by free choice. Barker's licensed occupation is barber. A likeness, address and tool inventory are attached, but the investigator leaves their identification to the witnesses whose accounts you are about to hear. These documents establish the original injustice and the four victims' roles. They do not announce which current neighbor committed the murders.  Hear every account before the final vote.\n\nThe investigator reads the supporting witness accounts before calling on the selected readers:\n\nWitness background for Jasper Crowe: Edith Shaw asks Jasper Crowe to explain a rumor he heard at the tavern about the woodworker once using a different name. He identifies its source as Ronan's remark about an old license, not personal knowledge of the imprisonment. Edith compares the signature on his ten-o'clock drink receipt with the appointment book preserved in Round 2; it confirms his earlier visit, while a separate eleven-o'clock entry admits a private visitor. His rosin flake explains a substance on the counter, but neither the rumor nor the flake identifies that later visitor or makes him a signer of the false statements in the court file.\n\nWitness background for Lydia Vance: Edith Shaw compares Lydia Vance's account of seeing the Mayor hide an old paper with the cabinet index recovered today. The teacher dates the sighting to a school-funding appointment entered in Edith's diary; Edith confirms she admitted her for that appointment and saw Thorne close the folder. The teacher could read receipt 47, but not the name hidden beneath his hand. This explains why the teacher questioned intrusive family records. Her chalk-marked folder and weekly lesson meetings establish access to school papers, not a signature on the falsified statements read from the court file.\n\nWitness background for Xander Hale: Edith Shaw identifies the court file's licensed likeness as Xander Hale; she compares the workshop address printed beside it with the signed shelf-repair invoice preserved in Round 2. The licensed name is Benjamin Barker. The barber's tool inventory describes an ivory razor with a chip beside the hinge, matching the blade Nell Reed saw in his hand in Round 4 and the one now on Thorne's desk. The fine stones and Harper's earlier-trade remark fit the documented occupation. The duplicate records identify the four people who helped Thorne destroy his former life. This joins identity, blade ownership and motive; the room must still decide its final accusation.\n\nWitness background for Marla Quinn: Edith Shaw checks Marla Quinn's account of an old visit by Thorne to the workshop home. The assistant remembers delivering a baker's basket there as a child; the retained delivery copy records the date and the house number. Edith compares those details with Thorne's appointment diary and confirms the visit. The account links a remembered visit to a documented place, but the assistant did not hear the conversation. Her repaired flour-marked boot still fits the closing chore established in Round 4, not a proven killing. Neither her childhood observation nor her recent bread delivery makes her one of the signers identified in the old file.\n\nThe host reads the original neighbors' recorded responses:\nXander Hale's recorded response: \"I heard Jasper Crowe's different-name rumor came from Ronan's old-license remark. His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin.\"\nMarla Quinn's recorded response: \"I learned Lydia Vance saw Thorne hide receipt 47 during her confirmed school-funding appointment. She couldn't read the name. I see why she questioned family records, not proof she falsified them.\"\nJasper Crowe's recorded response: \"I heard Edith match Xander Hale's licensed likeness and workshop address: Benjamin Barker, barber. His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse.\"\nLydia Vance's recorded response: \"I heard Edith confirm Marla Quinn's childhood delivery during Thorne's old workshop-home visit. She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot.\"\n\nThe supplied witness accounts support these comparisons:\nNell Reed identified the damaged razor in the earlier sighting.\nDella March's boot identification established work access, not print timing.\nFinn Moss's case account established an evening visit, not a witnessed murder.\nAda Bell's account left later private visitors possible.\nOwen Bell's accounts did not establish an overnight alibi.\nEdith Shaw matched the licensed likeness and address to Xander.\nTown Investigator read the retained duplicate records and Thorne's letter.\nDella's identification through Della's Granddaughter does not implicate Lydia in the old falsification.",
        "publicText": "Mayor Aldric Thorne: throat slashed; a polished razor with a chipped ivory handle on his desk. Edith Shaw identifies the cabinet and record index. Thorne's signed imprisonment order names Benjamin Barker under receipt 47. Duplicate records and his letter expose the four victims' false statements and his coercion. Witness identification follows in the player readings.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "Office clerk Edith Shaw finds Mayor Aldric Thorne in his office chair with his throat slashed, the same precise cut.",
          "A polished straight razor lies on the desk, its ivory handle chipped beside the hinge.",
          "Edith calls Nell Reed and identifies the locked cabinet from which the papers on the desk came; its numbered index and broken wax seal allow the investigator to trace their source."
        ],
        "readingGroups": [
          [
            "xander",
            "marla",
            "jasper"
          ]
        ],
        "chain": [
          "xander",
          "marla",
          "jasper"
        ],
        "coverageRepeat": true
      }
    ],
    "characters": [
      {
        "id": "xander",
        "name": "Xander Hale",
        "role": "Woodworker",
        "relationship": "A neighbor asked by the town investigator to help compare witness accounts of the Blackwater Row murders.",
        "tieIn": "A quiet craftsperson who repairs furniture and makes wooden fittings in a workshop off the market lane.",
        "optional": false,
        "ghost": null,
        "guest": "",
        "guestNote": "",
        "publicBlurb": "A quiet craftsperson who repairs furniture and makes wooden fittings in a workshop off the market lane.",
        "rounds": [
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I heard Nell saw {marla} leave the bakery's back door at nine with her red-handled brush. Her repaired, flour-packed heel resembles those prints. I still need their timing checked.",
              "observation": "I heard Nell saw {marla} leave the bakery's back door at nine with her red-handled brush.",
              "contradictingDetail": "Her repaired, flour-packed heel resembles those prints. I still need their timing checked."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I heard Ada saw {jasper}'s blue-strapped case on Ronan's counter at ten. His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors.",
              "observation": "I heard Ada saw {jasper}'s blue-strapped case on Ronan's counter at ten.",
              "contradictingDetail": "His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I read {marla}'s signed six-o'clock bread delivery to Harper's classroom door. Owen saw her wait by the open records drawer. I see access, but not a fatal-morning visit.",
              "observation": "I read {marla}'s signed six-o'clock bread delivery to Harper's classroom door.",
              "contradictingDetail": "Owen saw her wait by the open records drawer. I see access, but not a fatal-morning visit."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I heard {jasper}'s case rubbed the chalky desk over its flour streak. I must distinguish transferred work marks from evidence that he removed the student-record page.",
              "observation": "I heard {jasper}'s case rubbed the chalky desk over its flour streak.",
              "contradictingDetail": "I must distinguish transferred work marks from evidence that he removed the student-record page."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I read {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market. I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone.",
              "observation": "I read {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market.",
              "contradictingDetail": "I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I read {jasper}'s visit to the lamp in Della's account. I must not treat spilled oil on his sleeve as proof of a precise cut or an account of his later movements.",
              "observation": "I read {jasper}'s visit to the lamp in Della's account.",
              "contradictingDetail": "I must not treat spilled oil on his sleeve as proof of a precise cut or an account of his later movements."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I heard Edith confirm {marla}'s childhood delivery during Thorne's old workshop-home visit. She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot.",
              "observation": "I heard Edith confirm {marla}'s childhood delivery during Thorne's old workshop-home visit.",
              "contradictingDetail": "She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot."
            }
          }
        ]
      },
      {
        "id": "marla",
        "name": "Marla Quinn",
        "role": "Baker's assistant",
        "relationship": "Assistant to the first victim, the baker Elias Brim; asked to help compare witness accounts.",
        "tieIn": "Elias Brim's assistant, responsible for bread deliveries and the evening cleanup. A familiar face at doorsteps across town.",
        "optional": false,
        "ghost": null,
        "guest": "",
        "guestNote": "",
        "publicBlurb": "Elias Brim's assistant, responsible for bread deliveries and the evening cleanup. A familiar face at doorsteps across town.",
        "rounds": [
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I heard Finn saw {jasper} behind the bakery at nine-thirty with his blue-strapped case. A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave.",
              "observation": "I heard Finn saw {jasper} behind the bakery at nine-thirty with his blue-strapped case.",
              "contradictingDetail": "A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I read {xander}'s shelf invoice; Ada saw fine sharpening stones in his address-stamped sleeve. His repair cloth held amber shellac. I see another possible smear source, not proof he touched that mug.",
              "observation": "I read {xander}'s shelf invoice; Ada saw fine sharpening stones in his address-stamped sleeve.",
              "contradictingDetail": "His repair cloth held amber shellac. I see another possible smear source, not proof he touched that mug."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I read {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak. I see how marks transfer, but Owen didn't watch the yard entrance overnight.",
              "observation": "I read {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak.",
              "contradictingDetail": "I see how marks transfer, but Owen didn't watch the yard entrance overnight."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard {xander}'s drawer repair explained chalk on his cuff. I must not mistake a work mark for an explanation of the missing pages or his earlier blade skills.",
              "observation": "I heard {xander}'s drawer repair explained chalk on his cuff.",
              "contradictingDetail": "I must not mistake a work mark for an explanation of the missing pages or his earlier blade skills."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I heard Della saw {jasper} follow Tobias to the market lamp at ten. He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward.",
              "observation": "I heard Della saw {jasper} follow Tobias to the market lamp at ten.",
              "contradictingDetail": "He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard Nell identify {xander}'s chipped ivory razor. I must compare that identifiable tool with the repeated cuts, not call the sighting a confession.",
              "observation": "I heard Nell identify {xander}'s chipped ivory razor.",
              "contradictingDetail": "I must compare that identifiable tool with the repeated cuts, not call the sighting a confession."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I heard {jasper}'s different-name rumor came from Ronan's old-license remark. His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin.",
              "observation": "I heard {jasper}'s different-name rumor came from Ronan's old-license remark.",
              "contradictingDetail": "His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin."
            }
          }
        ]
      },
      {
        "id": "jasper",
        "name": "Jasper Crowe",
        "role": "Tavern musician",
        "relationship": "Musician at the tavern of the second victim, Ronan Pike; asked to help compare witness accounts.",
        "tieIn": "A musician at Ronan Pike's tavern who also plays for town events. Often out late carrying his instrument between jobs.",
        "optional": false,
        "ghost": null,
        "guest": "",
        "guestNote": "",
        "publicBlurb": "A musician at Ronan Pike's tavern who also plays for town events. Often out late carrying his instrument between jobs.",
        "rounds": [
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard Della saw Elias refuse to enter {xander}'s workshop over an old receipt. He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon.",
              "observation": "I heard Della saw Elias refuse to enter {xander}'s workshop over an old receipt.",
              "contradictingDetail": "He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I heard Della heard {marla} dispute Ronan's flour bill at seven. She showed a receipt and left toward the bakery. I can't confirm payment or a later return.",
              "observation": "I heard Della heard {marla} dispute Ronan's flour bill at seven.",
              "contradictingDetail": "She showed a receipt and left toward the bakery. I can't confirm payment or a later return."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair. Chalk explains his cuff mark to me, not missing pages or blade skills.",
              "observation": "I heard Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair.",
              "contradictingDetail": "Chalk explains his cuff mark to me, not missing pages or blade skills."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I read {marla}'s signed bread delivery at six. I must distinguish an evening delivery from a fatal-morning visit; access alone does not explain the missing page.",
              "observation": "I read {marla}'s signed bread delivery at six.",
              "contradictingDetail": "I must distinguish an evening delivery from a fatal-morning visit; access alone does not explain the missing page."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge. It went into his stamped sleeve. I worry about those precise cuts, not a confession.",
              "observation": "I heard Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge.",
              "contradictingDetail": "It went into his stamped sleeve. I worry about those precise cuts, not a confession."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I read {marla}'s closing duty to scrub the rear threshold. I must correct my earlier suspicion: flour in her repaired heel can come from work, not a witnessed killing.",
              "observation": "I read {marla}'s closing duty to scrub the rear threshold.",
              "contradictingDetail": "I must correct my earlier suspicion: flour in her repaired heel can come from work, not a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard Edith match {xander}'s licensed likeness and workshop address: Benjamin Barker, barber. His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse.",
              "observation": "I heard Edith match {xander}'s licensed likeness and workshop address: Benjamin Barker, barber.",
              "contradictingDetail": "His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse."
            }
          }
        ]
      }
    ],
    "finale": {
      "narration": "All seven chapters and the final witness accounts have now been read. Compare the identified blade, the licensed likeness and address, and the duplicate records with the earlier observations. Decide which neighbor accounts for the complete chain, not just one suspicious trace. A reason for revenge can explain a crime without excusing it. Make your final accusation before the investigator announces the solution.",
      "votePrompt": "Who do you accuse based on the evidence heard so far?"
    },
    "solution": {
      "killerId": "xander",
      "explanation": "Xander Hale is Benjamin Barker, formerly Blackwater Row's trusted barber, and he committed all five murders. Thorne's letter and court file, first read in Round 7, establish that the Mayor wanted Barker's wife, framed him, ordered his imprisonment and forced her into his household. Elias's false delivery entry, Ronan's invented confession, Harper's altered household record and Tobias's false night sighting helped destroy Barker's married life. After release, Barker returned as the woodworker Xander Hale. The fine stones in his address-stamped sleeve and Harper's earlier-trade remark established a blade skill without naming it. Nell's direct observation of the chipped ivory razor in Round 5 supplied identifiable ownership; Edith's Round 7 comparison joined that razor, the licensed likeness and the repair invoice to the old identity. Receipt 47 linked the disturbed records; retained duplicates explained the target selection. Marla's repaired flour-marked boot had a documented closing-chore source. Jasper's case and rosin and Lydia's folder and chalk had witnessed work-related sources; their movements raised questions but did not explain the complete identity, weapon and motive chain. No stain alone proved a killing. Barker killed the four accomplices before reaching his final target, the Mayor. This was deliberate revenge, not justice.",
      "revealNarration": "The investigator closes the court file. \"The killer is {xander}. His former name was Benjamin Barker, and his former trade was barber. Nell identified the damaged razor in his hand; Edith matched the license and address to his current work. The earlier victims supplied the false statements that destroyed his former life. Thorne was his final target.\"\n\nThe host may read Barker's final words: \"Once this town knew me as Benjamin Barker. I had a trade, a wife and a home. Thorne wanted what was not his, and four respectable voices made his lie sound like law. When I returned, I called myself Xander Hale and worked in wood. I thought a new name could bury the old one. Instead I carried it through every door. I chose revenge, and I killed them. It did not restore my wife's freedom or the years we lost. Nothing they did makes these murders right.\"\n\nBlackwater Row must now reckon with both the original injustice and the five deaths that followed."
    },
    "masterPreserving": true,
    "conversion": {
      "source": "Committed four-player Blackwater Row revision 3.",
      "changes": [
        {
          "original": "Five discovery chapters and four playable neighbors.",
          "replacement": "Five unchanged discovery sequences with two intervening comparison chapters and a three-player core.",
          "reason": "Seven-round requirement and smallest-edition master. Identity remains in the last discovery chapter; no murders or facts are added."
        },
        {
          "original": "Per-chapter four-player reader handoffs and twenty player responses.",
          "replacement": "Named recorded responses in shared narration and count-specific group order.",
          "reason": "Preserve every witness source and original response while selecting a three-player loop."
        },
        {
          "original": "Solution timing references to Round 4 and Round 5.",
          "replacement": "Corresponding seven-chapter references to Round 5 and Round 7.",
          "reason": "Inserted comparison rounds shift chapter numbers without advancing evidence."
        }
      ],
      "originalResponses": [
        {
          "id": "xander",
          "rounds": [
            {
              "readAloud": {
                "accuses": "marla",
                "text": "I heard Nell saw {marla} leave the bakery's back door at nine with her red-handled brush. Her repaired, flour-packed heel resembles those prints. I still need their timing checked.",
                "observation": "I heard Nell saw {marla} leave the bakery's back door at nine with her red-handled brush.",
                "contradictingDetail": "Her repaired, flour-packed heel resembles those prints. I still need their timing checked."
              }
            },
            {
              "readAloud": {
                "accuses": "jasper",
                "text": "I heard Ada saw {jasper}'s blue-strapped case on Ronan's counter at ten. His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors.",
                "observation": "I heard Ada saw {jasper}'s blue-strapped case on Ronan's counter at ten.",
                "contradictingDetail": "His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors."
              }
            },
            {
              "readAloud": {
                "accuses": "lydia",
                "text": "I heard Owen saw {lydia}'s green folder in Harper's classroom at six, discussing pupil privacy. Its chalk matches the desk height. I worry about access, but Owen left at seven.",
                "observation": "I heard Owen saw {lydia}'s green folder in Harper's classroom at six, discussing pupil privacy.",
                "contradictingDetail": "Its chalk matches the desk height. I worry about access, but Owen left at seven."
              }
            },
            {
              "readAloud": {
                "accuses": "marla",
                "text": "I read {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market. I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone.",
                "observation": "I read {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market.",
                "contradictingDetail": "I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone."
              }
            },
            {
              "readAloud": {
                "accuses": "jasper",
                "text": "I heard {jasper}'s different-name rumor came from Ronan's old-license remark. His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin.",
                "observation": "I heard {jasper}'s different-name rumor came from Ronan's old-license remark.",
                "contradictingDetail": "His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin."
              }
            }
          ]
        },
        {
          "id": "marla",
          "rounds": [
            {
              "readAloud": {
                "accuses": "jasper",
                "text": "I heard Finn saw {jasper} behind the bakery at nine-thirty with his blue-strapped case. A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave.",
                "observation": "I heard Finn saw {jasper} behind the bakery at nine-thirty with his blue-strapped case.",
                "contradictingDetail": "A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave."
              }
            },
            {
              "readAloud": {
                "accuses": "lydia",
                "text": "I heard Ada heard {lydia} warn Ronan about recording families at eight. She touched his book, leaving possible chalk. I can't prove a removed page or a later return.",
                "observation": "I heard Ada heard {lydia} warn Ronan about recording families at eight.",
                "contradictingDetail": "She touched his book, leaving possible chalk. I can't prove a removed page or a later return."
              }
            },
            {
              "readAloud": {
                "accuses": "xander",
                "text": "I heard Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair. Chalk explains his cuff mark to me, not missing pages or blade skills.",
                "observation": "I heard Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair.",
                "contradictingDetail": "Chalk explains his cuff mark to me, not missing pages or blade skills."
              }
            },
            {
              "readAloud": {
                "accuses": "jasper",
                "text": "I heard Della saw {jasper} follow Tobias to the market lamp at ten. He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward.",
                "observation": "I heard Della saw {jasper} follow Tobias to the market lamp at ten.",
                "contradictingDetail": "He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward."
              }
            },
            {
              "readAloud": {
                "accuses": "lydia",
                "text": "I learned {lydia} saw Thorne hide receipt 47 during her confirmed school-funding appointment. She couldn't read the name. I see why she questioned family records, not proof she falsified them.",
                "observation": "I learned {lydia} saw Thorne hide receipt 47 during her confirmed school-funding appointment.",
                "contradictingDetail": "She couldn't read the name. I see why she questioned family records, not proof she falsified them."
              }
            }
          ]
        },
        {
          "id": "jasper",
          "rounds": [
            {
              "readAloud": {
                "accuses": "lydia",
                "text": "I heard Della saw {lydia} argue with Elias that morning, her green lesson folder tucked under her arm. A bread bill held family history. I wonder why he folded that paper.",
                "observation": "I heard Della saw {lydia} argue with Elias that morning, her green lesson folder tucked under her arm.",
                "contradictingDetail": "A bread bill held family history. I wonder why he folded that paper."
              }
            },
            {
              "readAloud": {
                "accuses": "xander",
                "text": "I read {xander}'s shelf invoice; Ada saw fine sharpening stones in his address-stamped sleeve. His repair cloth held amber shellac. I see another possible smear source, not proof he touched that mug.",
                "observation": "I read {xander}'s shelf invoice; Ada saw fine sharpening stones in his address-stamped sleeve.",
                "contradictingDetail": "His repair cloth held amber shellac. I see another possible smear source, not proof he touched that mug."
              }
            },
            {
              "readAloud": {
                "accuses": "marla",
                "text": "I read {marla}'s signed six-o'clock bread delivery to Harper's classroom door. Owen saw her wait by the open records drawer. I see access, but not a fatal-morning visit.",
                "observation": "I read {marla}'s signed six-o'clock bread delivery to Harper's classroom door.",
                "contradictingDetail": "Owen saw her wait by the open records drawer. I see access, but not a fatal-morning visit."
              }
            },
            {
              "readAloud": {
                "accuses": "lydia",
                "text": "I read {lydia}'s warning to Tobias: children's family affairs don't belong in street notes. Her weekly lesson meetings explain contact to me, not an overnight alibi or receipt 47's torn page.",
                "observation": "I read {lydia}'s warning to Tobias: children's family affairs don't belong in street notes.",
                "contradictingDetail": "Her weekly lesson meetings explain contact to me, not an overnight alibi or receipt 47's torn page."
              }
            },
            {
              "readAloud": {
                "accuses": "xander",
                "text": "I heard Edith match {xander}'s licensed likeness and workshop address: Benjamin Barker, barber. His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse.",
                "observation": "I heard Edith match {xander}'s licensed likeness and workshop address: Benjamin Barker, barber.",
                "contradictingDetail": "His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse."
              }
            }
          ]
        },
        {
          "id": "lydia",
          "rounds": [
            {
              "readAloud": {
                "accuses": "xander",
                "text": "I heard Della saw Elias refuse to enter {xander}'s workshop over an old receipt. He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon.",
                "observation": "I heard Della saw Elias refuse to enter {xander}'s workshop over an old receipt.",
                "contradictingDetail": "He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon."
              }
            },
            {
              "readAloud": {
                "accuses": "marla",
                "text": "I heard Della heard {marla} dispute Ronan's flour bill at seven. She showed a receipt and left toward the bakery. I can't confirm payment or a later return.",
                "observation": "I heard Della heard {marla} dispute Ronan's flour bill at seven.",
                "contradictingDetail": "She showed a receipt and left toward the bakery. I can't confirm payment or a later return."
              }
            },
            {
              "readAloud": {
                "accuses": "jasper",
                "text": "I read {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak. I see how marks transfer, but Owen didn't watch the yard entrance overnight.",
                "observation": "I read {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak.",
                "contradictingDetail": "I see how marks transfer, but Owen didn't watch the yard entrance overnight."
              }
            },
            {
              "readAloud": {
                "accuses": "xander",
                "text": "I heard Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge. It went into his stamped sleeve. I worry about those precise cuts, not a confession.",
                "observation": "I heard Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge.",
                "contradictingDetail": "It went into his stamped sleeve. I worry about those precise cuts, not a confession."
              }
            },
            {
              "readAloud": {
                "accuses": "marla",
                "text": "I heard Edith confirm {marla}'s childhood delivery during Thorne's old workshop-home visit. She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot.",
                "observation": "I heard Edith confirm {marla}'s childhood delivery during Thorne's old workshop-home visit.",
                "contradictingDetail": "She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot."
              }
            }
          ]
        }
      ]
    }
  },
  "4": {
    "schemaVersion": 2,
    "fixedPlayerCount": 4,
    "discloseKiller": false,
    "clueRouting": "rotating",
    "edition": {
      "family": "blackwater-scalable",
      "id": "blackwater-scalable-4-players",
      "playerCount": 4,
      "revision": 1
    },
    "title": "The Barber of Blackwater Row",
    "atmosphere": "victorian",
    "setting": "Blackwater Row, a riverside town of workshops, narrow lanes and gaslit streets in the late nineteenth century.",
    "intro": "Evening settles over Blackwater Row. Three neighbors help the town investigator compare the supplied accounts: Xander Hale, the woodworker; Marla Quinn, the baker's assistant; and Jasper Crowe, the tavern musician. The host reads every recorded witness account before the players respond. Other named people remain in the evidence even when they are not playable. Discuss only the chapter just heard; nobody invents a history, witnesses a new discovery or improvises a private part.",
    "hiddenThread": "Receipt 47 recurs in every victim's disturbed records and finally names the Mayor's old imprisonment order against Benjamin Barker.",
    "coverageRepeatNote": "The trio covers all six directed pairs in the first two rounds. Later repeats add released evidence or explicitly correct an unsupported earlier inference. Each supplemental reader targets every other selected character before repeating, never in consecutive rounds. Separate singleton readings preserve the master loop and evidence timing.",
    "specialMechanics": [
      "Receipt 47 ledger: each murder surfaces another record indexed under receipt 47 (delivery log, tavern scrap, student-record index, night-route page). Compare them across rounds; the Mayor's signed order in Round 7 finally connects the series to the old case."
    ],
    "victim": {
      "name": "Elias Brim",
      "description": "The town baker, known for dependable bread deliveries and careful records."
    },
    "rounds": [
      {
        "title": "Round 1 - The Baker's Murder",
        "narration": "At dawn, delivery porter Finn Moss finds Elias Brim behind his bakery with his throat slashed. The investigator reports one clean, precise cut; the death happened off-screen. Elias supplied nearly every doorstep and recorded deliveries and closing chores in separate books. Finn calls night watchwoman Nell Reed before anyone enters the yard. She records a chain of flour prints from the back door to the wet cobbles. Each right print has a crescent-shaped gap at the heel; the cobbles preserve nothing beyond it. A page is torn from an older delivery log. Its surviving edge carries the date and part of receipt 47, but not a customer name or the purpose of the entry. The closing-duty sheet is intact and is kept for later comparison. These are the findings at this scene, not an identification of the killer. The investigator has collected four separate accounts about the neighbors.  Hear all four before discussing which details establish access and which merely raise suspicion.\n\nThe investigator reads the supporting witness accounts before calling on the selected readers:\n\nWitness background for Marla Quinn: Nell Reed saw Marla Quinn leave the bakery back door at nine, carrying her red-handled scrubbing brush. Nell recognized the brass buckle and crescent-shaped repair in the right heel of her work boots because cobbler Della March had shown her that repair at collection yesterday. Flour was packed into the repaired heel. The shape resembles the yard prints recorded this morning. This ties the boots to bakery work and the doorway, but does not date when each print was made. The closing-duty sheet has not yet been checked against the sighting.\n\nWitness background for Jasper Crowe: Finn Moss saw Jasper Crowe waiting behind the bakery at half past nine, with a blue-strapped instrument case propped against the wall. Finn recognized the musician from the tavern and the case from carrying it after last week's performance. A pale streak ran across its lower corner where it touched a flour sack outside the door. Finn heard him ask Elias for a promised parcel, but did not see a parcel handed over or hear what it contained. Finn left for the delivery cart; he did not witness the death or the musician's departure.\n\nWitness background for Lydia Vance: Della March saw Lydia Vance arguing with Elias at the bakery front counter that morning. She recognized the teacher from collecting her granddaughter from school and saw the same green lesson folder under her arm. Della heard the teacher ask why a bread bill included a household's personal history. Elias folded a paper and refused to answer. The teacher left a chalky thumb mark on the counter when she leaned forward. Della identifies the person and the topic, but heard no threat and never saw the contents of the folded paper.\n\nWitness background for Xander Hale: Della March delivered a wooden chair to Xander Hale's workshop last week and saw Elias at the open door. She recognized both men from their regular work at her market stall. Elias refused to enter and said, \"I will not bring that old receipt here again.\" The woodworker stopped sanding, gripped the chair rail and asked which book Elias meant. Della saw fresh amber shellac on his apron beside the repair cloth, but no weapon. She can identify the reaction and the receipt dispute; she cannot identify the old transaction or turn that reaction into proof of murder.\n\nThe host reads the original neighbors' recorded responses:\nXander Hale's recorded response: \"I heard Nell saw Marla Quinn leave the bakery's back door at nine with her red-handled brush. Her repaired, flour-packed heel resembles those prints. I still need their timing checked.\"\nMarla Quinn's recorded response: \"I heard Finn saw Jasper Crowe behind the bakery at nine-thirty with his blue-strapped case. A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave.\"\nJasper Crowe's recorded response: \"I heard Della saw Lydia Vance argue with Elias that morning, her green lesson folder tucked under her arm. A bread bill held family history. I wonder why he folded that paper.\"\nLydia Vance's recorded response: \"I heard Della saw Elias refuse to enter Xander Hale's workshop over an old receipt. He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon.\"\n\nThe supplied witness accounts support these comparisons:\nNell Reed recorded flour prints with a crescent gap in the right heel.\nDella March recognized the repaired boot from its collection yesterday.\nFinn Moss found Elias and called Nell before anyone entered the yard.\nAda Bell has not supplied a tavern account at this stage.\nOwen Bell has not supplied a classroom account at this stage.\nEdith Shaw has not supplied an office account at this stage.\nTown Investigator reported one precise cut at the bakery.\nDella recognized Lydia through collecting Della's Granddaughter from school.",
        "publicText": "Elias Brim: throat slashed with one precise cut. Finn Moss found the body; Nell Reed recorded flour prints with a crescent gap in the right heel. An old delivery-log page is torn; only receipt 47 survives at its edge. The closing-duty sheet is intact.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "At dawn, delivery porter Finn Moss finds Elias Brim behind his bakery with his throat slashed.",
          "The investigator reports one clean, precise cut; the death happened off-screen.",
          "Elias supplied nearly every doorstep and recorded deliveries and closing chores in separate books."
        ],
        "readingGroups": [
          [
            "xander",
            "marla",
            "jasper"
          ],
          [
            "lydia"
          ]
        ],
        "chain": [
          "xander",
          "marla",
          "jasper",
          "lydia"
        ],
        "coverageRepeat": false
      },
      {
        "title": "Round 2 - The Barkeep's Murder",
        "narration": "The next morning, cleaner Ada Bell finds Ronan Pike slumped over his tavern counter with his throat slashed. The investigator records the same precise cut as at the bakery. Ronan kept accounts of debts and stayed late for private appointments. Ada does not touch the mug beside him; Nell Reed records that it has been wiped and has no usable fingerprints. A thin amber smear remains beneath its handle. No owner has been established for the mug or the smear. Beneath Ronan's account book lies a scrap bearing receipt 47 and four lines of dates. No names or explanation survive on the scrap. The matching number links two sets of records, but does not identify their subject. Ronan's service tally and appointment book are preserved separately so that the last drink served will not be confused with the last visitor admitted. Four witness accounts are ready.  Listen for who saw an object, how they identified its owner and whether their timing actually reaches the death.\n\nThe investigator reads the supporting witness accounts before calling on the selected readers:\n\nWitness background for Jasper Crowe: Ada Bell saw Jasper Crowe put his instrument case on Ronan's counter at ten and leave after the last public drink was served. She recognized the case by its repaired blue strap, which she had sewn herself. He uses amber rosin on his bow; Ada collected a flake from the spot where the case rested. Its color resembles the smear beneath the wiped mug, but color alone cannot establish that they are the same material. Ronan locked the public door afterward; Ada did not watch the side entrance or the later appointments.\n\nWitness background for Lydia Vance: Ada Bell heard Lydia Vance tell Ronan at eight, \"Those are dangerous notes; people did not give you permission to record their families.\" Ada recognized the green lesson folder under the teacher's arm from her school-cleaning rounds. The teacher tapped Ronan's account book, leaving a white powder trace on its dark cover. Ada collected it as a possible chalk transfer, not a laboratory identification. The warning concerns records, but Ada saw no page removed. The teacher walked out through the public door; Ada could not observe who returned later.\n\nWitness background for Xander Hale: Ronan's repair invoice records Xander Hale replacing the tavern shelf last week. Ada Bell identified him from the signed invoice and saw him open a leather tool sleeve stamped with the same workshop address. Inside were sharpening stones Ronan called \"too fine for woodworking\": one was much narrower and smoother than the broad stone used on the shelf chisel. Ada saw him wipe the sleeve with an amber shellac-stained cloth from his repair kit. That establishes ownership of the stones and a second possible source of amber residue; it does not prove who handled the wiped mug on the night of the murder.\n\nWitness background for Marla Quinn: Della March heard Marla Quinn dispute an unpaid flour bill with Ronan outside the tavern at seven. She recognized the baker's assistant by the stamped delivery basket she was carrying. Ronan held a bill with a torn lower corner; the assistant produced a coin receipt, but Della was too far away to compare its amount. She saw the assistant leave with the basket toward the bakery. The argument supplies a specific grievance and an observed departure, not proof of payment or a witnessed return to the counter where Ronan died.\n\nThe host reads the original neighbors' recorded responses:\nXander Hale's recorded response: \"I heard Ada saw Jasper Crowe's blue-strapped case on Ronan's counter at ten. His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors.\"\nMarla Quinn's recorded response: \"I heard Ada heard Lydia Vance warn Ronan about recording families at eight. She touched his book, leaving possible chalk. I can't prove a removed page or a later return.\"\nJasper Crowe's recorded response: \"I read Xander Hale's shelf invoice; Ada saw fine sharpening stones in his address-stamped sleeve. His repair cloth held amber shellac. I see another possible smear source, not proof he touched that mug.\"\nLydia Vance's recorded response: \"I heard Della heard Marla Quinn dispute Ronan's flour bill at seven. She showed a receipt and left toward the bakery. I can't confirm payment or a later return.\"\n\nThe supplied witness accounts support these comparisons:\nNell Reed recorded a wiped mug without usable fingerprints.\nDella March heard Marla dispute the flour bill and leave toward the bakery.\nFinn Moss did not witness the bakery death or the musician leaving.\nAda Bell found Ronan and left the mug untouched.\nOwen Bell has not supplied a classroom account at this stage.\nEdith Shaw has not supplied an office account at this stage.\nTown Investigator reported the same precise cut at the tavern.\nDella's school collection of Della's Granddaughter explains her recognition of Lydia.",
        "publicText": "Ronan Pike: throat slashed with the same precise cut. Ada Bell found him. A wiped mug has no usable fingerprints and an unidentified amber smear beneath its handle. A dated scrap bears receipt 47 but no names. Service and appointment records are preserved.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "The next morning, cleaner Ada Bell finds Ronan Pike slumped over his tavern counter with his throat slashed.",
          "The investigator records the same precise cut as at the bakery.",
          "Ronan kept accounts of debts and stayed late for private appointments."
        ],
        "readingGroups": [
          [
            "xander",
            "jasper",
            "marla"
          ],
          [
            "lydia"
          ]
        ],
        "chain": [
          "xander",
          "jasper",
          "marla",
          "lydia"
        ],
        "coverageRepeat": false
      },
      {
        "title": "Round 3 - The Schoolteacher's Murder",
        "narration": "Before sunrise, caretaker Owen Bell finds senior teacher Harper Wren in her classroom with her throat slashed, the same precise cut again. Harper taught most of the town's children and kept family records as carefully as lesson plans. Owen locks the room and fetches Nell Reed. She records a broad chalk smear across the desk and a narrow drag line through it, running from the student-record book toward its open drawer. A page is missing from that book. Its remaining index cites receipt 47; a margin note says, \"Copy kept with the original order.\" Neither the order's owner nor its location is recorded here. Owen also hands over the fundraiser attendance sheet and Harper's lesson diary, both intact. Three disturbed records now share a number. That is a link worth following, not yet an explanation.  Compare observed visits with the traces on the desk, and keep the identity of any missing document separate from guesses about it.\n\nThe investigator reads the supporting witness accounts before calling on the selected readers:\n\nWitness background for Lydia Vance: Owen Bell saw Lydia Vance enter Harper's classroom at six carrying her green lesson folder. He recognized her name written inside its cover when she left it beside the register. A broad chalk mark on the folder's edge matches the height of the smeared desk; Owen had watched her lean it there while discussing pupil privacy. Her warning was, \"A family record should not become a weapon.\" This explains regular access and a possible source of chalk transfer, but Owen left at seven and cannot account for the classroom overnight.\n\nWitness background for Xander Hale: Owen Bell recalls Harper pointing out Xander Hale's narrow whetstone while the woodworker repaired her drawer rail last Tuesday. Owen saw the stone in a leather sleeve stamped with the workshop's address; he checked that address on the repair invoice. Harper said he \"used to work with blades in another trade\" but did not name it. Owen also saw fresh blue chalk on the woodworker's cuff after measuring the rail with Harper's chalk line. That gives an ordinary source for the cuff mark, not an explanation of the missing page or the earlier blade skills.\n\nWitness background for Marla Quinn: Owen Bell signed for Marla Quinn's six-o'clock bread delivery to Harper on the morning before the death. He recognized the baker's stamped basket and the repaired brass-buckled boots described in Round 1. The delivery docket, signed by Harper, specifies the classroom door rather than the school kitchen. Owen saw the assistant wait while Harper opened the student-record drawer to find payment. This gives a witnessed reason for knowing Harper's schedule and seeing the drawer. Neither the flour on the boots nor that access proves a visit before sunrise on the fatal morning.\n\nWitness background for Jasper Crowe: Owen Bell checked Jasper Crowe's name on the fundraiser attendance sheet at nine the previous evening. He recognized the blue-strapped case and watched the musician leave it beside Harper's desk while stacking chairs. White chalk marked the case corner where it rubbed the desktop, covering part of the pale bakery streak described in Round 1. Owen identifies a source for the transfer and a reason for being in the room. He locked the public school door after the event, but did not remain to watch the classroom's separate yard entrance overnight.\n\nThe host reads the original neighbors' recorded responses:\nXander Hale's recorded response: \"I heard Owen saw Lydia Vance's green folder in Harper's classroom at six, discussing pupil privacy. Its chalk matches the desk height. I worry about access, but Owen left at seven.\"\nMarla Quinn's recorded response: \"I heard Harper said Xander Hale once worked with blades; Owen saw his narrow whetstone during her drawer repair. Chalk explains his cuff mark to me, not missing pages or blade skills.\"\nJasper Crowe's recorded response: \"I read Marla Quinn's signed six-o'clock bread delivery to Harper's classroom door. Owen saw her wait by the open records drawer. I see access, but not a fatal-morning visit.\"\nLydia Vance's recorded response: \"I read Jasper Crowe's nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak. I see how marks transfer, but Owen didn't watch the yard entrance overnight.\"\n\nThe supplied witness accounts support these comparisons:\nNell Reed recorded a chalk smear and narrow drag line through it.\nDella March identified Lydia and the topic of the bakery argument.\nFinn Moss heard a promised parcel requested but saw no handover.\nAda Bell saw the fine stones in an address-stamped sleeve.\nOwen Bell found Harper, locked the classroom and fetched Nell.\nEdith Shaw has not supplied an office account at this stage.\nTown Investigator connected three disturbed records by receipt 47.\nDella's collection of Della's Granddaughter identifies a teacher, not a threat.",
        "publicText": "Harper Wren: throat slashed with the same precise cut. Owen Bell found her; Nell Reed recorded chalk and a drag line beside a disturbed student-record book. Its index cites receipt 47 and a copy kept with an unnamed original order. Attendance and lesson records are intact.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "Before sunrise, caretaker Owen Bell finds senior teacher Harper Wren in her classroom with her throat slashed, the same precise cut again.",
          "Harper taught most of the town's children and kept family records as carefully as lesson plans.",
          "Owen locks the room and fetches Nell Reed."
        ],
        "readingGroups": [
          [
            "xander",
            "marla",
            "jasper"
          ],
          [
            "lydia"
          ]
        ],
        "chain": [
          "xander",
          "marla",
          "jasper",
          "lydia"
        ],
        "coverageRepeat": true
      },
      {
        "title": "Round 4 - Visits and Transferred Marks",
        "narration": "Compare only the findings already read at the bakery, tavern and school. An evening delivery is not a fatal-morning visit; flour, rosin, shellac and chalk have witnessed work-related sources. Receipt 47 links disturbed records but does not yet identify their subject. Correct an accusation that mistakes a work trace or access for a witnessed killing. No new death, name, trade or weapon identification is introduced.",
        "publicText": "Correct earlier inferences using only already released evidence.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "Compare released work traces with the recorded visits.",
          "Correct unsupported accusations without a new discovery."
        ],
        "readingGroups": [
          [
            "xander",
            "jasper",
            "marla"
          ],
          [
            "lydia"
          ]
        ],
        "chain": [
          "xander",
          "jasper",
          "marla",
          "lydia"
        ],
        "coverageRepeat": true
      },
      {
        "title": "Round 5 - The Lamplighter's Murder",
        "narration": "Before the morning market opens, Nell Reed finds Tobias Wick beside an extinguished streetlamp with his throat slashed in the same precise manner. Tobias walked every lane at night and kept route notes about what he saw. Lamp oil has spilled in a perfect circle around the lamp base. Nell records its position before moving the fallen oil flask; the shape of the spill alone cannot identify who was there. A page is torn from Tobias's old route notebook. The surviving index bears receipt 47 and the instruction, \"Retain duplicate with original order.\" Nell gathers the bakery closing-duty sheet, Ronan's appointment book and Harper's lesson diary for comparison with the earlier witness accounts. Their entries can explain a visit or correct a timing assumption, but they are not blanket alibis. The subject of the old records is still missing.  Let each account introduce its own new finding. Then compare the four scenes and ask which traces are ordinary work and which remain unexplained.\n\nThe investigator reads the supporting witness accounts before calling on the selected readers:\n\nWitness background for Marla Quinn: Nell Reed compares Marla Quinn's flour-marked repaired boot from Round 1 with the bakery closing-duty sheet. Elias initialed her nine-o'clock task: scrub the rear threshold, then deliver the waste pail to the market. The entry explains why the crescent heel and flour appeared at the doorway; it is not evidence that the print was made during the killing. Market seller Della March also records that the assistant reported Tobias arguing with an unidentified figure beside the oil stall last night. Della heard the report, not the argument, so she cannot identify that figure.\n\nWitness background for Jasper Crowe: Della March saw Jasper Crowe follow Tobias from the tavern to the market lamp at ten last night. She identified the musician by his blue-strapped case and by the tune he had just played at her stall. Tobias asked him to hold the oil flask while adjusting the wick; Della saw a drop spill onto his right sleeve. The stain therefore has an observed source, not merely an assumed link to lamplighting. Della closed her shutter before Tobias resumed his route. The musician's presence and oil stain establish contact, but not where either man went afterward.\n\nWitness background for Lydia Vance: Nell Reed finds Lydia Vance's warning to Tobias entered in his intact route book: \"Children's family affairs do not belong in street notes.\" The entry describes her green folder and the school gate, where Owen Bell confirms he saw them speak. Nell compares it with Harper's lesson diary, which schedules their weekly meetings to prepare lessons and handle family requests. These sources explain the teacher's meetings and concern about records without supplying an overnight alibi. They do not explain why the older page indexed under receipt 47 was torn out.\n\nWitness background for Xander Hale: Nell Reed saw Xander Hale beneath the workshop lamp yesterday evening, holding a straight razor rather than a woodworking chisel. She recognized him from the shelf-repair invoice she had collected at the tavern and spoke to him face to face. The open blade reflected the lamp; the ivory handle had a triangular chip beside its hinge. He closed it and put it into the address-stamped leather sleeve whose fine stones Ada Bell described in Round 2. Nell can identify the owner, object and distinctive damage, but she did not see an attack. The blade should be compared with the repeated precise cuts, not treated as a confession.\n\nThe host reads the original neighbors' recorded responses:\nXander Hale's recorded response: \"I read Marla Quinn's nine-o'clock closing duty: scrub the rear threshold, then take waste to market. I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone.\"\nMarla Quinn's recorded response: \"I heard Della saw Jasper Crowe follow Tobias to the market lamp at ten. He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward.\"\nJasper Crowe's recorded response: \"I read Lydia Vance's warning to Tobias: children's family affairs don't belong in street notes. Her weekly lesson meetings explain contact to me, not an overnight alibi or receipt 47's torn page.\"\nLydia Vance's recorded response: \"I heard Nell saw Xander Hale's straight razor: ivory handle, triangular chip beside its hinge. It went into his stamped sleeve. I worry about those precise cuts, not a confession.\"\n\nThe supplied witness accounts support these comparisons:\nNell Reed saw the chipped ivory razor enter the stamped sleeve.\nDella March saw Jasper holding the flask before oil spilled on his sleeve.\nFinn Moss left for the delivery cart without witnessing the bakery death.\nAda Bell saw the blue-strapped case on Ronan's counter at ten.\nOwen Bell left at seven without watching the separate yard entrance overnight.\nEdith Shaw has not supplied an office account at this stage.\nTown Investigator preserved the earlier work records for timing comparisons.\nDella's school collection of Della's Granddaughter does not identify a murderer.",
        "publicText": "Tobias Wick: throat slashed with the same precise cut. Nell Reed found him beside an extinguished lamp and a circle of spilled oil. A torn night-route page is indexed under receipt 47. Earlier work and appointment records are ready for comparison, not complete alibis.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "Before the morning market opens, Nell Reed finds Tobias Wick beside an extinguished streetlamp with his throat slashed in the same precise manner.",
          "Tobias walked every lane at night and kept route notes about what he saw.",
          "Lamp oil has spilled in a perfect circle around the lamp base."
        ],
        "readingGroups": [
          [
            "xander",
            "marla",
            "jasper"
          ],
          [
            "lydia"
          ]
        ],
        "chain": [
          "xander",
          "marla",
          "jasper",
          "lydia"
        ],
        "coverageRepeat": true
      },
      {
        "title": "Round 6 - Work Traces and the Identified Tool",
        "narration": "Compare the already released closing-duty sheet, private-appointment records, school visits and Nell's chipped-razor sighting. A work record can explain a trace without supplying an overnight alibi. The identified razor is more specific than an unexplained color or stain, but its sighting is not a confession. Correct earlier accusations based only on flour, chalk or spilled oil. No new death or old identity is introduced.",
        "publicText": "Correct earlier inferences using only already released evidence.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "Compare released work traces with the recorded visits.",
          "Correct unsupported accusations without a new discovery."
        ],
        "readingGroups": [
          [
            "xander",
            "jasper",
            "marla"
          ],
          [
            "lydia"
          ]
        ],
        "chain": [
          "xander",
          "jasper",
          "marla",
          "lydia"
        ],
        "coverageRepeat": true
      },
      {
        "title": "Round 7 - The Mayor's Murder",
        "narration": "Office clerk Edith Shaw finds Mayor Aldric Thorne in his office chair with his throat slashed, the same precise cut. A polished straight razor lies on the desk, its ivory handle chipped beside the hinge. Edith calls Nell Reed and identifies the locked cabinet from which the papers on the desk came; its numbered index and broken wax seal allow the investigator to trace their source. A single old court document, signed by Thorne, orders the imprisonment of BENJAMIN BARKER and bears receipt 47. This is the first time that name enters the investigation. With it are the duplicate records referred to in Harper's index and Tobias's notebook. The investigator reads them aloud: Elias signed a false delivery entry placing Barker at a theft; Ronan signed a fabricated account of a confession; Harper altered a household record to support the charge; Tobias supplied a false night-route sighting. A retained letter from Thorne orders the changes, admits that he wanted Barker's wife and describes using imprisonment to separate them. The household record states that she was taken into Thorne's household under coercion, not by free choice. Barker's licensed occupation is barber. A likeness, address and tool inventory are attached, but the investigator leaves their identification to the witnesses whose accounts you are about to hear. These documents establish the original injustice and the four victims' roles. They do not announce which current neighbor committed the murders.  Hear every account before the final vote.\n\nThe investigator reads the supporting witness accounts before calling on the selected readers:\n\nWitness background for Jasper Crowe: Edith Shaw asks Jasper Crowe to explain a rumor he heard at the tavern about the woodworker once using a different name. He identifies its source as Ronan's remark about an old license, not personal knowledge of the imprisonment. Edith compares the signature on his ten-o'clock drink receipt with the appointment book preserved in Round 2; it confirms his earlier visit, while a separate eleven-o'clock entry admits a private visitor. His rosin flake explains a substance on the counter, but neither the rumor nor the flake identifies that later visitor or makes him a signer of the false statements in the court file.\n\nWitness background for Lydia Vance: Edith Shaw compares Lydia Vance's account of seeing the Mayor hide an old paper with the cabinet index recovered today. The teacher dates the sighting to a school-funding appointment entered in Edith's diary; Edith confirms she admitted her for that appointment and saw Thorne close the folder. The teacher could read receipt 47, but not the name hidden beneath his hand. This explains why the teacher questioned intrusive family records. Her chalk-marked folder and weekly lesson meetings establish access to school papers, not a signature on the falsified statements read from the court file.\n\nWitness background for Xander Hale: Edith Shaw identifies the court file's licensed likeness as Xander Hale; she compares the workshop address printed beside it with the signed shelf-repair invoice preserved in Round 2. The licensed name is Benjamin Barker. The barber's tool inventory describes an ivory razor with a chip beside the hinge, matching the blade Nell Reed saw in his hand in Round 4 and the one now on Thorne's desk. The fine stones and Harper's earlier-trade remark fit the documented occupation. The duplicate records identify the four people who helped Thorne destroy his former life. This joins identity, blade ownership and motive; the room must still decide its final accusation.\n\nWitness background for Marla Quinn: Edith Shaw checks Marla Quinn's account of an old visit by Thorne to the workshop home. The assistant remembers delivering a baker's basket there as a child; the retained delivery copy records the date and the house number. Edith compares those details with Thorne's appointment diary and confirms the visit. The account links a remembered visit to a documented place, but the assistant did not hear the conversation. Her repaired flour-marked boot still fits the closing chore established in Round 4, not a proven killing. Neither her childhood observation nor her recent bread delivery makes her one of the signers identified in the old file.\n\nThe host reads the original neighbors' recorded responses:\nXander Hale's recorded response: \"I heard Jasper Crowe's different-name rumor came from Ronan's old-license remark. His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin.\"\nMarla Quinn's recorded response: \"I learned Lydia Vance saw Thorne hide receipt 47 during her confirmed school-funding appointment. She couldn't read the name. I see why she questioned family records, not proof she falsified them.\"\nJasper Crowe's recorded response: \"I heard Edith match Xander Hale's licensed likeness and workshop address: Benjamin Barker, barber. His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse.\"\nLydia Vance's recorded response: \"I heard Edith confirm Marla Quinn's childhood delivery during Thorne's old workshop-home visit. She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot.\"\n\nThe supplied witness accounts support these comparisons:\nNell Reed identified the damaged razor in the earlier sighting.\nDella March's boot identification established work access, not print timing.\nFinn Moss's case account established an evening visit, not a witnessed murder.\nAda Bell's account left later private visitors possible.\nOwen Bell's accounts did not establish an overnight alibi.\nEdith Shaw matched the licensed likeness and address to Xander.\nTown Investigator read the retained duplicate records and Thorne's letter.\nDella's identification through Della's Granddaughter does not implicate Lydia in the old falsification.",
        "publicText": "Mayor Aldric Thorne: throat slashed; a polished razor with a chipped ivory handle on his desk. Edith Shaw identifies the cabinet and record index. Thorne's signed imprisonment order names Benjamin Barker under receipt 47. Duplicate records and his letter expose the four victims' false statements and his coercion. Witness identification follows in the player readings.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "Office clerk Edith Shaw finds Mayor Aldric Thorne in his office chair with his throat slashed, the same precise cut.",
          "A polished straight razor lies on the desk, its ivory handle chipped beside the hinge.",
          "Edith calls Nell Reed and identifies the locked cabinet from which the papers on the desk came; its numbered index and broken wax seal allow the investigator to trace their source."
        ],
        "readingGroups": [
          [
            "xander",
            "marla",
            "jasper"
          ],
          [
            "lydia"
          ]
        ],
        "chain": [
          "xander",
          "marla",
          "jasper",
          "lydia"
        ],
        "coverageRepeat": true
      }
    ],
    "characters": [
      {
        "id": "xander",
        "name": "Xander Hale",
        "role": "Woodworker",
        "relationship": "A neighbor asked by the town investigator to help compare witness accounts of the Blackwater Row murders.",
        "tieIn": "A quiet craftsperson who repairs furniture and makes wooden fittings in a workshop off the market lane.",
        "optional": false,
        "ghost": null,
        "guest": "",
        "guestNote": "",
        "publicBlurb": "A quiet craftsperson who repairs furniture and makes wooden fittings in a workshop off the market lane.",
        "rounds": [
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I heard Nell saw {marla} leave the bakery's back door at nine with her red-handled brush. Her repaired, flour-packed heel resembles those prints. I still need their timing checked.",
              "observation": "I heard Nell saw {marla} leave the bakery's back door at nine with her red-handled brush.",
              "contradictingDetail": "Her repaired, flour-packed heel resembles those prints. I still need their timing checked."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I heard Ada saw {jasper}'s blue-strapped case on Ronan's counter at ten. His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors.",
              "observation": "I heard Ada saw {jasper}'s blue-strapped case on Ronan's counter at ten.",
              "contradictingDetail": "His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I read {marla}'s signed six-o'clock bread delivery to Harper's classroom door. Owen saw her wait by the open records drawer. I see access, but not a fatal-morning visit.",
              "observation": "I read {marla}'s signed six-o'clock bread delivery to Harper's classroom door.",
              "contradictingDetail": "Owen saw her wait by the open records drawer. I see access, but not a fatal-morning visit."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I heard {jasper}'s case rubbed the chalky desk over its flour streak. I must distinguish transferred work marks from evidence that he removed the student-record page.",
              "observation": "I heard {jasper}'s case rubbed the chalky desk over its flour streak.",
              "contradictingDetail": "I must distinguish transferred work marks from evidence that he removed the student-record page."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I read {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market. I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone.",
              "observation": "I read {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market.",
              "contradictingDetail": "I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I read {jasper}'s visit to the lamp in Della's account. I must not treat spilled oil on his sleeve as proof of a precise cut or an account of his later movements.",
              "observation": "I read {jasper}'s visit to the lamp in Della's account.",
              "contradictingDetail": "I must not treat spilled oil on his sleeve as proof of a precise cut or an account of his later movements."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I heard Edith confirm {marla}'s childhood delivery during Thorne's old workshop-home visit. She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot.",
              "observation": "I heard Edith confirm {marla}'s childhood delivery during Thorne's old workshop-home visit.",
              "contradictingDetail": "She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot."
            }
          }
        ]
      },
      {
        "id": "marla",
        "name": "Marla Quinn",
        "role": "Baker's assistant",
        "relationship": "Assistant to the first victim, the baker Elias Brim; asked to help compare witness accounts.",
        "tieIn": "Elias Brim's assistant, responsible for bread deliveries and the evening cleanup. A familiar face at doorsteps across town.",
        "optional": false,
        "ghost": null,
        "guest": "",
        "guestNote": "",
        "publicBlurb": "Elias Brim's assistant, responsible for bread deliveries and the evening cleanup. A familiar face at doorsteps across town.",
        "rounds": [
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I heard Finn saw {jasper} behind the bakery at nine-thirty with his blue-strapped case. A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave.",
              "observation": "I heard Finn saw {jasper} behind the bakery at nine-thirty with his blue-strapped case.",
              "contradictingDetail": "A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I read {xander}'s shelf invoice; Ada saw fine sharpening stones in his address-stamped sleeve. His repair cloth held amber shellac. I see another possible smear source, not proof he touched that mug.",
              "observation": "I read {xander}'s shelf invoice; Ada saw fine sharpening stones in his address-stamped sleeve.",
              "contradictingDetail": "His repair cloth held amber shellac. I see another possible smear source, not proof he touched that mug."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I read {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak. I see how marks transfer, but Owen didn't watch the yard entrance overnight.",
              "observation": "I read {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak.",
              "contradictingDetail": "I see how marks transfer, but Owen didn't watch the yard entrance overnight."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard {xander}'s drawer repair explained chalk on his cuff. I must not mistake a work mark for an explanation of the missing pages or his earlier blade skills.",
              "observation": "I heard {xander}'s drawer repair explained chalk on his cuff.",
              "contradictingDetail": "I must not mistake a work mark for an explanation of the missing pages or his earlier blade skills."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I heard Della saw {jasper} follow Tobias to the market lamp at ten. He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward.",
              "observation": "I heard Della saw {jasper} follow Tobias to the market lamp at ten.",
              "contradictingDetail": "He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard Nell identify {xander}'s chipped ivory razor. I must compare that identifiable tool with the repeated cuts, not call the sighting a confession.",
              "observation": "I heard Nell identify {xander}'s chipped ivory razor.",
              "contradictingDetail": "I must compare that identifiable tool with the repeated cuts, not call the sighting a confession."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I heard {jasper}'s different-name rumor came from Ronan's old-license remark. His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin.",
              "observation": "I heard {jasper}'s different-name rumor came from Ronan's old-license remark.",
              "contradictingDetail": "His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin."
            }
          }
        ]
      },
      {
        "id": "jasper",
        "name": "Jasper Crowe",
        "role": "Tavern musician",
        "relationship": "Musician at the tavern of the second victim, Ronan Pike; asked to help compare witness accounts.",
        "tieIn": "A musician at Ronan Pike's tavern who also plays for town events. Often out late carrying his instrument between jobs.",
        "optional": false,
        "ghost": null,
        "guest": "",
        "guestNote": "",
        "publicBlurb": "A musician at Ronan Pike's tavern who also plays for town events. Often out late carrying his instrument between jobs.",
        "rounds": [
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard Della saw Elias refuse to enter {xander}'s workshop over an old receipt. He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon.",
              "observation": "I heard Della saw Elias refuse to enter {xander}'s workshop over an old receipt.",
              "contradictingDetail": "He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I heard Della heard {marla} dispute Ronan's flour bill at seven. She showed a receipt and left toward the bakery. I can't confirm payment or a later return.",
              "observation": "I heard Della heard {marla} dispute Ronan's flour bill at seven.",
              "contradictingDetail": "She showed a receipt and left toward the bakery. I can't confirm payment or a later return."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair. Chalk explains his cuff mark to me, not missing pages or blade skills.",
              "observation": "I heard Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair.",
              "contradictingDetail": "Chalk explains his cuff mark to me, not missing pages or blade skills."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I read {marla}'s signed bread delivery at six. I must distinguish an evening delivery from a fatal-morning visit; access alone does not explain the missing page.",
              "observation": "I read {marla}'s signed bread delivery at six.",
              "contradictingDetail": "I must distinguish an evening delivery from a fatal-morning visit; access alone does not explain the missing page."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge. It went into his stamped sleeve. I worry about those precise cuts, not a confession.",
              "observation": "I heard Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge.",
              "contradictingDetail": "It went into his stamped sleeve. I worry about those precise cuts, not a confession."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I read {marla}'s closing duty to scrub the rear threshold. I must correct my earlier suspicion: flour in her repaired heel can come from work, not a witnessed killing.",
              "observation": "I read {marla}'s closing duty to scrub the rear threshold.",
              "contradictingDetail": "I must correct my earlier suspicion: flour in her repaired heel can come from work, not a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard Edith match {xander}'s licensed likeness and workshop address: Benjamin Barker, barber. His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse.",
              "observation": "I heard Edith match {xander}'s licensed likeness and workshop address: Benjamin Barker, barber.",
              "contradictingDetail": "His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse."
            }
          }
        ]
      },
      {
        "id": "lydia",
        "name": "Lydia Vance",
        "role": "Schoolteacher",
        "relationship": "Teacher working alongside the third victim, senior teacher Harper Wren; asked to help compare witness accounts.",
        "tieIn": "A teacher working alongside senior teacher Harper Wren. Attentive to local families and protective of their privacy.",
        "publicBlurb": "A teacher working alongside senior teacher Harper Wren. Attentive to local families and protective of their privacy.",
        "optional": false,
        "guest": "",
        "guestNote": "",
        "ghost": null,
        "rounds": [
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I learned Della saw Elias refuse to enter {xander}'s workshop over an old receipt. He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon.",
              "observation": "I learned Della saw Elias refuse to enter {xander}'s workshop over an old receipt.",
              "contradictingDetail": "He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I learned Della heard {marla} dispute Ronan's flour bill at seven. She showed a receipt and left toward the bakery. I can't confirm payment or a later return.",
              "observation": "I learned Della heard {marla} dispute Ronan's flour bill at seven.",
              "contradictingDetail": "She showed a receipt and left toward the bakery. I can't confirm payment or a later return."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I checked {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak. I see how marks transfer, but Owen didn't watch the yard entrance overnight.",
              "observation": "I checked {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak.",
              "contradictingDetail": "I see how marks transfer, but Owen didn't watch the yard entrance overnight."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I learned Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair. I must correct mistaking a report for a witnessed killing.",
              "observation": "I learned Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair.",
              "contradictingDetail": "I must correct mistaking a report for a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I checked {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market. I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone.",
              "observation": "I checked {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market.",
              "contradictingDetail": "I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I learned Della saw {jasper} follow Tobias to the market lamp at ten. I must correct mistaking a report for a witnessed killing.",
              "observation": "I learned Della saw {jasper} follow Tobias to the market lamp at ten.",
              "contradictingDetail": "I must correct mistaking a report for a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I learned Edith match {xander}'s licensed likeness and workshop address: Benjamin Barker, barber. His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse.",
              "observation": "I learned Edith match {xander}'s licensed likeness and workshop address: Benjamin Barker, barber.",
              "contradictingDetail": "His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse."
            }
          }
        ]
      }
    ],
    "finale": {
      "narration": "All seven chapters and the final witness accounts have now been read. Compare the identified blade, the licensed likeness and address, and the duplicate records with the earlier observations. Decide which neighbor accounts for the complete chain, not just one suspicious trace. A reason for revenge can explain a crime without excusing it. Make your final accusation before the investigator announces the solution.",
      "votePrompt": "Who do you accuse based on the evidence heard so far?"
    },
    "solution": {
      "killerId": "xander",
      "explanation": "Xander Hale is Benjamin Barker, formerly Blackwater Row's trusted barber, and he committed all five murders. Thorne's letter and court file, first read in Round 7, establish that the Mayor wanted Barker's wife, framed him, ordered his imprisonment and forced her into his household. Elias's false delivery entry, Ronan's invented confession, Harper's altered household record and Tobias's false night sighting helped destroy Barker's married life. After release, Barker returned as the woodworker Xander Hale. The fine stones in his address-stamped sleeve and Harper's earlier-trade remark established a blade skill without naming it. Nell's direct observation of the chipped ivory razor in Round 5 supplied identifiable ownership; Edith's Round 7 comparison joined that razor, the licensed likeness and the repair invoice to the old identity. Receipt 47 linked the disturbed records; retained duplicates explained the target selection. Marla's repaired flour-marked boot had a documented closing-chore source. Jasper's case and rosin and Lydia's folder and chalk had witnessed work-related sources; their movements raised questions but did not explain the complete identity, weapon and motive chain. No stain alone proved a killing. Barker killed the four accomplices before reaching his final target, the Mayor. This was deliberate revenge, not justice.",
      "revealNarration": "The investigator closes the court file. \"The killer is {xander}. His former name was Benjamin Barker, and his former trade was barber. Nell identified the damaged razor in his hand; Edith matched the license and address to his current work. The earlier victims supplied the false statements that destroyed his former life. Thorne was his final target.\"\n\nThe host may read Barker's final words: \"Once this town knew me as Benjamin Barker. I had a trade, a wife and a home. Thorne wanted what was not his, and four respectable voices made his lie sound like law. When I returned, I called myself Xander Hale and worked in wood. I thought a new name could bury the old one. Instead I carried it through every door. I chose revenge, and I killed them. It did not restore my wife's freedom or the years we lost. Nothing they did makes these murders right.\"\n\nBlackwater Row must now reckon with both the original injustice and the five deaths that followed."
    },
    "masterPreserving": true,
    "conversion": {
      "source": "Committed four-player Blackwater Row revision 3.",
      "changes": [
        {
          "original": "Five discovery chapters and four playable neighbors.",
          "replacement": "Five unchanged discovery sequences with two intervening comparison chapters and a three-player core.",
          "reason": "Seven-round requirement and smallest-edition master. Identity remains in the last discovery chapter; no murders or facts are added."
        },
        {
          "original": "Per-chapter four-player reader handoffs and twenty player responses.",
          "replacement": "Named recorded responses in shared narration and count-specific group order.",
          "reason": "Preserve every witness source and original response while selecting a three-player loop."
        },
        {
          "original": "Solution timing references to Round 4 and Round 5.",
          "replacement": "Corresponding seven-chapter references to Round 5 and Round 7.",
          "reason": "Inserted comparison rounds shift chapter numbers without advancing evidence."
        }
      ],
      "originalResponses": [
        {
          "id": "xander",
          "rounds": [
            {
              "readAloud": {
                "accuses": "marla",
                "text": "I heard Nell saw {marla} leave the bakery's back door at nine with her red-handled brush. Her repaired, flour-packed heel resembles those prints. I still need their timing checked.",
                "observation": "I heard Nell saw {marla} leave the bakery's back door at nine with her red-handled brush.",
                "contradictingDetail": "Her repaired, flour-packed heel resembles those prints. I still need their timing checked."
              }
            },
            {
              "readAloud": {
                "accuses": "jasper",
                "text": "I heard Ada saw {jasper}'s blue-strapped case on Ronan's counter at ten. His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors.",
                "observation": "I heard Ada saw {jasper}'s blue-strapped case on Ronan's counter at ten.",
                "contradictingDetail": "His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors."
              }
            },
            {
              "readAloud": {
                "accuses": "lydia",
                "text": "I heard Owen saw {lydia}'s green folder in Harper's classroom at six, discussing pupil privacy. Its chalk matches the desk height. I worry about access, but Owen left at seven.",
                "observation": "I heard Owen saw {lydia}'s green folder in Harper's classroom at six, discussing pupil privacy.",
                "contradictingDetail": "Its chalk matches the desk height. I worry about access, but Owen left at seven."
              }
            },
            {
              "readAloud": {
                "accuses": "marla",
                "text": "I read {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market. I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone.",
                "observation": "I read {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market.",
                "contradictingDetail": "I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone."
              }
            },
            {
              "readAloud": {
                "accuses": "jasper",
                "text": "I heard {jasper}'s different-name rumor came from Ronan's old-license remark. His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin.",
                "observation": "I heard {jasper}'s different-name rumor came from Ronan's old-license remark.",
                "contradictingDetail": "His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin."
              }
            }
          ]
        },
        {
          "id": "marla",
          "rounds": [
            {
              "readAloud": {
                "accuses": "jasper",
                "text": "I heard Finn saw {jasper} behind the bakery at nine-thirty with his blue-strapped case. A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave.",
                "observation": "I heard Finn saw {jasper} behind the bakery at nine-thirty with his blue-strapped case.",
                "contradictingDetail": "A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave."
              }
            },
            {
              "readAloud": {
                "accuses": "lydia",
                "text": "I heard Ada heard {lydia} warn Ronan about recording families at eight. She touched his book, leaving possible chalk. I can't prove a removed page or a later return.",
                "observation": "I heard Ada heard {lydia} warn Ronan about recording families at eight.",
                "contradictingDetail": "She touched his book, leaving possible chalk. I can't prove a removed page or a later return."
              }
            },
            {
              "readAloud": {
                "accuses": "xander",
                "text": "I heard Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair. Chalk explains his cuff mark to me, not missing pages or blade skills.",
                "observation": "I heard Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair.",
                "contradictingDetail": "Chalk explains his cuff mark to me, not missing pages or blade skills."
              }
            },
            {
              "readAloud": {
                "accuses": "jasper",
                "text": "I heard Della saw {jasper} follow Tobias to the market lamp at ten. He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward.",
                "observation": "I heard Della saw {jasper} follow Tobias to the market lamp at ten.",
                "contradictingDetail": "He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward."
              }
            },
            {
              "readAloud": {
                "accuses": "lydia",
                "text": "I learned {lydia} saw Thorne hide receipt 47 during her confirmed school-funding appointment. She couldn't read the name. I see why she questioned family records, not proof she falsified them.",
                "observation": "I learned {lydia} saw Thorne hide receipt 47 during her confirmed school-funding appointment.",
                "contradictingDetail": "She couldn't read the name. I see why she questioned family records, not proof she falsified them."
              }
            }
          ]
        },
        {
          "id": "jasper",
          "rounds": [
            {
              "readAloud": {
                "accuses": "lydia",
                "text": "I heard Della saw {lydia} argue with Elias that morning, her green lesson folder tucked under her arm. A bread bill held family history. I wonder why he folded that paper.",
                "observation": "I heard Della saw {lydia} argue with Elias that morning, her green lesson folder tucked under her arm.",
                "contradictingDetail": "A bread bill held family history. I wonder why he folded that paper."
              }
            },
            {
              "readAloud": {
                "accuses": "xander",
                "text": "I read {xander}'s shelf invoice; Ada saw fine sharpening stones in his address-stamped sleeve. His repair cloth held amber shellac. I see another possible smear source, not proof he touched that mug.",
                "observation": "I read {xander}'s shelf invoice; Ada saw fine sharpening stones in his address-stamped sleeve.",
                "contradictingDetail": "His repair cloth held amber shellac. I see another possible smear source, not proof he touched that mug."
              }
            },
            {
              "readAloud": {
                "accuses": "marla",
                "text": "I read {marla}'s signed six-o'clock bread delivery to Harper's classroom door. Owen saw her wait by the open records drawer. I see access, but not a fatal-morning visit.",
                "observation": "I read {marla}'s signed six-o'clock bread delivery to Harper's classroom door.",
                "contradictingDetail": "Owen saw her wait by the open records drawer. I see access, but not a fatal-morning visit."
              }
            },
            {
              "readAloud": {
                "accuses": "lydia",
                "text": "I read {lydia}'s warning to Tobias: children's family affairs don't belong in street notes. Her weekly lesson meetings explain contact to me, not an overnight alibi or receipt 47's torn page.",
                "observation": "I read {lydia}'s warning to Tobias: children's family affairs don't belong in street notes.",
                "contradictingDetail": "Her weekly lesson meetings explain contact to me, not an overnight alibi or receipt 47's torn page."
              }
            },
            {
              "readAloud": {
                "accuses": "xander",
                "text": "I heard Edith match {xander}'s licensed likeness and workshop address: Benjamin Barker, barber. His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse.",
                "observation": "I heard Edith match {xander}'s licensed likeness and workshop address: Benjamin Barker, barber.",
                "contradictingDetail": "His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse."
              }
            }
          ]
        },
        {
          "id": "lydia",
          "rounds": [
            {
              "readAloud": {
                "accuses": "xander",
                "text": "I heard Della saw Elias refuse to enter {xander}'s workshop over an old receipt. He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon.",
                "observation": "I heard Della saw Elias refuse to enter {xander}'s workshop over an old receipt.",
                "contradictingDetail": "He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon."
              }
            },
            {
              "readAloud": {
                "accuses": "marla",
                "text": "I heard Della heard {marla} dispute Ronan's flour bill at seven. She showed a receipt and left toward the bakery. I can't confirm payment or a later return.",
                "observation": "I heard Della heard {marla} dispute Ronan's flour bill at seven.",
                "contradictingDetail": "She showed a receipt and left toward the bakery. I can't confirm payment or a later return."
              }
            },
            {
              "readAloud": {
                "accuses": "jasper",
                "text": "I read {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak. I see how marks transfer, but Owen didn't watch the yard entrance overnight.",
                "observation": "I read {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak.",
                "contradictingDetail": "I see how marks transfer, but Owen didn't watch the yard entrance overnight."
              }
            },
            {
              "readAloud": {
                "accuses": "xander",
                "text": "I heard Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge. It went into his stamped sleeve. I worry about those precise cuts, not a confession.",
                "observation": "I heard Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge.",
                "contradictingDetail": "It went into his stamped sleeve. I worry about those precise cuts, not a confession."
              }
            },
            {
              "readAloud": {
                "accuses": "marla",
                "text": "I heard Edith confirm {marla}'s childhood delivery during Thorne's old workshop-home visit. She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot.",
                "observation": "I heard Edith confirm {marla}'s childhood delivery during Thorne's old workshop-home visit.",
                "contradictingDetail": "She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot."
              }
            }
          ]
        }
      ]
    }
  },
  "5": {
    "schemaVersion": 2,
    "fixedPlayerCount": 5,
    "discloseKiller": false,
    "clueRouting": "rotating",
    "edition": {
      "family": "blackwater-scalable",
      "id": "blackwater-scalable-5-players",
      "playerCount": 5,
      "revision": 1
    },
    "title": "The Barber of Blackwater Row",
    "atmosphere": "victorian",
    "setting": "Blackwater Row, a riverside town of workshops, narrow lanes and gaslit streets in the late nineteenth century.",
    "intro": "Evening settles over Blackwater Row. Three neighbors help the town investigator compare the supplied accounts: Xander Hale, the woodworker; Marla Quinn, the baker's assistant; and Jasper Crowe, the tavern musician. The host reads every recorded witness account before the players respond. Other named people remain in the evidence even when they are not playable. Discuss only the chapter just heard; nobody invents a history, witnesses a new discovery or improvises a private part.",
    "hiddenThread": "Receipt 47 recurs in every victim's disturbed records and finally names the Mayor's old imprisonment order against Benjamin Barker.",
    "coverageRepeatNote": "The trio covers all six directed pairs in the first two rounds. Later repeats add released evidence or explicitly correct an unsupported earlier inference. Each supplemental reader targets every other selected character before repeating, never in consecutive rounds. Separate singleton readings preserve the master loop and evidence timing.",
    "specialMechanics": [
      "Receipt 47 ledger: each murder surfaces another record indexed under receipt 47 (delivery log, tavern scrap, student-record index, night-route page). Compare them across rounds; the Mayor's signed order in Round 7 finally connects the series to the old case."
    ],
    "victim": {
      "name": "Elias Brim",
      "description": "The town baker, known for dependable bread deliveries and careful records."
    },
    "rounds": [
      {
        "title": "Round 1 - The Baker's Murder",
        "narration": "At dawn, delivery porter Finn Moss finds Elias Brim behind his bakery with his throat slashed. The investigator reports one clean, precise cut; the death happened off-screen. Elias supplied nearly every doorstep and recorded deliveries and closing chores in separate books. Finn calls night watchwoman Nell Reed before anyone enters the yard. She records a chain of flour prints from the back door to the wet cobbles. Each right print has a crescent-shaped gap at the heel; the cobbles preserve nothing beyond it. A page is torn from an older delivery log. Its surviving edge carries the date and part of receipt 47, but not a customer name or the purpose of the entry. The closing-duty sheet is intact and is kept for later comparison. These are the findings at this scene, not an identification of the killer. The investigator has collected four separate accounts about the neighbors.  Hear all four before discussing which details establish access and which merely raise suspicion.\n\nThe investigator reads the supporting witness accounts before calling on the selected readers:\n\nWitness background for Marla Quinn: Nell Reed saw Marla Quinn leave the bakery back door at nine, carrying her red-handled scrubbing brush. Nell recognized the brass buckle and crescent-shaped repair in the right heel of her work boots because cobbler Della March had shown her that repair at collection yesterday. Flour was packed into the repaired heel. The shape resembles the yard prints recorded this morning. This ties the boots to bakery work and the doorway, but does not date when each print was made. The closing-duty sheet has not yet been checked against the sighting.\n\nWitness background for Jasper Crowe: Finn Moss saw Jasper Crowe waiting behind the bakery at half past nine, with a blue-strapped instrument case propped against the wall. Finn recognized the musician from the tavern and the case from carrying it after last week's performance. A pale streak ran across its lower corner where it touched a flour sack outside the door. Finn heard him ask Elias for a promised parcel, but did not see a parcel handed over or hear what it contained. Finn left for the delivery cart; he did not witness the death or the musician's departure.\n\nWitness background for Lydia Vance: Della March saw Lydia Vance arguing with Elias at the bakery front counter that morning. She recognized the teacher from collecting her granddaughter from school and saw the same green lesson folder under her arm. Della heard the teacher ask why a bread bill included a household's personal history. Elias folded a paper and refused to answer. The teacher left a chalky thumb mark on the counter when she leaned forward. Della identifies the person and the topic, but heard no threat and never saw the contents of the folded paper.\n\nWitness background for Xander Hale: Della March delivered a wooden chair to Xander Hale's workshop last week and saw Elias at the open door. She recognized both men from their regular work at her market stall. Elias refused to enter and said, \"I will not bring that old receipt here again.\" The woodworker stopped sanding, gripped the chair rail and asked which book Elias meant. Della saw fresh amber shellac on his apron beside the repair cloth, but no weapon. She can identify the reaction and the receipt dispute; she cannot identify the old transaction or turn that reaction into proof of murder.\n\nThe host reads the original neighbors' recorded responses:\nXander Hale's recorded response: \"I heard Nell saw Marla Quinn leave the bakery's back door at nine with her red-handled brush. Her repaired, flour-packed heel resembles those prints. I still need their timing checked.\"\nMarla Quinn's recorded response: \"I heard Finn saw Jasper Crowe behind the bakery at nine-thirty with his blue-strapped case. A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave.\"\nJasper Crowe's recorded response: \"I heard Della saw Lydia Vance argue with Elias that morning, her green lesson folder tucked under her arm. A bread bill held family history. I wonder why he folded that paper.\"\nLydia Vance's recorded response: \"I heard Della saw Elias refuse to enter Xander Hale's workshop over an old receipt. He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon.\"\n\nThe supplied witness accounts support these comparisons:\nNell Reed recorded flour prints with a crescent gap in the right heel.\nDella March recognized the repaired boot from its collection yesterday.\nFinn Moss found Elias and called Nell before anyone entered the yard.\nAda Bell has not supplied a tavern account at this stage.\nOwen Bell has not supplied a classroom account at this stage.\nEdith Shaw has not supplied an office account at this stage.\nTown Investigator reported one precise cut at the bakery.\nDella recognized Lydia through collecting Della's Granddaughter from school.",
        "publicText": "Elias Brim: throat slashed with one precise cut. Finn Moss found the body; Nell Reed recorded flour prints with a crescent gap in the right heel. An old delivery-log page is torn; only receipt 47 survives at its edge. The closing-duty sheet is intact.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "At dawn, delivery porter Finn Moss finds Elias Brim behind his bakery with his throat slashed.",
          "The investigator reports one clean, precise cut; the death happened off-screen.",
          "Elias supplied nearly every doorstep and recorded deliveries and closing chores in separate books."
        ],
        "readingGroups": [
          [
            "xander",
            "marla",
            "jasper"
          ],
          [
            "lydia"
          ],
          [
            "nell"
          ]
        ],
        "chain": [
          "xander",
          "marla",
          "jasper",
          "lydia",
          "nell"
        ],
        "coverageRepeat": false
      },
      {
        "title": "Round 2 - The Barkeep's Murder",
        "narration": "The next morning, cleaner Ada Bell finds Ronan Pike slumped over his tavern counter with his throat slashed. The investigator records the same precise cut as at the bakery. Ronan kept accounts of debts and stayed late for private appointments. Ada does not touch the mug beside him; Nell Reed records that it has been wiped and has no usable fingerprints. A thin amber smear remains beneath its handle. No owner has been established for the mug or the smear. Beneath Ronan's account book lies a scrap bearing receipt 47 and four lines of dates. No names or explanation survive on the scrap. The matching number links two sets of records, but does not identify their subject. Ronan's service tally and appointment book are preserved separately so that the last drink served will not be confused with the last visitor admitted. Four witness accounts are ready.  Listen for who saw an object, how they identified its owner and whether their timing actually reaches the death.\n\nThe investigator reads the supporting witness accounts before calling on the selected readers:\n\nWitness background for Jasper Crowe: Ada Bell saw Jasper Crowe put his instrument case on Ronan's counter at ten and leave after the last public drink was served. She recognized the case by its repaired blue strap, which she had sewn herself. He uses amber rosin on his bow; Ada collected a flake from the spot where the case rested. Its color resembles the smear beneath the wiped mug, but color alone cannot establish that they are the same material. Ronan locked the public door afterward; Ada did not watch the side entrance or the later appointments.\n\nWitness background for Lydia Vance: Ada Bell heard Lydia Vance tell Ronan at eight, \"Those are dangerous notes; people did not give you permission to record their families.\" Ada recognized the green lesson folder under the teacher's arm from her school-cleaning rounds. The teacher tapped Ronan's account book, leaving a white powder trace on its dark cover. Ada collected it as a possible chalk transfer, not a laboratory identification. The warning concerns records, but Ada saw no page removed. The teacher walked out through the public door; Ada could not observe who returned later.\n\nWitness background for Xander Hale: Ronan's repair invoice records Xander Hale replacing the tavern shelf last week. Ada Bell identified him from the signed invoice and saw him open a leather tool sleeve stamped with the same workshop address. Inside were sharpening stones Ronan called \"too fine for woodworking\": one was much narrower and smoother than the broad stone used on the shelf chisel. Ada saw him wipe the sleeve with an amber shellac-stained cloth from his repair kit. That establishes ownership of the stones and a second possible source of amber residue; it does not prove who handled the wiped mug on the night of the murder.\n\nWitness background for Marla Quinn: Della March heard Marla Quinn dispute an unpaid flour bill with Ronan outside the tavern at seven. She recognized the baker's assistant by the stamped delivery basket she was carrying. Ronan held a bill with a torn lower corner; the assistant produced a coin receipt, but Della was too far away to compare its amount. She saw the assistant leave with the basket toward the bakery. The argument supplies a specific grievance and an observed departure, not proof of payment or a witnessed return to the counter where Ronan died.\n\nThe host reads the original neighbors' recorded responses:\nXander Hale's recorded response: \"I heard Ada saw Jasper Crowe's blue-strapped case on Ronan's counter at ten. His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors.\"\nMarla Quinn's recorded response: \"I heard Ada heard Lydia Vance warn Ronan about recording families at eight. She touched his book, leaving possible chalk. I can't prove a removed page or a later return.\"\nJasper Crowe's recorded response: \"I read Xander Hale's shelf invoice; Ada saw fine sharpening stones in his address-stamped sleeve. His repair cloth held amber shellac. I see another possible smear source, not proof he touched that mug.\"\nLydia Vance's recorded response: \"I heard Della heard Marla Quinn dispute Ronan's flour bill at seven. She showed a receipt and left toward the bakery. I can't confirm payment or a later return.\"\n\nThe supplied witness accounts support these comparisons:\nNell Reed recorded a wiped mug without usable fingerprints.\nDella March heard Marla dispute the flour bill and leave toward the bakery.\nFinn Moss did not witness the bakery death or the musician leaving.\nAda Bell found Ronan and left the mug untouched.\nOwen Bell has not supplied a classroom account at this stage.\nEdith Shaw has not supplied an office account at this stage.\nTown Investigator reported the same precise cut at the tavern.\nDella's school collection of Della's Granddaughter explains her recognition of Lydia.",
        "publicText": "Ronan Pike: throat slashed with the same precise cut. Ada Bell found him. A wiped mug has no usable fingerprints and an unidentified amber smear beneath its handle. A dated scrap bears receipt 47 but no names. Service and appointment records are preserved.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "The next morning, cleaner Ada Bell finds Ronan Pike slumped over his tavern counter with his throat slashed.",
          "The investigator records the same precise cut as at the bakery.",
          "Ronan kept accounts of debts and stayed late for private appointments."
        ],
        "readingGroups": [
          [
            "xander",
            "jasper",
            "marla"
          ],
          [
            "lydia"
          ],
          [
            "nell"
          ]
        ],
        "chain": [
          "xander",
          "jasper",
          "marla",
          "lydia",
          "nell"
        ],
        "coverageRepeat": false
      },
      {
        "title": "Round 3 - The Schoolteacher's Murder",
        "narration": "Before sunrise, caretaker Owen Bell finds senior teacher Harper Wren in her classroom with her throat slashed, the same precise cut again. Harper taught most of the town's children and kept family records as carefully as lesson plans. Owen locks the room and fetches Nell Reed. She records a broad chalk smear across the desk and a narrow drag line through it, running from the student-record book toward its open drawer. A page is missing from that book. Its remaining index cites receipt 47; a margin note says, \"Copy kept with the original order.\" Neither the order's owner nor its location is recorded here. Owen also hands over the fundraiser attendance sheet and Harper's lesson diary, both intact. Three disturbed records now share a number. That is a link worth following, not yet an explanation.  Compare observed visits with the traces on the desk, and keep the identity of any missing document separate from guesses about it.\n\nThe investigator reads the supporting witness accounts before calling on the selected readers:\n\nWitness background for Lydia Vance: Owen Bell saw Lydia Vance enter Harper's classroom at six carrying her green lesson folder. He recognized her name written inside its cover when she left it beside the register. A broad chalk mark on the folder's edge matches the height of the smeared desk; Owen had watched her lean it there while discussing pupil privacy. Her warning was, \"A family record should not become a weapon.\" This explains regular access and a possible source of chalk transfer, but Owen left at seven and cannot account for the classroom overnight.\n\nWitness background for Xander Hale: Owen Bell recalls Harper pointing out Xander Hale's narrow whetstone while the woodworker repaired her drawer rail last Tuesday. Owen saw the stone in a leather sleeve stamped with the workshop's address; he checked that address on the repair invoice. Harper said he \"used to work with blades in another trade\" but did not name it. Owen also saw fresh blue chalk on the woodworker's cuff after measuring the rail with Harper's chalk line. That gives an ordinary source for the cuff mark, not an explanation of the missing page or the earlier blade skills.\n\nWitness background for Marla Quinn: Owen Bell signed for Marla Quinn's six-o'clock bread delivery to Harper on the morning before the death. He recognized the baker's stamped basket and the repaired brass-buckled boots described in Round 1. The delivery docket, signed by Harper, specifies the classroom door rather than the school kitchen. Owen saw the assistant wait while Harper opened the student-record drawer to find payment. This gives a witnessed reason for knowing Harper's schedule and seeing the drawer. Neither the flour on the boots nor that access proves a visit before sunrise on the fatal morning.\n\nWitness background for Jasper Crowe: Owen Bell checked Jasper Crowe's name on the fundraiser attendance sheet at nine the previous evening. He recognized the blue-strapped case and watched the musician leave it beside Harper's desk while stacking chairs. White chalk marked the case corner where it rubbed the desktop, covering part of the pale bakery streak described in Round 1. Owen identifies a source for the transfer and a reason for being in the room. He locked the public school door after the event, but did not remain to watch the classroom's separate yard entrance overnight.\n\nThe host reads the original neighbors' recorded responses:\nXander Hale's recorded response: \"I heard Owen saw Lydia Vance's green folder in Harper's classroom at six, discussing pupil privacy. Its chalk matches the desk height. I worry about access, but Owen left at seven.\"\nMarla Quinn's recorded response: \"I heard Harper said Xander Hale once worked with blades; Owen saw his narrow whetstone during her drawer repair. Chalk explains his cuff mark to me, not missing pages or blade skills.\"\nJasper Crowe's recorded response: \"I read Marla Quinn's signed six-o'clock bread delivery to Harper's classroom door. Owen saw her wait by the open records drawer. I see access, but not a fatal-morning visit.\"\nLydia Vance's recorded response: \"I read Jasper Crowe's nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak. I see how marks transfer, but Owen didn't watch the yard entrance overnight.\"\n\nThe supplied witness accounts support these comparisons:\nNell Reed recorded a chalk smear and narrow drag line through it.\nDella March identified Lydia and the topic of the bakery argument.\nFinn Moss heard a promised parcel requested but saw no handover.\nAda Bell saw the fine stones in an address-stamped sleeve.\nOwen Bell found Harper, locked the classroom and fetched Nell.\nEdith Shaw has not supplied an office account at this stage.\nTown Investigator connected three disturbed records by receipt 47.\nDella's collection of Della's Granddaughter identifies a teacher, not a threat.",
        "publicText": "Harper Wren: throat slashed with the same precise cut. Owen Bell found her; Nell Reed recorded chalk and a drag line beside a disturbed student-record book. Its index cites receipt 47 and a copy kept with an unnamed original order. Attendance and lesson records are intact.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "Before sunrise, caretaker Owen Bell finds senior teacher Harper Wren in her classroom with her throat slashed, the same precise cut again.",
          "Harper taught most of the town's children and kept family records as carefully as lesson plans.",
          "Owen locks the room and fetches Nell Reed."
        ],
        "readingGroups": [
          [
            "xander",
            "marla",
            "jasper"
          ],
          [
            "lydia"
          ],
          [
            "nell"
          ]
        ],
        "chain": [
          "xander",
          "marla",
          "jasper",
          "lydia",
          "nell"
        ],
        "coverageRepeat": true
      },
      {
        "title": "Round 4 - Visits and Transferred Marks",
        "narration": "Compare only the findings already read at the bakery, tavern and school. An evening delivery is not a fatal-morning visit; flour, rosin, shellac and chalk have witnessed work-related sources. Receipt 47 links disturbed records but does not yet identify their subject. Correct an accusation that mistakes a work trace or access for a witnessed killing. No new death, name, trade or weapon identification is introduced.",
        "publicText": "Correct earlier inferences using only already released evidence.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "Compare released work traces with the recorded visits.",
          "Correct unsupported accusations without a new discovery."
        ],
        "readingGroups": [
          [
            "xander",
            "jasper",
            "marla"
          ],
          [
            "lydia"
          ],
          [
            "nell"
          ]
        ],
        "chain": [
          "xander",
          "jasper",
          "marla",
          "lydia",
          "nell"
        ],
        "coverageRepeat": true
      },
      {
        "title": "Round 5 - The Lamplighter's Murder",
        "narration": "Before the morning market opens, Nell Reed finds Tobias Wick beside an extinguished streetlamp with his throat slashed in the same precise manner. Tobias walked every lane at night and kept route notes about what he saw. Lamp oil has spilled in a perfect circle around the lamp base. Nell records its position before moving the fallen oil flask; the shape of the spill alone cannot identify who was there. A page is torn from Tobias's old route notebook. The surviving index bears receipt 47 and the instruction, \"Retain duplicate with original order.\" Nell gathers the bakery closing-duty sheet, Ronan's appointment book and Harper's lesson diary for comparison with the earlier witness accounts. Their entries can explain a visit or correct a timing assumption, but they are not blanket alibis. The subject of the old records is still missing.  Let each account introduce its own new finding. Then compare the four scenes and ask which traces are ordinary work and which remain unexplained.\n\nThe investigator reads the supporting witness accounts before calling on the selected readers:\n\nWitness background for Marla Quinn: Nell Reed compares Marla Quinn's flour-marked repaired boot from Round 1 with the bakery closing-duty sheet. Elias initialed her nine-o'clock task: scrub the rear threshold, then deliver the waste pail to the market. The entry explains why the crescent heel and flour appeared at the doorway; it is not evidence that the print was made during the killing. Market seller Della March also records that the assistant reported Tobias arguing with an unidentified figure beside the oil stall last night. Della heard the report, not the argument, so she cannot identify that figure.\n\nWitness background for Jasper Crowe: Della March saw Jasper Crowe follow Tobias from the tavern to the market lamp at ten last night. She identified the musician by his blue-strapped case and by the tune he had just played at her stall. Tobias asked him to hold the oil flask while adjusting the wick; Della saw a drop spill onto his right sleeve. The stain therefore has an observed source, not merely an assumed link to lamplighting. Della closed her shutter before Tobias resumed his route. The musician's presence and oil stain establish contact, but not where either man went afterward.\n\nWitness background for Lydia Vance: Nell Reed finds Lydia Vance's warning to Tobias entered in his intact route book: \"Children's family affairs do not belong in street notes.\" The entry describes her green folder and the school gate, where Owen Bell confirms he saw them speak. Nell compares it with Harper's lesson diary, which schedules their weekly meetings to prepare lessons and handle family requests. These sources explain the teacher's meetings and concern about records without supplying an overnight alibi. They do not explain why the older page indexed under receipt 47 was torn out.\n\nWitness background for Xander Hale: Nell Reed saw Xander Hale beneath the workshop lamp yesterday evening, holding a straight razor rather than a woodworking chisel. She recognized him from the shelf-repair invoice she had collected at the tavern and spoke to him face to face. The open blade reflected the lamp; the ivory handle had a triangular chip beside its hinge. He closed it and put it into the address-stamped leather sleeve whose fine stones Ada Bell described in Round 2. Nell can identify the owner, object and distinctive damage, but she did not see an attack. The blade should be compared with the repeated precise cuts, not treated as a confession.\n\nThe host reads the original neighbors' recorded responses:\nXander Hale's recorded response: \"I read Marla Quinn's nine-o'clock closing duty: scrub the rear threshold, then take waste to market. I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone.\"\nMarla Quinn's recorded response: \"I heard Della saw Jasper Crowe follow Tobias to the market lamp at ten. He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward.\"\nJasper Crowe's recorded response: \"I read Lydia Vance's warning to Tobias: children's family affairs don't belong in street notes. Her weekly lesson meetings explain contact to me, not an overnight alibi or receipt 47's torn page.\"\nLydia Vance's recorded response: \"I heard Nell saw Xander Hale's straight razor: ivory handle, triangular chip beside its hinge. It went into his stamped sleeve. I worry about those precise cuts, not a confession.\"\n\nThe supplied witness accounts support these comparisons:\nNell Reed saw the chipped ivory razor enter the stamped sleeve.\nDella March saw Jasper holding the flask before oil spilled on his sleeve.\nFinn Moss left for the delivery cart without witnessing the bakery death.\nAda Bell saw the blue-strapped case on Ronan's counter at ten.\nOwen Bell left at seven without watching the separate yard entrance overnight.\nEdith Shaw has not supplied an office account at this stage.\nTown Investigator preserved the earlier work records for timing comparisons.\nDella's school collection of Della's Granddaughter does not identify a murderer.",
        "publicText": "Tobias Wick: throat slashed with the same precise cut. Nell Reed found him beside an extinguished lamp and a circle of spilled oil. A torn night-route page is indexed under receipt 47. Earlier work and appointment records are ready for comparison, not complete alibis.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "Before the morning market opens, Nell Reed finds Tobias Wick beside an extinguished streetlamp with his throat slashed in the same precise manner.",
          "Tobias walked every lane at night and kept route notes about what he saw.",
          "Lamp oil has spilled in a perfect circle around the lamp base."
        ],
        "readingGroups": [
          [
            "xander",
            "marla",
            "jasper"
          ],
          [
            "lydia"
          ],
          [
            "nell"
          ]
        ],
        "chain": [
          "xander",
          "marla",
          "jasper",
          "lydia",
          "nell"
        ],
        "coverageRepeat": true
      },
      {
        "title": "Round 6 - Work Traces and the Identified Tool",
        "narration": "Compare the already released closing-duty sheet, private-appointment records, school visits and Nell's chipped-razor sighting. A work record can explain a trace without supplying an overnight alibi. The identified razor is more specific than an unexplained color or stain, but its sighting is not a confession. Correct earlier accusations based only on flour, chalk or spilled oil. No new death or old identity is introduced.",
        "publicText": "Correct earlier inferences using only already released evidence.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "Compare released work traces with the recorded visits.",
          "Correct unsupported accusations without a new discovery."
        ],
        "readingGroups": [
          [
            "xander",
            "jasper",
            "marla"
          ],
          [
            "lydia"
          ],
          [
            "nell"
          ]
        ],
        "chain": [
          "xander",
          "jasper",
          "marla",
          "lydia",
          "nell"
        ],
        "coverageRepeat": true
      },
      {
        "title": "Round 7 - The Mayor's Murder",
        "narration": "Office clerk Edith Shaw finds Mayor Aldric Thorne in his office chair with his throat slashed, the same precise cut. A polished straight razor lies on the desk, its ivory handle chipped beside the hinge. Edith calls Nell Reed and identifies the locked cabinet from which the papers on the desk came; its numbered index and broken wax seal allow the investigator to trace their source. A single old court document, signed by Thorne, orders the imprisonment of BENJAMIN BARKER and bears receipt 47. This is the first time that name enters the investigation. With it are the duplicate records referred to in Harper's index and Tobias's notebook. The investigator reads them aloud: Elias signed a false delivery entry placing Barker at a theft; Ronan signed a fabricated account of a confession; Harper altered a household record to support the charge; Tobias supplied a false night-route sighting. A retained letter from Thorne orders the changes, admits that he wanted Barker's wife and describes using imprisonment to separate them. The household record states that she was taken into Thorne's household under coercion, not by free choice. Barker's licensed occupation is barber. A likeness, address and tool inventory are attached, but the investigator leaves their identification to the witnesses whose accounts you are about to hear. These documents establish the original injustice and the four victims' roles. They do not announce which current neighbor committed the murders.  Hear every account before the final vote.\n\nThe investigator reads the supporting witness accounts before calling on the selected readers:\n\nWitness background for Jasper Crowe: Edith Shaw asks Jasper Crowe to explain a rumor he heard at the tavern about the woodworker once using a different name. He identifies its source as Ronan's remark about an old license, not personal knowledge of the imprisonment. Edith compares the signature on his ten-o'clock drink receipt with the appointment book preserved in Round 2; it confirms his earlier visit, while a separate eleven-o'clock entry admits a private visitor. His rosin flake explains a substance on the counter, but neither the rumor nor the flake identifies that later visitor or makes him a signer of the false statements in the court file.\n\nWitness background for Lydia Vance: Edith Shaw compares Lydia Vance's account of seeing the Mayor hide an old paper with the cabinet index recovered today. The teacher dates the sighting to a school-funding appointment entered in Edith's diary; Edith confirms she admitted her for that appointment and saw Thorne close the folder. The teacher could read receipt 47, but not the name hidden beneath his hand. This explains why the teacher questioned intrusive family records. Her chalk-marked folder and weekly lesson meetings establish access to school papers, not a signature on the falsified statements read from the court file.\n\nWitness background for Xander Hale: Edith Shaw identifies the court file's licensed likeness as Xander Hale; she compares the workshop address printed beside it with the signed shelf-repair invoice preserved in Round 2. The licensed name is Benjamin Barker. The barber's tool inventory describes an ivory razor with a chip beside the hinge, matching the blade Nell Reed saw in his hand in Round 4 and the one now on Thorne's desk. The fine stones and Harper's earlier-trade remark fit the documented occupation. The duplicate records identify the four people who helped Thorne destroy his former life. This joins identity, blade ownership and motive; the room must still decide its final accusation.\n\nWitness background for Marla Quinn: Edith Shaw checks Marla Quinn's account of an old visit by Thorne to the workshop home. The assistant remembers delivering a baker's basket there as a child; the retained delivery copy records the date and the house number. Edith compares those details with Thorne's appointment diary and confirms the visit. The account links a remembered visit to a documented place, but the assistant did not hear the conversation. Her repaired flour-marked boot still fits the closing chore established in Round 4, not a proven killing. Neither her childhood observation nor her recent bread delivery makes her one of the signers identified in the old file.\n\nThe host reads the original neighbors' recorded responses:\nXander Hale's recorded response: \"I heard Jasper Crowe's different-name rumor came from Ronan's old-license remark. His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin.\"\nMarla Quinn's recorded response: \"I learned Lydia Vance saw Thorne hide receipt 47 during her confirmed school-funding appointment. She couldn't read the name. I see why she questioned family records, not proof she falsified them.\"\nJasper Crowe's recorded response: \"I heard Edith match Xander Hale's licensed likeness and workshop address: Benjamin Barker, barber. His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse.\"\nLydia Vance's recorded response: \"I heard Edith confirm Marla Quinn's childhood delivery during Thorne's old workshop-home visit. She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot.\"\n\nThe supplied witness accounts support these comparisons:\nNell Reed identified the damaged razor in the earlier sighting.\nDella March's boot identification established work access, not print timing.\nFinn Moss's case account established an evening visit, not a witnessed murder.\nAda Bell's account left later private visitors possible.\nOwen Bell's accounts did not establish an overnight alibi.\nEdith Shaw matched the licensed likeness and address to Xander.\nTown Investigator read the retained duplicate records and Thorne's letter.\nDella's identification through Della's Granddaughter does not implicate Lydia in the old falsification.",
        "publicText": "Mayor Aldric Thorne: throat slashed; a polished razor with a chipped ivory handle on his desk. Edith Shaw identifies the cabinet and record index. Thorne's signed imprisonment order names Benjamin Barker under receipt 47. Duplicate records and his letter expose the four victims' false statements and his coercion. Witness identification follows in the player readings.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "Office clerk Edith Shaw finds Mayor Aldric Thorne in his office chair with his throat slashed, the same precise cut.",
          "A polished straight razor lies on the desk, its ivory handle chipped beside the hinge.",
          "Edith calls Nell Reed and identifies the locked cabinet from which the papers on the desk came; its numbered index and broken wax seal allow the investigator to trace their source."
        ],
        "readingGroups": [
          [
            "xander",
            "marla",
            "jasper"
          ],
          [
            "lydia"
          ],
          [
            "nell"
          ]
        ],
        "chain": [
          "xander",
          "marla",
          "jasper",
          "lydia",
          "nell"
        ],
        "coverageRepeat": true
      }
    ],
    "characters": [
      {
        "id": "xander",
        "name": "Xander Hale",
        "role": "Woodworker",
        "relationship": "A neighbor asked by the town investigator to help compare witness accounts of the Blackwater Row murders.",
        "tieIn": "A quiet craftsperson who repairs furniture and makes wooden fittings in a workshop off the market lane.",
        "optional": false,
        "ghost": null,
        "guest": "",
        "guestNote": "",
        "publicBlurb": "A quiet craftsperson who repairs furniture and makes wooden fittings in a workshop off the market lane.",
        "rounds": [
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I heard Nell saw {marla} leave the bakery's back door at nine with her red-handled brush. Her repaired, flour-packed heel resembles those prints. I still need their timing checked.",
              "observation": "I heard Nell saw {marla} leave the bakery's back door at nine with her red-handled brush.",
              "contradictingDetail": "Her repaired, flour-packed heel resembles those prints. I still need their timing checked."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I heard Ada saw {jasper}'s blue-strapped case on Ronan's counter at ten. His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors.",
              "observation": "I heard Ada saw {jasper}'s blue-strapped case on Ronan's counter at ten.",
              "contradictingDetail": "His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I read {marla}'s signed six-o'clock bread delivery to Harper's classroom door. Owen saw her wait by the open records drawer. I see access, but not a fatal-morning visit.",
              "observation": "I read {marla}'s signed six-o'clock bread delivery to Harper's classroom door.",
              "contradictingDetail": "Owen saw her wait by the open records drawer. I see access, but not a fatal-morning visit."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I heard {jasper}'s case rubbed the chalky desk over its flour streak. I must distinguish transferred work marks from evidence that he removed the student-record page.",
              "observation": "I heard {jasper}'s case rubbed the chalky desk over its flour streak.",
              "contradictingDetail": "I must distinguish transferred work marks from evidence that he removed the student-record page."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I read {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market. I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone.",
              "observation": "I read {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market.",
              "contradictingDetail": "I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I read {jasper}'s visit to the lamp in Della's account. I must not treat spilled oil on his sleeve as proof of a precise cut or an account of his later movements.",
              "observation": "I read {jasper}'s visit to the lamp in Della's account.",
              "contradictingDetail": "I must not treat spilled oil on his sleeve as proof of a precise cut or an account of his later movements."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I heard Edith confirm {marla}'s childhood delivery during Thorne's old workshop-home visit. She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot.",
              "observation": "I heard Edith confirm {marla}'s childhood delivery during Thorne's old workshop-home visit.",
              "contradictingDetail": "She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot."
            }
          }
        ]
      },
      {
        "id": "marla",
        "name": "Marla Quinn",
        "role": "Baker's assistant",
        "relationship": "Assistant to the first victim, the baker Elias Brim; asked to help compare witness accounts.",
        "tieIn": "Elias Brim's assistant, responsible for bread deliveries and the evening cleanup. A familiar face at doorsteps across town.",
        "optional": false,
        "ghost": null,
        "guest": "",
        "guestNote": "",
        "publicBlurb": "Elias Brim's assistant, responsible for bread deliveries and the evening cleanup. A familiar face at doorsteps across town.",
        "rounds": [
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I heard Finn saw {jasper} behind the bakery at nine-thirty with his blue-strapped case. A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave.",
              "observation": "I heard Finn saw {jasper} behind the bakery at nine-thirty with his blue-strapped case.",
              "contradictingDetail": "A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I read {xander}'s shelf invoice; Ada saw fine sharpening stones in his address-stamped sleeve. His repair cloth held amber shellac. I see another possible smear source, not proof he touched that mug.",
              "observation": "I read {xander}'s shelf invoice; Ada saw fine sharpening stones in his address-stamped sleeve.",
              "contradictingDetail": "His repair cloth held amber shellac. I see another possible smear source, not proof he touched that mug."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I read {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak. I see how marks transfer, but Owen didn't watch the yard entrance overnight.",
              "observation": "I read {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak.",
              "contradictingDetail": "I see how marks transfer, but Owen didn't watch the yard entrance overnight."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard {xander}'s drawer repair explained chalk on his cuff. I must not mistake a work mark for an explanation of the missing pages or his earlier blade skills.",
              "observation": "I heard {xander}'s drawer repair explained chalk on his cuff.",
              "contradictingDetail": "I must not mistake a work mark for an explanation of the missing pages or his earlier blade skills."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I heard Della saw {jasper} follow Tobias to the market lamp at ten. He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward.",
              "observation": "I heard Della saw {jasper} follow Tobias to the market lamp at ten.",
              "contradictingDetail": "He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard Nell identify {xander}'s chipped ivory razor. I must compare that identifiable tool with the repeated cuts, not call the sighting a confession.",
              "observation": "I heard Nell identify {xander}'s chipped ivory razor.",
              "contradictingDetail": "I must compare that identifiable tool with the repeated cuts, not call the sighting a confession."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I heard {jasper}'s different-name rumor came from Ronan's old-license remark. His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin.",
              "observation": "I heard {jasper}'s different-name rumor came from Ronan's old-license remark.",
              "contradictingDetail": "His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin."
            }
          }
        ]
      },
      {
        "id": "jasper",
        "name": "Jasper Crowe",
        "role": "Tavern musician",
        "relationship": "Musician at the tavern of the second victim, Ronan Pike; asked to help compare witness accounts.",
        "tieIn": "A musician at Ronan Pike's tavern who also plays for town events. Often out late carrying his instrument between jobs.",
        "optional": false,
        "ghost": null,
        "guest": "",
        "guestNote": "",
        "publicBlurb": "A musician at Ronan Pike's tavern who also plays for town events. Often out late carrying his instrument between jobs.",
        "rounds": [
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard Della saw Elias refuse to enter {xander}'s workshop over an old receipt. He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon.",
              "observation": "I heard Della saw Elias refuse to enter {xander}'s workshop over an old receipt.",
              "contradictingDetail": "He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I heard Della heard {marla} dispute Ronan's flour bill at seven. She showed a receipt and left toward the bakery. I can't confirm payment or a later return.",
              "observation": "I heard Della heard {marla} dispute Ronan's flour bill at seven.",
              "contradictingDetail": "She showed a receipt and left toward the bakery. I can't confirm payment or a later return."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair. Chalk explains his cuff mark to me, not missing pages or blade skills.",
              "observation": "I heard Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair.",
              "contradictingDetail": "Chalk explains his cuff mark to me, not missing pages or blade skills."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I read {marla}'s signed bread delivery at six. I must distinguish an evening delivery from a fatal-morning visit; access alone does not explain the missing page.",
              "observation": "I read {marla}'s signed bread delivery at six.",
              "contradictingDetail": "I must distinguish an evening delivery from a fatal-morning visit; access alone does not explain the missing page."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge. It went into his stamped sleeve. I worry about those precise cuts, not a confession.",
              "observation": "I heard Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge.",
              "contradictingDetail": "It went into his stamped sleeve. I worry about those precise cuts, not a confession."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I read {marla}'s closing duty to scrub the rear threshold. I must correct my earlier suspicion: flour in her repaired heel can come from work, not a witnessed killing.",
              "observation": "I read {marla}'s closing duty to scrub the rear threshold.",
              "contradictingDetail": "I must correct my earlier suspicion: flour in her repaired heel can come from work, not a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard Edith match {xander}'s licensed likeness and workshop address: Benjamin Barker, barber. His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse.",
              "observation": "I heard Edith match {xander}'s licensed likeness and workshop address: Benjamin Barker, barber.",
              "contradictingDetail": "His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse."
            }
          }
        ]
      },
      {
        "id": "lydia",
        "name": "Lydia Vance",
        "role": "Schoolteacher",
        "relationship": "Teacher working alongside the third victim, senior teacher Harper Wren; asked to help compare witness accounts.",
        "tieIn": "A teacher working alongside senior teacher Harper Wren. Attentive to local families and protective of their privacy.",
        "publicBlurb": "A teacher working alongside senior teacher Harper Wren. Attentive to local families and protective of their privacy.",
        "optional": false,
        "guest": "",
        "guestNote": "",
        "ghost": null,
        "rounds": [
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I learned Della saw Elias refuse to enter {xander}'s workshop over an old receipt. He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon.",
              "observation": "I learned Della saw Elias refuse to enter {xander}'s workshop over an old receipt.",
              "contradictingDetail": "He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I learned Della heard {marla} dispute Ronan's flour bill at seven. She showed a receipt and left toward the bakery. I can't confirm payment or a later return.",
              "observation": "I learned Della heard {marla} dispute Ronan's flour bill at seven.",
              "contradictingDetail": "She showed a receipt and left toward the bakery. I can't confirm payment or a later return."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I checked {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak. I see how marks transfer, but Owen didn't watch the yard entrance overnight.",
              "observation": "I checked {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak.",
              "contradictingDetail": "I see how marks transfer, but Owen didn't watch the yard entrance overnight."
            }
          },
          {
            "readAloud": {
              "accuses": "nell",
              "text": "I heard the account: {nell} recorded a chalk smear and narrow drag line through it. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: {nell} recorded a chalk smear and narrow drag line through it.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I learned Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge. It went into his stamped sleeve. I worry about those precise cuts, not a confession.",
              "observation": "I learned Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge.",
              "contradictingDetail": "It went into his stamped sleeve. I worry about those precise cuts, not a confession."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I checked {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market. I must correct mistaking a report for a witnessed killing.",
              "observation": "I checked {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market.",
              "contradictingDetail": "I must correct mistaking a report for a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I learned {jasper}'s different-name rumor came from Ronan's old-license remark. His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin.",
              "observation": "I learned {jasper}'s different-name rumor came from Ronan's old-license remark.",
              "contradictingDetail": "His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin."
            }
          }
        ]
      },
      {
        "id": "nell",
        "name": "Nell Reed",
        "role": "Night watchwoman",
        "relationship": "An existing person in the supplied Blackwater Row accounts.",
        "tieIn": "Records the scene findings and supplies the razor sighting.",
        "publicBlurb": "Records the scene findings and supplies the razor sighting.",
        "optional": false,
        "guest": "",
        "guestNote": "",
        "ghost": null,
        "rounds": [
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I learned Nell saw {marla} leave the bakery's back door at nine with her red-handled brush. Her repaired, flour-packed heel resembles those prints. I still need their timing checked.",
              "observation": "I learned Nell saw {marla} leave the bakery's back door at nine with her red-handled brush.",
              "contradictingDetail": "Her repaired, flour-packed heel resembles those prints. I still need their timing checked."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I learned Ada saw {jasper}'s blue-strapped case on Ronan's counter at ten. His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors.",
              "observation": "I learned Ada saw {jasper}'s blue-strapped case on Ronan's counter at ten.",
              "contradictingDetail": "His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors."
            }
          },
          {
            "readAloud": {
              "accuses": "lydia",
              "text": "I learned Owen saw {lydia}'s green folder in Harper's classroom at six, discussing pupil privacy. Its chalk matches the desk height. I worry about access, but Owen left at seven.",
              "observation": "I learned Owen saw {lydia}'s green folder in Harper's classroom at six, discussing pupil privacy.",
              "contradictingDetail": "Its chalk matches the desk height. I worry about access, but Owen left at seven."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I learned Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair. Chalk explains his cuff mark to me, not missing pages or blade skills.",
              "observation": "I learned Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair.",
              "contradictingDetail": "Chalk explains his cuff mark to me, not missing pages or blade skills."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I checked {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market. I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone.",
              "observation": "I checked {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market.",
              "contradictingDetail": "I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I learned Della saw {jasper} follow Tobias to the market lamp at ten. I must correct mistaking a report for a witnessed killing.",
              "observation": "I learned Della saw {jasper} follow Tobias to the market lamp at ten.",
              "contradictingDetail": "I must correct mistaking a report for a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "lydia",
              "text": "I heard {lydia} saw Thorne hide receipt 47 during her confirmed school-funding appointment. She couldn't read the name. I see why she questioned family records, not proof she falsified them.",
              "observation": "I heard {lydia} saw Thorne hide receipt 47 during her confirmed school-funding appointment.",
              "contradictingDetail": "She couldn't read the name. I see why she questioned family records, not proof she falsified them."
            }
          }
        ]
      }
    ],
    "finale": {
      "narration": "All seven chapters and the final witness accounts have now been read. Compare the identified blade, the licensed likeness and address, and the duplicate records with the earlier observations. Decide which neighbor accounts for the complete chain, not just one suspicious trace. A reason for revenge can explain a crime without excusing it. Make your final accusation before the investigator announces the solution.",
      "votePrompt": "Who do you accuse based on the evidence heard so far?"
    },
    "solution": {
      "killerId": "xander",
      "explanation": "Xander Hale is Benjamin Barker, formerly Blackwater Row's trusted barber, and he committed all five murders. Thorne's letter and court file, first read in Round 7, establish that the Mayor wanted Barker's wife, framed him, ordered his imprisonment and forced her into his household. Elias's false delivery entry, Ronan's invented confession, Harper's altered household record and Tobias's false night sighting helped destroy Barker's married life. After release, Barker returned as the woodworker Xander Hale. The fine stones in his address-stamped sleeve and Harper's earlier-trade remark established a blade skill without naming it. Nell's direct observation of the chipped ivory razor in Round 5 supplied identifiable ownership; Edith's Round 7 comparison joined that razor, the licensed likeness and the repair invoice to the old identity. Receipt 47 linked the disturbed records; retained duplicates explained the target selection. Marla's repaired flour-marked boot had a documented closing-chore source. Jasper's case and rosin and Lydia's folder and chalk had witnessed work-related sources; their movements raised questions but did not explain the complete identity, weapon and motive chain. No stain alone proved a killing. Barker killed the four accomplices before reaching his final target, the Mayor. This was deliberate revenge, not justice.",
      "revealNarration": "The investigator closes the court file. \"The killer is {xander}. His former name was Benjamin Barker, and his former trade was barber. Nell identified the damaged razor in his hand; Edith matched the license and address to his current work. The earlier victims supplied the false statements that destroyed his former life. Thorne was his final target.\"\n\nThe host may read Barker's final words: \"Once this town knew me as Benjamin Barker. I had a trade, a wife and a home. Thorne wanted what was not his, and four respectable voices made his lie sound like law. When I returned, I called myself Xander Hale and worked in wood. I thought a new name could bury the old one. Instead I carried it through every door. I chose revenge, and I killed them. It did not restore my wife's freedom or the years we lost. Nothing they did makes these murders right.\"\n\nBlackwater Row must now reckon with both the original injustice and the five deaths that followed."
    },
    "masterPreserving": true,
    "conversion": {
      "source": "Committed four-player Blackwater Row revision 3.",
      "changes": [
        {
          "original": "Five discovery chapters and four playable neighbors.",
          "replacement": "Five unchanged discovery sequences with two intervening comparison chapters and a three-player core.",
          "reason": "Seven-round requirement and smallest-edition master. Identity remains in the last discovery chapter; no murders or facts are added."
        },
        {
          "original": "Per-chapter four-player reader handoffs and twenty player responses.",
          "replacement": "Named recorded responses in shared narration and count-specific group order.",
          "reason": "Preserve every witness source and original response while selecting a three-player loop."
        },
        {
          "original": "Solution timing references to Round 4 and Round 5.",
          "replacement": "Corresponding seven-chapter references to Round 5 and Round 7.",
          "reason": "Inserted comparison rounds shift chapter numbers without advancing evidence."
        }
      ],
      "originalResponses": [
        {
          "id": "xander",
          "rounds": [
            {
              "readAloud": {
                "accuses": "marla",
                "text": "I heard Nell saw {marla} leave the bakery's back door at nine with her red-handled brush. Her repaired, flour-packed heel resembles those prints. I still need their timing checked.",
                "observation": "I heard Nell saw {marla} leave the bakery's back door at nine with her red-handled brush.",
                "contradictingDetail": "Her repaired, flour-packed heel resembles those prints. I still need their timing checked."
              }
            },
            {
              "readAloud": {
                "accuses": "jasper",
                "text": "I heard Ada saw {jasper}'s blue-strapped case on Ronan's counter at ten. His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors.",
                "observation": "I heard Ada saw {jasper}'s blue-strapped case on Ronan's counter at ten.",
                "contradictingDetail": "His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors."
              }
            },
            {
              "readAloud": {
                "accuses": "lydia",
                "text": "I heard Owen saw {lydia}'s green folder in Harper's classroom at six, discussing pupil privacy. Its chalk matches the desk height. I worry about access, but Owen left at seven.",
                "observation": "I heard Owen saw {lydia}'s green folder in Harper's classroom at six, discussing pupil privacy.",
                "contradictingDetail": "Its chalk matches the desk height. I worry about access, but Owen left at seven."
              }
            },
            {
              "readAloud": {
                "accuses": "marla",
                "text": "I read {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market. I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone.",
                "observation": "I read {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market.",
                "contradictingDetail": "I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone."
              }
            },
            {
              "readAloud": {
                "accuses": "jasper",
                "text": "I heard {jasper}'s different-name rumor came from Ronan's old-license remark. His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin.",
                "observation": "I heard {jasper}'s different-name rumor came from Ronan's old-license remark.",
                "contradictingDetail": "His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin."
              }
            }
          ]
        },
        {
          "id": "marla",
          "rounds": [
            {
              "readAloud": {
                "accuses": "jasper",
                "text": "I heard Finn saw {jasper} behind the bakery at nine-thirty with his blue-strapped case. A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave.",
                "observation": "I heard Finn saw {jasper} behind the bakery at nine-thirty with his blue-strapped case.",
                "contradictingDetail": "A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave."
              }
            },
            {
              "readAloud": {
                "accuses": "lydia",
                "text": "I heard Ada heard {lydia} warn Ronan about recording families at eight. She touched his book, leaving possible chalk. I can't prove a removed page or a later return.",
                "observation": "I heard Ada heard {lydia} warn Ronan about recording families at eight.",
                "contradictingDetail": "She touched his book, leaving possible chalk. I can't prove a removed page or a later return."
              }
            },
            {
              "readAloud": {
                "accuses": "xander",
                "text": "I heard Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair. Chalk explains his cuff mark to me, not missing pages or blade skills.",
                "observation": "I heard Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair.",
                "contradictingDetail": "Chalk explains his cuff mark to me, not missing pages or blade skills."
              }
            },
            {
              "readAloud": {
                "accuses": "jasper",
                "text": "I heard Della saw {jasper} follow Tobias to the market lamp at ten. He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward.",
                "observation": "I heard Della saw {jasper} follow Tobias to the market lamp at ten.",
                "contradictingDetail": "He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward."
              }
            },
            {
              "readAloud": {
                "accuses": "lydia",
                "text": "I learned {lydia} saw Thorne hide receipt 47 during her confirmed school-funding appointment. She couldn't read the name. I see why she questioned family records, not proof she falsified them.",
                "observation": "I learned {lydia} saw Thorne hide receipt 47 during her confirmed school-funding appointment.",
                "contradictingDetail": "She couldn't read the name. I see why she questioned family records, not proof she falsified them."
              }
            }
          ]
        },
        {
          "id": "jasper",
          "rounds": [
            {
              "readAloud": {
                "accuses": "lydia",
                "text": "I heard Della saw {lydia} argue with Elias that morning, her green lesson folder tucked under her arm. A bread bill held family history. I wonder why he folded that paper.",
                "observation": "I heard Della saw {lydia} argue with Elias that morning, her green lesson folder tucked under her arm.",
                "contradictingDetail": "A bread bill held family history. I wonder why he folded that paper."
              }
            },
            {
              "readAloud": {
                "accuses": "xander",
                "text": "I read {xander}'s shelf invoice; Ada saw fine sharpening stones in his address-stamped sleeve. His repair cloth held amber shellac. I see another possible smear source, not proof he touched that mug.",
                "observation": "I read {xander}'s shelf invoice; Ada saw fine sharpening stones in his address-stamped sleeve.",
                "contradictingDetail": "His repair cloth held amber shellac. I see another possible smear source, not proof he touched that mug."
              }
            },
            {
              "readAloud": {
                "accuses": "marla",
                "text": "I read {marla}'s signed six-o'clock bread delivery to Harper's classroom door. Owen saw her wait by the open records drawer. I see access, but not a fatal-morning visit.",
                "observation": "I read {marla}'s signed six-o'clock bread delivery to Harper's classroom door.",
                "contradictingDetail": "Owen saw her wait by the open records drawer. I see access, but not a fatal-morning visit."
              }
            },
            {
              "readAloud": {
                "accuses": "lydia",
                "text": "I read {lydia}'s warning to Tobias: children's family affairs don't belong in street notes. Her weekly lesson meetings explain contact to me, not an overnight alibi or receipt 47's torn page.",
                "observation": "I read {lydia}'s warning to Tobias: children's family affairs don't belong in street notes.",
                "contradictingDetail": "Her weekly lesson meetings explain contact to me, not an overnight alibi or receipt 47's torn page."
              }
            },
            {
              "readAloud": {
                "accuses": "xander",
                "text": "I heard Edith match {xander}'s licensed likeness and workshop address: Benjamin Barker, barber. His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse.",
                "observation": "I heard Edith match {xander}'s licensed likeness and workshop address: Benjamin Barker, barber.",
                "contradictingDetail": "His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse."
              }
            }
          ]
        },
        {
          "id": "lydia",
          "rounds": [
            {
              "readAloud": {
                "accuses": "xander",
                "text": "I heard Della saw Elias refuse to enter {xander}'s workshop over an old receipt. He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon.",
                "observation": "I heard Della saw Elias refuse to enter {xander}'s workshop over an old receipt.",
                "contradictingDetail": "He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon."
              }
            },
            {
              "readAloud": {
                "accuses": "marla",
                "text": "I heard Della heard {marla} dispute Ronan's flour bill at seven. She showed a receipt and left toward the bakery. I can't confirm payment or a later return.",
                "observation": "I heard Della heard {marla} dispute Ronan's flour bill at seven.",
                "contradictingDetail": "She showed a receipt and left toward the bakery. I can't confirm payment or a later return."
              }
            },
            {
              "readAloud": {
                "accuses": "jasper",
                "text": "I read {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak. I see how marks transfer, but Owen didn't watch the yard entrance overnight.",
                "observation": "I read {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak.",
                "contradictingDetail": "I see how marks transfer, but Owen didn't watch the yard entrance overnight."
              }
            },
            {
              "readAloud": {
                "accuses": "xander",
                "text": "I heard Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge. It went into his stamped sleeve. I worry about those precise cuts, not a confession.",
                "observation": "I heard Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge.",
                "contradictingDetail": "It went into his stamped sleeve. I worry about those precise cuts, not a confession."
              }
            },
            {
              "readAloud": {
                "accuses": "marla",
                "text": "I heard Edith confirm {marla}'s childhood delivery during Thorne's old workshop-home visit. She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot.",
                "observation": "I heard Edith confirm {marla}'s childhood delivery during Thorne's old workshop-home visit.",
                "contradictingDetail": "She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot."
              }
            }
          ]
        }
      ]
    }
  },
  "6": {
    "schemaVersion": 2,
    "fixedPlayerCount": 6,
    "discloseKiller": false,
    "clueRouting": "rotating",
    "edition": {
      "family": "blackwater-scalable",
      "id": "blackwater-scalable-6-players",
      "playerCount": 6,
      "revision": 1
    },
    "title": "The Barber of Blackwater Row",
    "atmosphere": "victorian",
    "setting": "Blackwater Row, a riverside town of workshops, narrow lanes and gaslit streets in the late nineteenth century.",
    "intro": "Evening settles over Blackwater Row. Three neighbors help the town investigator compare the supplied accounts: Xander Hale, the woodworker; Marla Quinn, the baker's assistant; and Jasper Crowe, the tavern musician. The host reads every recorded witness account before the players respond. Other named people remain in the evidence even when they are not playable. Discuss only the chapter just heard; nobody invents a history, witnesses a new discovery or improvises a private part.",
    "hiddenThread": "Receipt 47 recurs in every victim's disturbed records and finally names the Mayor's old imprisonment order against Benjamin Barker.",
    "coverageRepeatNote": "The trio covers all six directed pairs in the first two rounds. Later repeats add released evidence or explicitly correct an unsupported earlier inference. Each supplemental reader targets every other selected character before repeating, never in consecutive rounds. Separate singleton readings preserve the master loop and evidence timing.",
    "specialMechanics": [
      "Receipt 47 ledger: each murder surfaces another record indexed under receipt 47 (delivery log, tavern scrap, student-record index, night-route page). Compare them across rounds; the Mayor's signed order in Round 7 finally connects the series to the old case."
    ],
    "victim": {
      "name": "Elias Brim",
      "description": "The town baker, known for dependable bread deliveries and careful records."
    },
    "rounds": [
      {
        "title": "Round 1 - The Baker's Murder",
        "narration": "At dawn, delivery porter Finn Moss finds Elias Brim behind his bakery with his throat slashed. The investigator reports one clean, precise cut; the death happened off-screen. Elias supplied nearly every doorstep and recorded deliveries and closing chores in separate books. Finn calls night watchwoman Nell Reed before anyone enters the yard. She records a chain of flour prints from the back door to the wet cobbles. Each right print has a crescent-shaped gap at the heel; the cobbles preserve nothing beyond it. A page is torn from an older delivery log. Its surviving edge carries the date and part of receipt 47, but not a customer name or the purpose of the entry. The closing-duty sheet is intact and is kept for later comparison. These are the findings at this scene, not an identification of the killer. The investigator has collected four separate accounts about the neighbors.  Hear all four before discussing which details establish access and which merely raise suspicion.\n\nThe investigator reads the supporting witness accounts before calling on the selected readers:\n\nWitness background for Marla Quinn: Nell Reed saw Marla Quinn leave the bakery back door at nine, carrying her red-handled scrubbing brush. Nell recognized the brass buckle and crescent-shaped repair in the right heel of her work boots because cobbler Della March had shown her that repair at collection yesterday. Flour was packed into the repaired heel. The shape resembles the yard prints recorded this morning. This ties the boots to bakery work and the doorway, but does not date when each print was made. The closing-duty sheet has not yet been checked against the sighting.\n\nWitness background for Jasper Crowe: Finn Moss saw Jasper Crowe waiting behind the bakery at half past nine, with a blue-strapped instrument case propped against the wall. Finn recognized the musician from the tavern and the case from carrying it after last week's performance. A pale streak ran across its lower corner where it touched a flour sack outside the door. Finn heard him ask Elias for a promised parcel, but did not see a parcel handed over or hear what it contained. Finn left for the delivery cart; he did not witness the death or the musician's departure.\n\nWitness background for Lydia Vance: Della March saw Lydia Vance arguing with Elias at the bakery front counter that morning. She recognized the teacher from collecting her granddaughter from school and saw the same green lesson folder under her arm. Della heard the teacher ask why a bread bill included a household's personal history. Elias folded a paper and refused to answer. The teacher left a chalky thumb mark on the counter when she leaned forward. Della identifies the person and the topic, but heard no threat and never saw the contents of the folded paper.\n\nWitness background for Xander Hale: Della March delivered a wooden chair to Xander Hale's workshop last week and saw Elias at the open door. She recognized both men from their regular work at her market stall. Elias refused to enter and said, \"I will not bring that old receipt here again.\" The woodworker stopped sanding, gripped the chair rail and asked which book Elias meant. Della saw fresh amber shellac on his apron beside the repair cloth, but no weapon. She can identify the reaction and the receipt dispute; she cannot identify the old transaction or turn that reaction into proof of murder.\n\nThe host reads the original neighbors' recorded responses:\nXander Hale's recorded response: \"I heard Nell saw Marla Quinn leave the bakery's back door at nine with her red-handled brush. Her repaired, flour-packed heel resembles those prints. I still need their timing checked.\"\nMarla Quinn's recorded response: \"I heard Finn saw Jasper Crowe behind the bakery at nine-thirty with his blue-strapped case. A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave.\"\nJasper Crowe's recorded response: \"I heard Della saw Lydia Vance argue with Elias that morning, her green lesson folder tucked under her arm. A bread bill held family history. I wonder why he folded that paper.\"\nLydia Vance's recorded response: \"I heard Della saw Elias refuse to enter Xander Hale's workshop over an old receipt. He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon.\"\n\nThe supplied witness accounts support these comparisons:\nNell Reed recorded flour prints with a crescent gap in the right heel.\nDella March recognized the repaired boot from its collection yesterday.\nFinn Moss found Elias and called Nell before anyone entered the yard.\nAda Bell has not supplied a tavern account at this stage.\nOwen Bell has not supplied a classroom account at this stage.\nEdith Shaw has not supplied an office account at this stage.\nTown Investigator reported one precise cut at the bakery.\nDella recognized Lydia through collecting Della's Granddaughter from school.",
        "publicText": "Elias Brim: throat slashed with one precise cut. Finn Moss found the body; Nell Reed recorded flour prints with a crescent gap in the right heel. An old delivery-log page is torn; only receipt 47 survives at its edge. The closing-duty sheet is intact.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "At dawn, delivery porter Finn Moss finds Elias Brim behind his bakery with his throat slashed.",
          "The investigator reports one clean, precise cut; the death happened off-screen.",
          "Elias supplied nearly every doorstep and recorded deliveries and closing chores in separate books."
        ],
        "readingGroups": [
          [
            "xander",
            "marla",
            "jasper"
          ],
          [
            "lydia"
          ],
          [
            "nell"
          ],
          [
            "della"
          ]
        ],
        "chain": [
          "xander",
          "marla",
          "jasper",
          "lydia",
          "nell",
          "della"
        ],
        "coverageRepeat": false
      },
      {
        "title": "Round 2 - The Barkeep's Murder",
        "narration": "The next morning, cleaner Ada Bell finds Ronan Pike slumped over his tavern counter with his throat slashed. The investigator records the same precise cut as at the bakery. Ronan kept accounts of debts and stayed late for private appointments. Ada does not touch the mug beside him; Nell Reed records that it has been wiped and has no usable fingerprints. A thin amber smear remains beneath its handle. No owner has been established for the mug or the smear. Beneath Ronan's account book lies a scrap bearing receipt 47 and four lines of dates. No names or explanation survive on the scrap. The matching number links two sets of records, but does not identify their subject. Ronan's service tally and appointment book are preserved separately so that the last drink served will not be confused with the last visitor admitted. Four witness accounts are ready.  Listen for who saw an object, how they identified its owner and whether their timing actually reaches the death.\n\nThe investigator reads the supporting witness accounts before calling on the selected readers:\n\nWitness background for Jasper Crowe: Ada Bell saw Jasper Crowe put his instrument case on Ronan's counter at ten and leave after the last public drink was served. She recognized the case by its repaired blue strap, which she had sewn herself. He uses amber rosin on his bow; Ada collected a flake from the spot where the case rested. Its color resembles the smear beneath the wiped mug, but color alone cannot establish that they are the same material. Ronan locked the public door afterward; Ada did not watch the side entrance or the later appointments.\n\nWitness background for Lydia Vance: Ada Bell heard Lydia Vance tell Ronan at eight, \"Those are dangerous notes; people did not give you permission to record their families.\" Ada recognized the green lesson folder under the teacher's arm from her school-cleaning rounds. The teacher tapped Ronan's account book, leaving a white powder trace on its dark cover. Ada collected it as a possible chalk transfer, not a laboratory identification. The warning concerns records, but Ada saw no page removed. The teacher walked out through the public door; Ada could not observe who returned later.\n\nWitness background for Xander Hale: Ronan's repair invoice records Xander Hale replacing the tavern shelf last week. Ada Bell identified him from the signed invoice and saw him open a leather tool sleeve stamped with the same workshop address. Inside were sharpening stones Ronan called \"too fine for woodworking\": one was much narrower and smoother than the broad stone used on the shelf chisel. Ada saw him wipe the sleeve with an amber shellac-stained cloth from his repair kit. That establishes ownership of the stones and a second possible source of amber residue; it does not prove who handled the wiped mug on the night of the murder.\n\nWitness background for Marla Quinn: Della March heard Marla Quinn dispute an unpaid flour bill with Ronan outside the tavern at seven. She recognized the baker's assistant by the stamped delivery basket she was carrying. Ronan held a bill with a torn lower corner; the assistant produced a coin receipt, but Della was too far away to compare its amount. She saw the assistant leave with the basket toward the bakery. The argument supplies a specific grievance and an observed departure, not proof of payment or a witnessed return to the counter where Ronan died.\n\nThe host reads the original neighbors' recorded responses:\nXander Hale's recorded response: \"I heard Ada saw Jasper Crowe's blue-strapped case on Ronan's counter at ten. His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors.\"\nMarla Quinn's recorded response: \"I heard Ada heard Lydia Vance warn Ronan about recording families at eight. She touched his book, leaving possible chalk. I can't prove a removed page or a later return.\"\nJasper Crowe's recorded response: \"I read Xander Hale's shelf invoice; Ada saw fine sharpening stones in his address-stamped sleeve. His repair cloth held amber shellac. I see another possible smear source, not proof he touched that mug.\"\nLydia Vance's recorded response: \"I heard Della heard Marla Quinn dispute Ronan's flour bill at seven. She showed a receipt and left toward the bakery. I can't confirm payment or a later return.\"\n\nThe supplied witness accounts support these comparisons:\nNell Reed recorded a wiped mug without usable fingerprints.\nDella March heard Marla dispute the flour bill and leave toward the bakery.\nFinn Moss did not witness the bakery death or the musician leaving.\nAda Bell found Ronan and left the mug untouched.\nOwen Bell has not supplied a classroom account at this stage.\nEdith Shaw has not supplied an office account at this stage.\nTown Investigator reported the same precise cut at the tavern.\nDella's school collection of Della's Granddaughter explains her recognition of Lydia.",
        "publicText": "Ronan Pike: throat slashed with the same precise cut. Ada Bell found him. A wiped mug has no usable fingerprints and an unidentified amber smear beneath its handle. A dated scrap bears receipt 47 but no names. Service and appointment records are preserved.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "The next morning, cleaner Ada Bell finds Ronan Pike slumped over his tavern counter with his throat slashed.",
          "The investigator records the same precise cut as at the bakery.",
          "Ronan kept accounts of debts and stayed late for private appointments."
        ],
        "readingGroups": [
          [
            "xander",
            "jasper",
            "marla"
          ],
          [
            "lydia"
          ],
          [
            "nell"
          ],
          [
            "della"
          ]
        ],
        "chain": [
          "xander",
          "jasper",
          "marla",
          "lydia",
          "nell",
          "della"
        ],
        "coverageRepeat": false
      },
      {
        "title": "Round 3 - The Schoolteacher's Murder",
        "narration": "Before sunrise, caretaker Owen Bell finds senior teacher Harper Wren in her classroom with her throat slashed, the same precise cut again. Harper taught most of the town's children and kept family records as carefully as lesson plans. Owen locks the room and fetches Nell Reed. She records a broad chalk smear across the desk and a narrow drag line through it, running from the student-record book toward its open drawer. A page is missing from that book. Its remaining index cites receipt 47; a margin note says, \"Copy kept with the original order.\" Neither the order's owner nor its location is recorded here. Owen also hands over the fundraiser attendance sheet and Harper's lesson diary, both intact. Three disturbed records now share a number. That is a link worth following, not yet an explanation.  Compare observed visits with the traces on the desk, and keep the identity of any missing document separate from guesses about it.\n\nThe investigator reads the supporting witness accounts before calling on the selected readers:\n\nWitness background for Lydia Vance: Owen Bell saw Lydia Vance enter Harper's classroom at six carrying her green lesson folder. He recognized her name written inside its cover when she left it beside the register. A broad chalk mark on the folder's edge matches the height of the smeared desk; Owen had watched her lean it there while discussing pupil privacy. Her warning was, \"A family record should not become a weapon.\" This explains regular access and a possible source of chalk transfer, but Owen left at seven and cannot account for the classroom overnight.\n\nWitness background for Xander Hale: Owen Bell recalls Harper pointing out Xander Hale's narrow whetstone while the woodworker repaired her drawer rail last Tuesday. Owen saw the stone in a leather sleeve stamped with the workshop's address; he checked that address on the repair invoice. Harper said he \"used to work with blades in another trade\" but did not name it. Owen also saw fresh blue chalk on the woodworker's cuff after measuring the rail with Harper's chalk line. That gives an ordinary source for the cuff mark, not an explanation of the missing page or the earlier blade skills.\n\nWitness background for Marla Quinn: Owen Bell signed for Marla Quinn's six-o'clock bread delivery to Harper on the morning before the death. He recognized the baker's stamped basket and the repaired brass-buckled boots described in Round 1. The delivery docket, signed by Harper, specifies the classroom door rather than the school kitchen. Owen saw the assistant wait while Harper opened the student-record drawer to find payment. This gives a witnessed reason for knowing Harper's schedule and seeing the drawer. Neither the flour on the boots nor that access proves a visit before sunrise on the fatal morning.\n\nWitness background for Jasper Crowe: Owen Bell checked Jasper Crowe's name on the fundraiser attendance sheet at nine the previous evening. He recognized the blue-strapped case and watched the musician leave it beside Harper's desk while stacking chairs. White chalk marked the case corner where it rubbed the desktop, covering part of the pale bakery streak described in Round 1. Owen identifies a source for the transfer and a reason for being in the room. He locked the public school door after the event, but did not remain to watch the classroom's separate yard entrance overnight.\n\nThe host reads the original neighbors' recorded responses:\nXander Hale's recorded response: \"I heard Owen saw Lydia Vance's green folder in Harper's classroom at six, discussing pupil privacy. Its chalk matches the desk height. I worry about access, but Owen left at seven.\"\nMarla Quinn's recorded response: \"I heard Harper said Xander Hale once worked with blades; Owen saw his narrow whetstone during her drawer repair. Chalk explains his cuff mark to me, not missing pages or blade skills.\"\nJasper Crowe's recorded response: \"I read Marla Quinn's signed six-o'clock bread delivery to Harper's classroom door. Owen saw her wait by the open records drawer. I see access, but not a fatal-morning visit.\"\nLydia Vance's recorded response: \"I read Jasper Crowe's nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak. I see how marks transfer, but Owen didn't watch the yard entrance overnight.\"\n\nThe supplied witness accounts support these comparisons:\nNell Reed recorded a chalk smear and narrow drag line through it.\nDella March identified Lydia and the topic of the bakery argument.\nFinn Moss heard a promised parcel requested but saw no handover.\nAda Bell saw the fine stones in an address-stamped sleeve.\nOwen Bell found Harper, locked the classroom and fetched Nell.\nEdith Shaw has not supplied an office account at this stage.\nTown Investigator connected three disturbed records by receipt 47.\nDella's collection of Della's Granddaughter identifies a teacher, not a threat.",
        "publicText": "Harper Wren: throat slashed with the same precise cut. Owen Bell found her; Nell Reed recorded chalk and a drag line beside a disturbed student-record book. Its index cites receipt 47 and a copy kept with an unnamed original order. Attendance and lesson records are intact.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "Before sunrise, caretaker Owen Bell finds senior teacher Harper Wren in her classroom with her throat slashed, the same precise cut again.",
          "Harper taught most of the town's children and kept family records as carefully as lesson plans.",
          "Owen locks the room and fetches Nell Reed."
        ],
        "readingGroups": [
          [
            "xander",
            "marla",
            "jasper"
          ],
          [
            "lydia"
          ],
          [
            "nell"
          ],
          [
            "della"
          ]
        ],
        "chain": [
          "xander",
          "marla",
          "jasper",
          "lydia",
          "nell",
          "della"
        ],
        "coverageRepeat": true
      },
      {
        "title": "Round 4 - Visits and Transferred Marks",
        "narration": "Compare only the findings already read at the bakery, tavern and school. An evening delivery is not a fatal-morning visit; flour, rosin, shellac and chalk have witnessed work-related sources. Receipt 47 links disturbed records but does not yet identify their subject. Correct an accusation that mistakes a work trace or access for a witnessed killing. No new death, name, trade or weapon identification is introduced.",
        "publicText": "Correct earlier inferences using only already released evidence.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "Compare released work traces with the recorded visits.",
          "Correct unsupported accusations without a new discovery."
        ],
        "readingGroups": [
          [
            "xander",
            "jasper",
            "marla"
          ],
          [
            "lydia"
          ],
          [
            "nell"
          ],
          [
            "della"
          ]
        ],
        "chain": [
          "xander",
          "jasper",
          "marla",
          "lydia",
          "nell",
          "della"
        ],
        "coverageRepeat": true
      },
      {
        "title": "Round 5 - The Lamplighter's Murder",
        "narration": "Before the morning market opens, Nell Reed finds Tobias Wick beside an extinguished streetlamp with his throat slashed in the same precise manner. Tobias walked every lane at night and kept route notes about what he saw. Lamp oil has spilled in a perfect circle around the lamp base. Nell records its position before moving the fallen oil flask; the shape of the spill alone cannot identify who was there. A page is torn from Tobias's old route notebook. The surviving index bears receipt 47 and the instruction, \"Retain duplicate with original order.\" Nell gathers the bakery closing-duty sheet, Ronan's appointment book and Harper's lesson diary for comparison with the earlier witness accounts. Their entries can explain a visit or correct a timing assumption, but they are not blanket alibis. The subject of the old records is still missing.  Let each account introduce its own new finding. Then compare the four scenes and ask which traces are ordinary work and which remain unexplained.\n\nThe investigator reads the supporting witness accounts before calling on the selected readers:\n\nWitness background for Marla Quinn: Nell Reed compares Marla Quinn's flour-marked repaired boot from Round 1 with the bakery closing-duty sheet. Elias initialed her nine-o'clock task: scrub the rear threshold, then deliver the waste pail to the market. The entry explains why the crescent heel and flour appeared at the doorway; it is not evidence that the print was made during the killing. Market seller Della March also records that the assistant reported Tobias arguing with an unidentified figure beside the oil stall last night. Della heard the report, not the argument, so she cannot identify that figure.\n\nWitness background for Jasper Crowe: Della March saw Jasper Crowe follow Tobias from the tavern to the market lamp at ten last night. She identified the musician by his blue-strapped case and by the tune he had just played at her stall. Tobias asked him to hold the oil flask while adjusting the wick; Della saw a drop spill onto his right sleeve. The stain therefore has an observed source, not merely an assumed link to lamplighting. Della closed her shutter before Tobias resumed his route. The musician's presence and oil stain establish contact, but not where either man went afterward.\n\nWitness background for Lydia Vance: Nell Reed finds Lydia Vance's warning to Tobias entered in his intact route book: \"Children's family affairs do not belong in street notes.\" The entry describes her green folder and the school gate, where Owen Bell confirms he saw them speak. Nell compares it with Harper's lesson diary, which schedules their weekly meetings to prepare lessons and handle family requests. These sources explain the teacher's meetings and concern about records without supplying an overnight alibi. They do not explain why the older page indexed under receipt 47 was torn out.\n\nWitness background for Xander Hale: Nell Reed saw Xander Hale beneath the workshop lamp yesterday evening, holding a straight razor rather than a woodworking chisel. She recognized him from the shelf-repair invoice she had collected at the tavern and spoke to him face to face. The open blade reflected the lamp; the ivory handle had a triangular chip beside its hinge. He closed it and put it into the address-stamped leather sleeve whose fine stones Ada Bell described in Round 2. Nell can identify the owner, object and distinctive damage, but she did not see an attack. The blade should be compared with the repeated precise cuts, not treated as a confession.\n\nThe host reads the original neighbors' recorded responses:\nXander Hale's recorded response: \"I read Marla Quinn's nine-o'clock closing duty: scrub the rear threshold, then take waste to market. I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone.\"\nMarla Quinn's recorded response: \"I heard Della saw Jasper Crowe follow Tobias to the market lamp at ten. He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward.\"\nJasper Crowe's recorded response: \"I read Lydia Vance's warning to Tobias: children's family affairs don't belong in street notes. Her weekly lesson meetings explain contact to me, not an overnight alibi or receipt 47's torn page.\"\nLydia Vance's recorded response: \"I heard Nell saw Xander Hale's straight razor: ivory handle, triangular chip beside its hinge. It went into his stamped sleeve. I worry about those precise cuts, not a confession.\"\n\nThe supplied witness accounts support these comparisons:\nNell Reed saw the chipped ivory razor enter the stamped sleeve.\nDella March saw Jasper holding the flask before oil spilled on his sleeve.\nFinn Moss left for the delivery cart without witnessing the bakery death.\nAda Bell saw the blue-strapped case on Ronan's counter at ten.\nOwen Bell left at seven without watching the separate yard entrance overnight.\nEdith Shaw has not supplied an office account at this stage.\nTown Investigator preserved the earlier work records for timing comparisons.\nDella's school collection of Della's Granddaughter does not identify a murderer.",
        "publicText": "Tobias Wick: throat slashed with the same precise cut. Nell Reed found him beside an extinguished lamp and a circle of spilled oil. A torn night-route page is indexed under receipt 47. Earlier work and appointment records are ready for comparison, not complete alibis.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "Before the morning market opens, Nell Reed finds Tobias Wick beside an extinguished streetlamp with his throat slashed in the same precise manner.",
          "Tobias walked every lane at night and kept route notes about what he saw.",
          "Lamp oil has spilled in a perfect circle around the lamp base."
        ],
        "readingGroups": [
          [
            "xander",
            "marla",
            "jasper"
          ],
          [
            "lydia"
          ],
          [
            "nell"
          ],
          [
            "della"
          ]
        ],
        "chain": [
          "xander",
          "marla",
          "jasper",
          "lydia",
          "nell",
          "della"
        ],
        "coverageRepeat": true
      },
      {
        "title": "Round 6 - Work Traces and the Identified Tool",
        "narration": "Compare the already released closing-duty sheet, private-appointment records, school visits and Nell's chipped-razor sighting. A work record can explain a trace without supplying an overnight alibi. The identified razor is more specific than an unexplained color or stain, but its sighting is not a confession. Correct earlier accusations based only on flour, chalk or spilled oil. No new death or old identity is introduced.",
        "publicText": "Correct earlier inferences using only already released evidence.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "Compare released work traces with the recorded visits.",
          "Correct unsupported accusations without a new discovery."
        ],
        "readingGroups": [
          [
            "xander",
            "jasper",
            "marla"
          ],
          [
            "lydia"
          ],
          [
            "nell"
          ],
          [
            "della"
          ]
        ],
        "chain": [
          "xander",
          "jasper",
          "marla",
          "lydia",
          "nell",
          "della"
        ],
        "coverageRepeat": true
      },
      {
        "title": "Round 7 - The Mayor's Murder",
        "narration": "Office clerk Edith Shaw finds Mayor Aldric Thorne in his office chair with his throat slashed, the same precise cut. A polished straight razor lies on the desk, its ivory handle chipped beside the hinge. Edith calls Nell Reed and identifies the locked cabinet from which the papers on the desk came; its numbered index and broken wax seal allow the investigator to trace their source. A single old court document, signed by Thorne, orders the imprisonment of BENJAMIN BARKER and bears receipt 47. This is the first time that name enters the investigation. With it are the duplicate records referred to in Harper's index and Tobias's notebook. The investigator reads them aloud: Elias signed a false delivery entry placing Barker at a theft; Ronan signed a fabricated account of a confession; Harper altered a household record to support the charge; Tobias supplied a false night-route sighting. A retained letter from Thorne orders the changes, admits that he wanted Barker's wife and describes using imprisonment to separate them. The household record states that she was taken into Thorne's household under coercion, not by free choice. Barker's licensed occupation is barber. A likeness, address and tool inventory are attached, but the investigator leaves their identification to the witnesses whose accounts you are about to hear. These documents establish the original injustice and the four victims' roles. They do not announce which current neighbor committed the murders.  Hear every account before the final vote.\n\nThe investigator reads the supporting witness accounts before calling on the selected readers:\n\nWitness background for Jasper Crowe: Edith Shaw asks Jasper Crowe to explain a rumor he heard at the tavern about the woodworker once using a different name. He identifies its source as Ronan's remark about an old license, not personal knowledge of the imprisonment. Edith compares the signature on his ten-o'clock drink receipt with the appointment book preserved in Round 2; it confirms his earlier visit, while a separate eleven-o'clock entry admits a private visitor. His rosin flake explains a substance on the counter, but neither the rumor nor the flake identifies that later visitor or makes him a signer of the false statements in the court file.\n\nWitness background for Lydia Vance: Edith Shaw compares Lydia Vance's account of seeing the Mayor hide an old paper with the cabinet index recovered today. The teacher dates the sighting to a school-funding appointment entered in Edith's diary; Edith confirms she admitted her for that appointment and saw Thorne close the folder. The teacher could read receipt 47, but not the name hidden beneath his hand. This explains why the teacher questioned intrusive family records. Her chalk-marked folder and weekly lesson meetings establish access to school papers, not a signature on the falsified statements read from the court file.\n\nWitness background for Xander Hale: Edith Shaw identifies the court file's licensed likeness as Xander Hale; she compares the workshop address printed beside it with the signed shelf-repair invoice preserved in Round 2. The licensed name is Benjamin Barker. The barber's tool inventory describes an ivory razor with a chip beside the hinge, matching the blade Nell Reed saw in his hand in Round 4 and the one now on Thorne's desk. The fine stones and Harper's earlier-trade remark fit the documented occupation. The duplicate records identify the four people who helped Thorne destroy his former life. This joins identity, blade ownership and motive; the room must still decide its final accusation.\n\nWitness background for Marla Quinn: Edith Shaw checks Marla Quinn's account of an old visit by Thorne to the workshop home. The assistant remembers delivering a baker's basket there as a child; the retained delivery copy records the date and the house number. Edith compares those details with Thorne's appointment diary and confirms the visit. The account links a remembered visit to a documented place, but the assistant did not hear the conversation. Her repaired flour-marked boot still fits the closing chore established in Round 4, not a proven killing. Neither her childhood observation nor her recent bread delivery makes her one of the signers identified in the old file.\n\nThe host reads the original neighbors' recorded responses:\nXander Hale's recorded response: \"I heard Jasper Crowe's different-name rumor came from Ronan's old-license remark. His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin.\"\nMarla Quinn's recorded response: \"I learned Lydia Vance saw Thorne hide receipt 47 during her confirmed school-funding appointment. She couldn't read the name. I see why she questioned family records, not proof she falsified them.\"\nJasper Crowe's recorded response: \"I heard Edith match Xander Hale's licensed likeness and workshop address: Benjamin Barker, barber. His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse.\"\nLydia Vance's recorded response: \"I heard Edith confirm Marla Quinn's childhood delivery during Thorne's old workshop-home visit. She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot.\"\n\nThe supplied witness accounts support these comparisons:\nNell Reed identified the damaged razor in the earlier sighting.\nDella March's boot identification established work access, not print timing.\nFinn Moss's case account established an evening visit, not a witnessed murder.\nAda Bell's account left later private visitors possible.\nOwen Bell's accounts did not establish an overnight alibi.\nEdith Shaw matched the licensed likeness and address to Xander.\nTown Investigator read the retained duplicate records and Thorne's letter.\nDella's identification through Della's Granddaughter does not implicate Lydia in the old falsification.",
        "publicText": "Mayor Aldric Thorne: throat slashed; a polished razor with a chipped ivory handle on his desk. Edith Shaw identifies the cabinet and record index. Thorne's signed imprisonment order names Benjamin Barker under receipt 47. Duplicate records and his letter expose the four victims' false statements and his coercion. Witness identification follows in the player readings.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "Office clerk Edith Shaw finds Mayor Aldric Thorne in his office chair with his throat slashed, the same precise cut.",
          "A polished straight razor lies on the desk, its ivory handle chipped beside the hinge.",
          "Edith calls Nell Reed and identifies the locked cabinet from which the papers on the desk came; its numbered index and broken wax seal allow the investigator to trace their source."
        ],
        "readingGroups": [
          [
            "xander",
            "marla",
            "jasper"
          ],
          [
            "lydia"
          ],
          [
            "nell"
          ],
          [
            "della"
          ]
        ],
        "chain": [
          "xander",
          "marla",
          "jasper",
          "lydia",
          "nell",
          "della"
        ],
        "coverageRepeat": true
      }
    ],
    "characters": [
      {
        "id": "xander",
        "name": "Xander Hale",
        "role": "Woodworker",
        "relationship": "A neighbor asked by the town investigator to help compare witness accounts of the Blackwater Row murders.",
        "tieIn": "A quiet craftsperson who repairs furniture and makes wooden fittings in a workshop off the market lane.",
        "optional": false,
        "ghost": null,
        "guest": "",
        "guestNote": "",
        "publicBlurb": "A quiet craftsperson who repairs furniture and makes wooden fittings in a workshop off the market lane.",
        "rounds": [
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I heard Nell saw {marla} leave the bakery's back door at nine with her red-handled brush. Her repaired, flour-packed heel resembles those prints. I still need their timing checked.",
              "observation": "I heard Nell saw {marla} leave the bakery's back door at nine with her red-handled brush.",
              "contradictingDetail": "Her repaired, flour-packed heel resembles those prints. I still need their timing checked."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I heard Ada saw {jasper}'s blue-strapped case on Ronan's counter at ten. His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors.",
              "observation": "I heard Ada saw {jasper}'s blue-strapped case on Ronan's counter at ten.",
              "contradictingDetail": "His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I read {marla}'s signed six-o'clock bread delivery to Harper's classroom door. Owen saw her wait by the open records drawer. I see access, but not a fatal-morning visit.",
              "observation": "I read {marla}'s signed six-o'clock bread delivery to Harper's classroom door.",
              "contradictingDetail": "Owen saw her wait by the open records drawer. I see access, but not a fatal-morning visit."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I heard {jasper}'s case rubbed the chalky desk over its flour streak. I must distinguish transferred work marks from evidence that he removed the student-record page.",
              "observation": "I heard {jasper}'s case rubbed the chalky desk over its flour streak.",
              "contradictingDetail": "I must distinguish transferred work marks from evidence that he removed the student-record page."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I read {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market. I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone.",
              "observation": "I read {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market.",
              "contradictingDetail": "I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I read {jasper}'s visit to the lamp in Della's account. I must not treat spilled oil on his sleeve as proof of a precise cut or an account of his later movements.",
              "observation": "I read {jasper}'s visit to the lamp in Della's account.",
              "contradictingDetail": "I must not treat spilled oil on his sleeve as proof of a precise cut or an account of his later movements."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I heard Edith confirm {marla}'s childhood delivery during Thorne's old workshop-home visit. She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot.",
              "observation": "I heard Edith confirm {marla}'s childhood delivery during Thorne's old workshop-home visit.",
              "contradictingDetail": "She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot."
            }
          }
        ]
      },
      {
        "id": "marla",
        "name": "Marla Quinn",
        "role": "Baker's assistant",
        "relationship": "Assistant to the first victim, the baker Elias Brim; asked to help compare witness accounts.",
        "tieIn": "Elias Brim's assistant, responsible for bread deliveries and the evening cleanup. A familiar face at doorsteps across town.",
        "optional": false,
        "ghost": null,
        "guest": "",
        "guestNote": "",
        "publicBlurb": "Elias Brim's assistant, responsible for bread deliveries and the evening cleanup. A familiar face at doorsteps across town.",
        "rounds": [
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I heard Finn saw {jasper} behind the bakery at nine-thirty with his blue-strapped case. A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave.",
              "observation": "I heard Finn saw {jasper} behind the bakery at nine-thirty with his blue-strapped case.",
              "contradictingDetail": "A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I read {xander}'s shelf invoice; Ada saw fine sharpening stones in his address-stamped sleeve. His repair cloth held amber shellac. I see another possible smear source, not proof he touched that mug.",
              "observation": "I read {xander}'s shelf invoice; Ada saw fine sharpening stones in his address-stamped sleeve.",
              "contradictingDetail": "His repair cloth held amber shellac. I see another possible smear source, not proof he touched that mug."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I read {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak. I see how marks transfer, but Owen didn't watch the yard entrance overnight.",
              "observation": "I read {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak.",
              "contradictingDetail": "I see how marks transfer, but Owen didn't watch the yard entrance overnight."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard {xander}'s drawer repair explained chalk on his cuff. I must not mistake a work mark for an explanation of the missing pages or his earlier blade skills.",
              "observation": "I heard {xander}'s drawer repair explained chalk on his cuff.",
              "contradictingDetail": "I must not mistake a work mark for an explanation of the missing pages or his earlier blade skills."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I heard Della saw {jasper} follow Tobias to the market lamp at ten. He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward.",
              "observation": "I heard Della saw {jasper} follow Tobias to the market lamp at ten.",
              "contradictingDetail": "He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard Nell identify {xander}'s chipped ivory razor. I must compare that identifiable tool with the repeated cuts, not call the sighting a confession.",
              "observation": "I heard Nell identify {xander}'s chipped ivory razor.",
              "contradictingDetail": "I must compare that identifiable tool with the repeated cuts, not call the sighting a confession."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I heard {jasper}'s different-name rumor came from Ronan's old-license remark. His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin.",
              "observation": "I heard {jasper}'s different-name rumor came from Ronan's old-license remark.",
              "contradictingDetail": "His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin."
            }
          }
        ]
      },
      {
        "id": "jasper",
        "name": "Jasper Crowe",
        "role": "Tavern musician",
        "relationship": "Musician at the tavern of the second victim, Ronan Pike; asked to help compare witness accounts.",
        "tieIn": "A musician at Ronan Pike's tavern who also plays for town events. Often out late carrying his instrument between jobs.",
        "optional": false,
        "ghost": null,
        "guest": "",
        "guestNote": "",
        "publicBlurb": "A musician at Ronan Pike's tavern who also plays for town events. Often out late carrying his instrument between jobs.",
        "rounds": [
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard Della saw Elias refuse to enter {xander}'s workshop over an old receipt. He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon.",
              "observation": "I heard Della saw Elias refuse to enter {xander}'s workshop over an old receipt.",
              "contradictingDetail": "He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I heard Della heard {marla} dispute Ronan's flour bill at seven. She showed a receipt and left toward the bakery. I can't confirm payment or a later return.",
              "observation": "I heard Della heard {marla} dispute Ronan's flour bill at seven.",
              "contradictingDetail": "She showed a receipt and left toward the bakery. I can't confirm payment or a later return."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair. Chalk explains his cuff mark to me, not missing pages or blade skills.",
              "observation": "I heard Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair.",
              "contradictingDetail": "Chalk explains his cuff mark to me, not missing pages or blade skills."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I read {marla}'s signed bread delivery at six. I must distinguish an evening delivery from a fatal-morning visit; access alone does not explain the missing page.",
              "observation": "I read {marla}'s signed bread delivery at six.",
              "contradictingDetail": "I must distinguish an evening delivery from a fatal-morning visit; access alone does not explain the missing page."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge. It went into his stamped sleeve. I worry about those precise cuts, not a confession.",
              "observation": "I heard Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge.",
              "contradictingDetail": "It went into his stamped sleeve. I worry about those precise cuts, not a confession."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I read {marla}'s closing duty to scrub the rear threshold. I must correct my earlier suspicion: flour in her repaired heel can come from work, not a witnessed killing.",
              "observation": "I read {marla}'s closing duty to scrub the rear threshold.",
              "contradictingDetail": "I must correct my earlier suspicion: flour in her repaired heel can come from work, not a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard Edith match {xander}'s licensed likeness and workshop address: Benjamin Barker, barber. His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse.",
              "observation": "I heard Edith match {xander}'s licensed likeness and workshop address: Benjamin Barker, barber.",
              "contradictingDetail": "His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse."
            }
          }
        ]
      },
      {
        "id": "lydia",
        "name": "Lydia Vance",
        "role": "Schoolteacher",
        "relationship": "Teacher working alongside the third victim, senior teacher Harper Wren; asked to help compare witness accounts.",
        "tieIn": "A teacher working alongside senior teacher Harper Wren. Attentive to local families and protective of their privacy.",
        "publicBlurb": "A teacher working alongside senior teacher Harper Wren. Attentive to local families and protective of their privacy.",
        "optional": false,
        "guest": "",
        "guestNote": "",
        "ghost": null,
        "rounds": [
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I learned Della saw Elias refuse to enter {xander}'s workshop over an old receipt. He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon.",
              "observation": "I learned Della saw Elias refuse to enter {xander}'s workshop over an old receipt.",
              "contradictingDetail": "He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I learned Della heard {marla} dispute Ronan's flour bill at seven. She showed a receipt and left toward the bakery. I can't confirm payment or a later return.",
              "observation": "I learned Della heard {marla} dispute Ronan's flour bill at seven.",
              "contradictingDetail": "She showed a receipt and left toward the bakery. I can't confirm payment or a later return."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I checked {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak. I see how marks transfer, but Owen didn't watch the yard entrance overnight.",
              "observation": "I checked {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak.",
              "contradictingDetail": "I see how marks transfer, but Owen didn't watch the yard entrance overnight."
            }
          },
          {
            "readAloud": {
              "accuses": "nell",
              "text": "I heard the account: {nell} recorded a chalk smear and narrow drag line through it. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: {nell} recorded a chalk smear and narrow drag line through it.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "della",
              "text": "I heard the account: {della} saw Jasper holding the flask before oil spilled on his sleeve. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {della} saw Jasper holding the flask before oil spilled on his sleeve.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I learned Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge. I must correct mistaking a report for a witnessed killing.",
              "observation": "I learned Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge.",
              "contradictingDetail": "I must correct mistaking a report for a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I learned Edith confirm {marla}'s childhood delivery during Thorne's old workshop-home visit. She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot.",
              "observation": "I learned Edith confirm {marla}'s childhood delivery during Thorne's old workshop-home visit.",
              "contradictingDetail": "She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot."
            }
          }
        ]
      },
      {
        "id": "nell",
        "name": "Nell Reed",
        "role": "Night watchwoman",
        "relationship": "An existing person in the supplied Blackwater Row accounts.",
        "tieIn": "Records the scene findings and supplies the razor sighting.",
        "publicBlurb": "Records the scene findings and supplies the razor sighting.",
        "optional": false,
        "guest": "",
        "guestNote": "",
        "ghost": null,
        "rounds": [
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I learned Nell saw {marla} leave the bakery's back door at nine with her red-handled brush. Her repaired, flour-packed heel resembles those prints. I still need their timing checked.",
              "observation": "I learned Nell saw {marla} leave the bakery's back door at nine with her red-handled brush.",
              "contradictingDetail": "Her repaired, flour-packed heel resembles those prints. I still need their timing checked."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I learned Ada saw {jasper}'s blue-strapped case on Ronan's counter at ten. His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors.",
              "observation": "I learned Ada saw {jasper}'s blue-strapped case on Ronan's counter at ten.",
              "contradictingDetail": "His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors."
            }
          },
          {
            "readAloud": {
              "accuses": "lydia",
              "text": "I learned Owen saw {lydia}'s green folder in Harper's classroom at six, discussing pupil privacy. Its chalk matches the desk height. I worry about access, but Owen left at seven.",
              "observation": "I learned Owen saw {lydia}'s green folder in Harper's classroom at six, discussing pupil privacy.",
              "contradictingDetail": "Its chalk matches the desk height. I worry about access, but Owen left at seven."
            }
          },
          {
            "readAloud": {
              "accuses": "della",
              "text": "I heard the account: {della} identified Lydia and the topic of the bakery argument. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: {della} identified Lydia and the topic of the bakery argument.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I learned Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge. It went into his stamped sleeve. I worry about those precise cuts, not a confession.",
              "observation": "I learned Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge.",
              "contradictingDetail": "It went into his stamped sleeve. I worry about those precise cuts, not a confession."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I checked {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market. I must correct mistaking a report for a witnessed killing.",
              "observation": "I checked {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market.",
              "contradictingDetail": "I must correct mistaking a report for a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I learned {jasper}'s different-name rumor came from Ronan's old-license remark. His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin.",
              "observation": "I learned {jasper}'s different-name rumor came from Ronan's old-license remark.",
              "contradictingDetail": "His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin."
            }
          }
        ]
      },
      {
        "id": "della",
        "name": "Della March",
        "role": "Cobbler",
        "relationship": "An existing person in the supplied Blackwater Row accounts.",
        "tieIn": "Identifies the repaired boot and the neighbors in her recorded accounts.",
        "publicBlurb": "Identifies the repaired boot and the neighbors in her recorded accounts.",
        "optional": false,
        "guest": "",
        "guestNote": "",
        "ghost": null,
        "rounds": [
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I learned Finn saw {jasper} behind the bakery at nine-thirty with his blue-strapped case. A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave.",
              "observation": "I learned Finn saw {jasper} behind the bakery at nine-thirty with his blue-strapped case.",
              "contradictingDetail": "A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave."
            }
          },
          {
            "readAloud": {
              "accuses": "lydia",
              "text": "I learned Ada heard {lydia} warn Ronan about recording families at eight. She touched his book, leaving possible chalk. I can't prove a removed page or a later return.",
              "observation": "I learned Ada heard {lydia} warn Ronan about recording families at eight.",
              "contradictingDetail": "She touched his book, leaving possible chalk. I can't prove a removed page or a later return."
            }
          },
          {
            "readAloud": {
              "accuses": "nell",
              "text": "I heard the account: {nell} recorded a chalk smear and narrow drag line through it. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {nell} recorded a chalk smear and narrow drag line through it.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I learned Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair. Chalk explains his cuff mark to me, not missing pages or blade skills.",
              "observation": "I learned Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair.",
              "contradictingDetail": "Chalk explains his cuff mark to me, not missing pages or blade skills."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I checked {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market. I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone.",
              "observation": "I checked {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market.",
              "contradictingDetail": "I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I learned Della saw {jasper} follow Tobias to the market lamp at ten. I must correct mistaking a report for a witnessed killing.",
              "observation": "I learned Della saw {jasper} follow Tobias to the market lamp at ten.",
              "contradictingDetail": "I must correct mistaking a report for a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "lydia",
              "text": "I heard {lydia} saw Thorne hide receipt 47 during her confirmed school-funding appointment. She couldn't read the name. I see why she questioned family records, not proof she falsified them.",
              "observation": "I heard {lydia} saw Thorne hide receipt 47 during her confirmed school-funding appointment.",
              "contradictingDetail": "She couldn't read the name. I see why she questioned family records, not proof she falsified them."
            }
          }
        ]
      }
    ],
    "finale": {
      "narration": "All seven chapters and the final witness accounts have now been read. Compare the identified blade, the licensed likeness and address, and the duplicate records with the earlier observations. Decide which neighbor accounts for the complete chain, not just one suspicious trace. A reason for revenge can explain a crime without excusing it. Make your final accusation before the investigator announces the solution.",
      "votePrompt": "Who do you accuse based on the evidence heard so far?"
    },
    "solution": {
      "killerId": "xander",
      "explanation": "Xander Hale is Benjamin Barker, formerly Blackwater Row's trusted barber, and he committed all five murders. Thorne's letter and court file, first read in Round 7, establish that the Mayor wanted Barker's wife, framed him, ordered his imprisonment and forced her into his household. Elias's false delivery entry, Ronan's invented confession, Harper's altered household record and Tobias's false night sighting helped destroy Barker's married life. After release, Barker returned as the woodworker Xander Hale. The fine stones in his address-stamped sleeve and Harper's earlier-trade remark established a blade skill without naming it. Nell's direct observation of the chipped ivory razor in Round 5 supplied identifiable ownership; Edith's Round 7 comparison joined that razor, the licensed likeness and the repair invoice to the old identity. Receipt 47 linked the disturbed records; retained duplicates explained the target selection. Marla's repaired flour-marked boot had a documented closing-chore source. Jasper's case and rosin and Lydia's folder and chalk had witnessed work-related sources; their movements raised questions but did not explain the complete identity, weapon and motive chain. No stain alone proved a killing. Barker killed the four accomplices before reaching his final target, the Mayor. This was deliberate revenge, not justice.",
      "revealNarration": "The investigator closes the court file. \"The killer is {xander}. His former name was Benjamin Barker, and his former trade was barber. Nell identified the damaged razor in his hand; Edith matched the license and address to his current work. The earlier victims supplied the false statements that destroyed his former life. Thorne was his final target.\"\n\nThe host may read Barker's final words: \"Once this town knew me as Benjamin Barker. I had a trade, a wife and a home. Thorne wanted what was not his, and four respectable voices made his lie sound like law. When I returned, I called myself Xander Hale and worked in wood. I thought a new name could bury the old one. Instead I carried it through every door. I chose revenge, and I killed them. It did not restore my wife's freedom or the years we lost. Nothing they did makes these murders right.\"\n\nBlackwater Row must now reckon with both the original injustice and the five deaths that followed."
    },
    "masterPreserving": true,
    "conversion": {
      "source": "Committed four-player Blackwater Row revision 3.",
      "changes": [
        {
          "original": "Five discovery chapters and four playable neighbors.",
          "replacement": "Five unchanged discovery sequences with two intervening comparison chapters and a three-player core.",
          "reason": "Seven-round requirement and smallest-edition master. Identity remains in the last discovery chapter; no murders or facts are added."
        },
        {
          "original": "Per-chapter four-player reader handoffs and twenty player responses.",
          "replacement": "Named recorded responses in shared narration and count-specific group order.",
          "reason": "Preserve every witness source and original response while selecting a three-player loop."
        },
        {
          "original": "Solution timing references to Round 4 and Round 5.",
          "replacement": "Corresponding seven-chapter references to Round 5 and Round 7.",
          "reason": "Inserted comparison rounds shift chapter numbers without advancing evidence."
        }
      ],
      "originalResponses": [
        {
          "id": "xander",
          "rounds": [
            {
              "readAloud": {
                "accuses": "marla",
                "text": "I heard Nell saw {marla} leave the bakery's back door at nine with her red-handled brush. Her repaired, flour-packed heel resembles those prints. I still need their timing checked.",
                "observation": "I heard Nell saw {marla} leave the bakery's back door at nine with her red-handled brush.",
                "contradictingDetail": "Her repaired, flour-packed heel resembles those prints. I still need their timing checked."
              }
            },
            {
              "readAloud": {
                "accuses": "jasper",
                "text": "I heard Ada saw {jasper}'s blue-strapped case on Ronan's counter at ten. His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors.",
                "observation": "I heard Ada saw {jasper}'s blue-strapped case on Ronan's counter at ten.",
                "contradictingDetail": "His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors."
              }
            },
            {
              "readAloud": {
                "accuses": "lydia",
                "text": "I heard Owen saw {lydia}'s green folder in Harper's classroom at six, discussing pupil privacy. Its chalk matches the desk height. I worry about access, but Owen left at seven.",
                "observation": "I heard Owen saw {lydia}'s green folder in Harper's classroom at six, discussing pupil privacy.",
                "contradictingDetail": "Its chalk matches the desk height. I worry about access, but Owen left at seven."
              }
            },
            {
              "readAloud": {
                "accuses": "marla",
                "text": "I read {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market. I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone.",
                "observation": "I read {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market.",
                "contradictingDetail": "I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone."
              }
            },
            {
              "readAloud": {
                "accuses": "jasper",
                "text": "I heard {jasper}'s different-name rumor came from Ronan's old-license remark. His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin.",
                "observation": "I heard {jasper}'s different-name rumor came from Ronan's old-license remark.",
                "contradictingDetail": "His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin."
              }
            }
          ]
        },
        {
          "id": "marla",
          "rounds": [
            {
              "readAloud": {
                "accuses": "jasper",
                "text": "I heard Finn saw {jasper} behind the bakery at nine-thirty with his blue-strapped case. A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave.",
                "observation": "I heard Finn saw {jasper} behind the bakery at nine-thirty with his blue-strapped case.",
                "contradictingDetail": "A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave."
              }
            },
            {
              "readAloud": {
                "accuses": "lydia",
                "text": "I heard Ada heard {lydia} warn Ronan about recording families at eight. She touched his book, leaving possible chalk. I can't prove a removed page or a later return.",
                "observation": "I heard Ada heard {lydia} warn Ronan about recording families at eight.",
                "contradictingDetail": "She touched his book, leaving possible chalk. I can't prove a removed page or a later return."
              }
            },
            {
              "readAloud": {
                "accuses": "xander",
                "text": "I heard Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair. Chalk explains his cuff mark to me, not missing pages or blade skills.",
                "observation": "I heard Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair.",
                "contradictingDetail": "Chalk explains his cuff mark to me, not missing pages or blade skills."
              }
            },
            {
              "readAloud": {
                "accuses": "jasper",
                "text": "I heard Della saw {jasper} follow Tobias to the market lamp at ten. He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward.",
                "observation": "I heard Della saw {jasper} follow Tobias to the market lamp at ten.",
                "contradictingDetail": "He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward."
              }
            },
            {
              "readAloud": {
                "accuses": "lydia",
                "text": "I learned {lydia} saw Thorne hide receipt 47 during her confirmed school-funding appointment. She couldn't read the name. I see why she questioned family records, not proof she falsified them.",
                "observation": "I learned {lydia} saw Thorne hide receipt 47 during her confirmed school-funding appointment.",
                "contradictingDetail": "She couldn't read the name. I see why she questioned family records, not proof she falsified them."
              }
            }
          ]
        },
        {
          "id": "jasper",
          "rounds": [
            {
              "readAloud": {
                "accuses": "lydia",
                "text": "I heard Della saw {lydia} argue with Elias that morning, her green lesson folder tucked under her arm. A bread bill held family history. I wonder why he folded that paper.",
                "observation": "I heard Della saw {lydia} argue with Elias that morning, her green lesson folder tucked under her arm.",
                "contradictingDetail": "A bread bill held family history. I wonder why he folded that paper."
              }
            },
            {
              "readAloud": {
                "accuses": "xander",
                "text": "I read {xander}'s shelf invoice; Ada saw fine sharpening stones in his address-stamped sleeve. His repair cloth held amber shellac. I see another possible smear source, not proof he touched that mug.",
                "observation": "I read {xander}'s shelf invoice; Ada saw fine sharpening stones in his address-stamped sleeve.",
                "contradictingDetail": "His repair cloth held amber shellac. I see another possible smear source, not proof he touched that mug."
              }
            },
            {
              "readAloud": {
                "accuses": "marla",
                "text": "I read {marla}'s signed six-o'clock bread delivery to Harper's classroom door. Owen saw her wait by the open records drawer. I see access, but not a fatal-morning visit.",
                "observation": "I read {marla}'s signed six-o'clock bread delivery to Harper's classroom door.",
                "contradictingDetail": "Owen saw her wait by the open records drawer. I see access, but not a fatal-morning visit."
              }
            },
            {
              "readAloud": {
                "accuses": "lydia",
                "text": "I read {lydia}'s warning to Tobias: children's family affairs don't belong in street notes. Her weekly lesson meetings explain contact to me, not an overnight alibi or receipt 47's torn page.",
                "observation": "I read {lydia}'s warning to Tobias: children's family affairs don't belong in street notes.",
                "contradictingDetail": "Her weekly lesson meetings explain contact to me, not an overnight alibi or receipt 47's torn page."
              }
            },
            {
              "readAloud": {
                "accuses": "xander",
                "text": "I heard Edith match {xander}'s licensed likeness and workshop address: Benjamin Barker, barber. His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse.",
                "observation": "I heard Edith match {xander}'s licensed likeness and workshop address: Benjamin Barker, barber.",
                "contradictingDetail": "His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse."
              }
            }
          ]
        },
        {
          "id": "lydia",
          "rounds": [
            {
              "readAloud": {
                "accuses": "xander",
                "text": "I heard Della saw Elias refuse to enter {xander}'s workshop over an old receipt. He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon.",
                "observation": "I heard Della saw Elias refuse to enter {xander}'s workshop over an old receipt.",
                "contradictingDetail": "He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon."
              }
            },
            {
              "readAloud": {
                "accuses": "marla",
                "text": "I heard Della heard {marla} dispute Ronan's flour bill at seven. She showed a receipt and left toward the bakery. I can't confirm payment or a later return.",
                "observation": "I heard Della heard {marla} dispute Ronan's flour bill at seven.",
                "contradictingDetail": "She showed a receipt and left toward the bakery. I can't confirm payment or a later return."
              }
            },
            {
              "readAloud": {
                "accuses": "jasper",
                "text": "I read {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak. I see how marks transfer, but Owen didn't watch the yard entrance overnight.",
                "observation": "I read {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak.",
                "contradictingDetail": "I see how marks transfer, but Owen didn't watch the yard entrance overnight."
              }
            },
            {
              "readAloud": {
                "accuses": "xander",
                "text": "I heard Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge. It went into his stamped sleeve. I worry about those precise cuts, not a confession.",
                "observation": "I heard Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge.",
                "contradictingDetail": "It went into his stamped sleeve. I worry about those precise cuts, not a confession."
              }
            },
            {
              "readAloud": {
                "accuses": "marla",
                "text": "I heard Edith confirm {marla}'s childhood delivery during Thorne's old workshop-home visit. She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot.",
                "observation": "I heard Edith confirm {marla}'s childhood delivery during Thorne's old workshop-home visit.",
                "contradictingDetail": "She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot."
              }
            }
          ]
        }
      ]
    }
  },
  "7": {
    "schemaVersion": 2,
    "fixedPlayerCount": 7,
    "discloseKiller": false,
    "clueRouting": "rotating",
    "edition": {
      "family": "blackwater-scalable",
      "id": "blackwater-scalable-7-players",
      "playerCount": 7,
      "revision": 1
    },
    "title": "The Barber of Blackwater Row",
    "atmosphere": "victorian",
    "setting": "Blackwater Row, a riverside town of workshops, narrow lanes and gaslit streets in the late nineteenth century.",
    "intro": "Evening settles over Blackwater Row. Three neighbors help the town investigator compare the supplied accounts: Xander Hale, the woodworker; Marla Quinn, the baker's assistant; and Jasper Crowe, the tavern musician. The host reads every recorded witness account before the players respond. Other named people remain in the evidence even when they are not playable. Discuss only the chapter just heard; nobody invents a history, witnesses a new discovery or improvises a private part.",
    "hiddenThread": "Receipt 47 recurs in every victim's disturbed records and finally names the Mayor's old imprisonment order against Benjamin Barker.",
    "coverageRepeatNote": "The trio covers all six directed pairs in the first two rounds. Later repeats add released evidence or explicitly correct an unsupported earlier inference. Each supplemental reader targets every other selected character before repeating, never in consecutive rounds. Separate singleton readings preserve the master loop and evidence timing.",
    "specialMechanics": [
      "Receipt 47 ledger: each murder surfaces another record indexed under receipt 47 (delivery log, tavern scrap, student-record index, night-route page). Compare them across rounds; the Mayor's signed order in Round 7 finally connects the series to the old case."
    ],
    "victim": {
      "name": "Elias Brim",
      "description": "The town baker, known for dependable bread deliveries and careful records."
    },
    "rounds": [
      {
        "title": "Round 1 - The Baker's Murder",
        "narration": "At dawn, delivery porter Finn Moss finds Elias Brim behind his bakery with his throat slashed. The investigator reports one clean, precise cut; the death happened off-screen. Elias supplied nearly every doorstep and recorded deliveries and closing chores in separate books. Finn calls night watchwoman Nell Reed before anyone enters the yard. She records a chain of flour prints from the back door to the wet cobbles. Each right print has a crescent-shaped gap at the heel; the cobbles preserve nothing beyond it. A page is torn from an older delivery log. Its surviving edge carries the date and part of receipt 47, but not a customer name or the purpose of the entry. The closing-duty sheet is intact and is kept for later comparison. These are the findings at this scene, not an identification of the killer. The investigator has collected four separate accounts about the neighbors.  Hear all four before discussing which details establish access and which merely raise suspicion.\n\nThe investigator reads the supporting witness accounts before calling on the selected readers:\n\nWitness background for Marla Quinn: Nell Reed saw Marla Quinn leave the bakery back door at nine, carrying her red-handled scrubbing brush. Nell recognized the brass buckle and crescent-shaped repair in the right heel of her work boots because cobbler Della March had shown her that repair at collection yesterday. Flour was packed into the repaired heel. The shape resembles the yard prints recorded this morning. This ties the boots to bakery work and the doorway, but does not date when each print was made. The closing-duty sheet has not yet been checked against the sighting.\n\nWitness background for Jasper Crowe: Finn Moss saw Jasper Crowe waiting behind the bakery at half past nine, with a blue-strapped instrument case propped against the wall. Finn recognized the musician from the tavern and the case from carrying it after last week's performance. A pale streak ran across its lower corner where it touched a flour sack outside the door. Finn heard him ask Elias for a promised parcel, but did not see a parcel handed over or hear what it contained. Finn left for the delivery cart; he did not witness the death or the musician's departure.\n\nWitness background for Lydia Vance: Della March saw Lydia Vance arguing with Elias at the bakery front counter that morning. She recognized the teacher from collecting her granddaughter from school and saw the same green lesson folder under her arm. Della heard the teacher ask why a bread bill included a household's personal history. Elias folded a paper and refused to answer. The teacher left a chalky thumb mark on the counter when she leaned forward. Della identifies the person and the topic, but heard no threat and never saw the contents of the folded paper.\n\nWitness background for Xander Hale: Della March delivered a wooden chair to Xander Hale's workshop last week and saw Elias at the open door. She recognized both men from their regular work at her market stall. Elias refused to enter and said, \"I will not bring that old receipt here again.\" The woodworker stopped sanding, gripped the chair rail and asked which book Elias meant. Della saw fresh amber shellac on his apron beside the repair cloth, but no weapon. She can identify the reaction and the receipt dispute; she cannot identify the old transaction or turn that reaction into proof of murder.\n\nThe host reads the original neighbors' recorded responses:\nXander Hale's recorded response: \"I heard Nell saw Marla Quinn leave the bakery's back door at nine with her red-handled brush. Her repaired, flour-packed heel resembles those prints. I still need their timing checked.\"\nMarla Quinn's recorded response: \"I heard Finn saw Jasper Crowe behind the bakery at nine-thirty with his blue-strapped case. A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave.\"\nJasper Crowe's recorded response: \"I heard Della saw Lydia Vance argue with Elias that morning, her green lesson folder tucked under her arm. A bread bill held family history. I wonder why he folded that paper.\"\nLydia Vance's recorded response: \"I heard Della saw Elias refuse to enter Xander Hale's workshop over an old receipt. He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon.\"\n\nThe supplied witness accounts support these comparisons:\nNell Reed recorded flour prints with a crescent gap in the right heel.\nDella March recognized the repaired boot from its collection yesterday.\nFinn Moss found Elias and called Nell before anyone entered the yard.\nAda Bell has not supplied a tavern account at this stage.\nOwen Bell has not supplied a classroom account at this stage.\nEdith Shaw has not supplied an office account at this stage.\nTown Investigator reported one precise cut at the bakery.\nDella recognized Lydia through collecting Della's Granddaughter from school.",
        "publicText": "Elias Brim: throat slashed with one precise cut. Finn Moss found the body; Nell Reed recorded flour prints with a crescent gap in the right heel. An old delivery-log page is torn; only receipt 47 survives at its edge. The closing-duty sheet is intact.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "At dawn, delivery porter Finn Moss finds Elias Brim behind his bakery with his throat slashed.",
          "The investigator reports one clean, precise cut; the death happened off-screen.",
          "Elias supplied nearly every doorstep and recorded deliveries and closing chores in separate books."
        ],
        "readingGroups": [
          [
            "xander",
            "marla",
            "jasper"
          ],
          [
            "lydia"
          ],
          [
            "nell"
          ],
          [
            "della"
          ],
          [
            "finn"
          ]
        ],
        "chain": [
          "xander",
          "marla",
          "jasper",
          "lydia",
          "nell",
          "della",
          "finn"
        ],
        "coverageRepeat": false
      },
      {
        "title": "Round 2 - The Barkeep's Murder",
        "narration": "The next morning, cleaner Ada Bell finds Ronan Pike slumped over his tavern counter with his throat slashed. The investigator records the same precise cut as at the bakery. Ronan kept accounts of debts and stayed late for private appointments. Ada does not touch the mug beside him; Nell Reed records that it has been wiped and has no usable fingerprints. A thin amber smear remains beneath its handle. No owner has been established for the mug or the smear. Beneath Ronan's account book lies a scrap bearing receipt 47 and four lines of dates. No names or explanation survive on the scrap. The matching number links two sets of records, but does not identify their subject. Ronan's service tally and appointment book are preserved separately so that the last drink served will not be confused with the last visitor admitted. Four witness accounts are ready.  Listen for who saw an object, how they identified its owner and whether their timing actually reaches the death.\n\nThe investigator reads the supporting witness accounts before calling on the selected readers:\n\nWitness background for Jasper Crowe: Ada Bell saw Jasper Crowe put his instrument case on Ronan's counter at ten and leave after the last public drink was served. She recognized the case by its repaired blue strap, which she had sewn herself. He uses amber rosin on his bow; Ada collected a flake from the spot where the case rested. Its color resembles the smear beneath the wiped mug, but color alone cannot establish that they are the same material. Ronan locked the public door afterward; Ada did not watch the side entrance or the later appointments.\n\nWitness background for Lydia Vance: Ada Bell heard Lydia Vance tell Ronan at eight, \"Those are dangerous notes; people did not give you permission to record their families.\" Ada recognized the green lesson folder under the teacher's arm from her school-cleaning rounds. The teacher tapped Ronan's account book, leaving a white powder trace on its dark cover. Ada collected it as a possible chalk transfer, not a laboratory identification. The warning concerns records, but Ada saw no page removed. The teacher walked out through the public door; Ada could not observe who returned later.\n\nWitness background for Xander Hale: Ronan's repair invoice records Xander Hale replacing the tavern shelf last week. Ada Bell identified him from the signed invoice and saw him open a leather tool sleeve stamped with the same workshop address. Inside were sharpening stones Ronan called \"too fine for woodworking\": one was much narrower and smoother than the broad stone used on the shelf chisel. Ada saw him wipe the sleeve with an amber shellac-stained cloth from his repair kit. That establishes ownership of the stones and a second possible source of amber residue; it does not prove who handled the wiped mug on the night of the murder.\n\nWitness background for Marla Quinn: Della March heard Marla Quinn dispute an unpaid flour bill with Ronan outside the tavern at seven. She recognized the baker's assistant by the stamped delivery basket she was carrying. Ronan held a bill with a torn lower corner; the assistant produced a coin receipt, but Della was too far away to compare its amount. She saw the assistant leave with the basket toward the bakery. The argument supplies a specific grievance and an observed departure, not proof of payment or a witnessed return to the counter where Ronan died.\n\nThe host reads the original neighbors' recorded responses:\nXander Hale's recorded response: \"I heard Ada saw Jasper Crowe's blue-strapped case on Ronan's counter at ten. His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors.\"\nMarla Quinn's recorded response: \"I heard Ada heard Lydia Vance warn Ronan about recording families at eight. She touched his book, leaving possible chalk. I can't prove a removed page or a later return.\"\nJasper Crowe's recorded response: \"I read Xander Hale's shelf invoice; Ada saw fine sharpening stones in his address-stamped sleeve. His repair cloth held amber shellac. I see another possible smear source, not proof he touched that mug.\"\nLydia Vance's recorded response: \"I heard Della heard Marla Quinn dispute Ronan's flour bill at seven. She showed a receipt and left toward the bakery. I can't confirm payment or a later return.\"\n\nThe supplied witness accounts support these comparisons:\nNell Reed recorded a wiped mug without usable fingerprints.\nDella March heard Marla dispute the flour bill and leave toward the bakery.\nFinn Moss did not witness the bakery death or the musician leaving.\nAda Bell found Ronan and left the mug untouched.\nOwen Bell has not supplied a classroom account at this stage.\nEdith Shaw has not supplied an office account at this stage.\nTown Investigator reported the same precise cut at the tavern.\nDella's school collection of Della's Granddaughter explains her recognition of Lydia.",
        "publicText": "Ronan Pike: throat slashed with the same precise cut. Ada Bell found him. A wiped mug has no usable fingerprints and an unidentified amber smear beneath its handle. A dated scrap bears receipt 47 but no names. Service and appointment records are preserved.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "The next morning, cleaner Ada Bell finds Ronan Pike slumped over his tavern counter with his throat slashed.",
          "The investigator records the same precise cut as at the bakery.",
          "Ronan kept accounts of debts and stayed late for private appointments."
        ],
        "readingGroups": [
          [
            "xander",
            "jasper",
            "marla"
          ],
          [
            "lydia"
          ],
          [
            "nell"
          ],
          [
            "della"
          ],
          [
            "finn"
          ]
        ],
        "chain": [
          "xander",
          "jasper",
          "marla",
          "lydia",
          "nell",
          "della",
          "finn"
        ],
        "coverageRepeat": false
      },
      {
        "title": "Round 3 - The Schoolteacher's Murder",
        "narration": "Before sunrise, caretaker Owen Bell finds senior teacher Harper Wren in her classroom with her throat slashed, the same precise cut again. Harper taught most of the town's children and kept family records as carefully as lesson plans. Owen locks the room and fetches Nell Reed. She records a broad chalk smear across the desk and a narrow drag line through it, running from the student-record book toward its open drawer. A page is missing from that book. Its remaining index cites receipt 47; a margin note says, \"Copy kept with the original order.\" Neither the order's owner nor its location is recorded here. Owen also hands over the fundraiser attendance sheet and Harper's lesson diary, both intact. Three disturbed records now share a number. That is a link worth following, not yet an explanation.  Compare observed visits with the traces on the desk, and keep the identity of any missing document separate from guesses about it.\n\nThe investigator reads the supporting witness accounts before calling on the selected readers:\n\nWitness background for Lydia Vance: Owen Bell saw Lydia Vance enter Harper's classroom at six carrying her green lesson folder. He recognized her name written inside its cover when she left it beside the register. A broad chalk mark on the folder's edge matches the height of the smeared desk; Owen had watched her lean it there while discussing pupil privacy. Her warning was, \"A family record should not become a weapon.\" This explains regular access and a possible source of chalk transfer, but Owen left at seven and cannot account for the classroom overnight.\n\nWitness background for Xander Hale: Owen Bell recalls Harper pointing out Xander Hale's narrow whetstone while the woodworker repaired her drawer rail last Tuesday. Owen saw the stone in a leather sleeve stamped with the workshop's address; he checked that address on the repair invoice. Harper said he \"used to work with blades in another trade\" but did not name it. Owen also saw fresh blue chalk on the woodworker's cuff after measuring the rail with Harper's chalk line. That gives an ordinary source for the cuff mark, not an explanation of the missing page or the earlier blade skills.\n\nWitness background for Marla Quinn: Owen Bell signed for Marla Quinn's six-o'clock bread delivery to Harper on the morning before the death. He recognized the baker's stamped basket and the repaired brass-buckled boots described in Round 1. The delivery docket, signed by Harper, specifies the classroom door rather than the school kitchen. Owen saw the assistant wait while Harper opened the student-record drawer to find payment. This gives a witnessed reason for knowing Harper's schedule and seeing the drawer. Neither the flour on the boots nor that access proves a visit before sunrise on the fatal morning.\n\nWitness background for Jasper Crowe: Owen Bell checked Jasper Crowe's name on the fundraiser attendance sheet at nine the previous evening. He recognized the blue-strapped case and watched the musician leave it beside Harper's desk while stacking chairs. White chalk marked the case corner where it rubbed the desktop, covering part of the pale bakery streak described in Round 1. Owen identifies a source for the transfer and a reason for being in the room. He locked the public school door after the event, but did not remain to watch the classroom's separate yard entrance overnight.\n\nThe host reads the original neighbors' recorded responses:\nXander Hale's recorded response: \"I heard Owen saw Lydia Vance's green folder in Harper's classroom at six, discussing pupil privacy. Its chalk matches the desk height. I worry about access, but Owen left at seven.\"\nMarla Quinn's recorded response: \"I heard Harper said Xander Hale once worked with blades; Owen saw his narrow whetstone during her drawer repair. Chalk explains his cuff mark to me, not missing pages or blade skills.\"\nJasper Crowe's recorded response: \"I read Marla Quinn's signed six-o'clock bread delivery to Harper's classroom door. Owen saw her wait by the open records drawer. I see access, but not a fatal-morning visit.\"\nLydia Vance's recorded response: \"I read Jasper Crowe's nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak. I see how marks transfer, but Owen didn't watch the yard entrance overnight.\"\n\nThe supplied witness accounts support these comparisons:\nNell Reed recorded a chalk smear and narrow drag line through it.\nDella March identified Lydia and the topic of the bakery argument.\nFinn Moss heard a promised parcel requested but saw no handover.\nAda Bell saw the fine stones in an address-stamped sleeve.\nOwen Bell found Harper, locked the classroom and fetched Nell.\nEdith Shaw has not supplied an office account at this stage.\nTown Investigator connected three disturbed records by receipt 47.\nDella's collection of Della's Granddaughter identifies a teacher, not a threat.",
        "publicText": "Harper Wren: throat slashed with the same precise cut. Owen Bell found her; Nell Reed recorded chalk and a drag line beside a disturbed student-record book. Its index cites receipt 47 and a copy kept with an unnamed original order. Attendance and lesson records are intact.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "Before sunrise, caretaker Owen Bell finds senior teacher Harper Wren in her classroom with her throat slashed, the same precise cut again.",
          "Harper taught most of the town's children and kept family records as carefully as lesson plans.",
          "Owen locks the room and fetches Nell Reed."
        ],
        "readingGroups": [
          [
            "xander",
            "marla",
            "jasper"
          ],
          [
            "lydia"
          ],
          [
            "nell"
          ],
          [
            "della"
          ],
          [
            "finn"
          ]
        ],
        "chain": [
          "xander",
          "marla",
          "jasper",
          "lydia",
          "nell",
          "della",
          "finn"
        ],
        "coverageRepeat": true
      },
      {
        "title": "Round 4 - Visits and Transferred Marks",
        "narration": "Compare only the findings already read at the bakery, tavern and school. An evening delivery is not a fatal-morning visit; flour, rosin, shellac and chalk have witnessed work-related sources. Receipt 47 links disturbed records but does not yet identify their subject. Correct an accusation that mistakes a work trace or access for a witnessed killing. No new death, name, trade or weapon identification is introduced.",
        "publicText": "Correct earlier inferences using only already released evidence.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "Compare released work traces with the recorded visits.",
          "Correct unsupported accusations without a new discovery."
        ],
        "readingGroups": [
          [
            "xander",
            "jasper",
            "marla"
          ],
          [
            "lydia"
          ],
          [
            "nell"
          ],
          [
            "della"
          ],
          [
            "finn"
          ]
        ],
        "chain": [
          "xander",
          "jasper",
          "marla",
          "lydia",
          "nell",
          "della",
          "finn"
        ],
        "coverageRepeat": true
      },
      {
        "title": "Round 5 - The Lamplighter's Murder",
        "narration": "Before the morning market opens, Nell Reed finds Tobias Wick beside an extinguished streetlamp with his throat slashed in the same precise manner. Tobias walked every lane at night and kept route notes about what he saw. Lamp oil has spilled in a perfect circle around the lamp base. Nell records its position before moving the fallen oil flask; the shape of the spill alone cannot identify who was there. A page is torn from Tobias's old route notebook. The surviving index bears receipt 47 and the instruction, \"Retain duplicate with original order.\" Nell gathers the bakery closing-duty sheet, Ronan's appointment book and Harper's lesson diary for comparison with the earlier witness accounts. Their entries can explain a visit or correct a timing assumption, but they are not blanket alibis. The subject of the old records is still missing.  Let each account introduce its own new finding. Then compare the four scenes and ask which traces are ordinary work and which remain unexplained.\n\nThe investigator reads the supporting witness accounts before calling on the selected readers:\n\nWitness background for Marla Quinn: Nell Reed compares Marla Quinn's flour-marked repaired boot from Round 1 with the bakery closing-duty sheet. Elias initialed her nine-o'clock task: scrub the rear threshold, then deliver the waste pail to the market. The entry explains why the crescent heel and flour appeared at the doorway; it is not evidence that the print was made during the killing. Market seller Della March also records that the assistant reported Tobias arguing with an unidentified figure beside the oil stall last night. Della heard the report, not the argument, so she cannot identify that figure.\n\nWitness background for Jasper Crowe: Della March saw Jasper Crowe follow Tobias from the tavern to the market lamp at ten last night. She identified the musician by his blue-strapped case and by the tune he had just played at her stall. Tobias asked him to hold the oil flask while adjusting the wick; Della saw a drop spill onto his right sleeve. The stain therefore has an observed source, not merely an assumed link to lamplighting. Della closed her shutter before Tobias resumed his route. The musician's presence and oil stain establish contact, but not where either man went afterward.\n\nWitness background for Lydia Vance: Nell Reed finds Lydia Vance's warning to Tobias entered in his intact route book: \"Children's family affairs do not belong in street notes.\" The entry describes her green folder and the school gate, where Owen Bell confirms he saw them speak. Nell compares it with Harper's lesson diary, which schedules their weekly meetings to prepare lessons and handle family requests. These sources explain the teacher's meetings and concern about records without supplying an overnight alibi. They do not explain why the older page indexed under receipt 47 was torn out.\n\nWitness background for Xander Hale: Nell Reed saw Xander Hale beneath the workshop lamp yesterday evening, holding a straight razor rather than a woodworking chisel. She recognized him from the shelf-repair invoice she had collected at the tavern and spoke to him face to face. The open blade reflected the lamp; the ivory handle had a triangular chip beside its hinge. He closed it and put it into the address-stamped leather sleeve whose fine stones Ada Bell described in Round 2. Nell can identify the owner, object and distinctive damage, but she did not see an attack. The blade should be compared with the repeated precise cuts, not treated as a confession.\n\nThe host reads the original neighbors' recorded responses:\nXander Hale's recorded response: \"I read Marla Quinn's nine-o'clock closing duty: scrub the rear threshold, then take waste to market. I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone.\"\nMarla Quinn's recorded response: \"I heard Della saw Jasper Crowe follow Tobias to the market lamp at ten. He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward.\"\nJasper Crowe's recorded response: \"I read Lydia Vance's warning to Tobias: children's family affairs don't belong in street notes. Her weekly lesson meetings explain contact to me, not an overnight alibi or receipt 47's torn page.\"\nLydia Vance's recorded response: \"I heard Nell saw Xander Hale's straight razor: ivory handle, triangular chip beside its hinge. It went into his stamped sleeve. I worry about those precise cuts, not a confession.\"\n\nThe supplied witness accounts support these comparisons:\nNell Reed saw the chipped ivory razor enter the stamped sleeve.\nDella March saw Jasper holding the flask before oil spilled on his sleeve.\nFinn Moss left for the delivery cart without witnessing the bakery death.\nAda Bell saw the blue-strapped case on Ronan's counter at ten.\nOwen Bell left at seven without watching the separate yard entrance overnight.\nEdith Shaw has not supplied an office account at this stage.\nTown Investigator preserved the earlier work records for timing comparisons.\nDella's school collection of Della's Granddaughter does not identify a murderer.",
        "publicText": "Tobias Wick: throat slashed with the same precise cut. Nell Reed found him beside an extinguished lamp and a circle of spilled oil. A torn night-route page is indexed under receipt 47. Earlier work and appointment records are ready for comparison, not complete alibis.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "Before the morning market opens, Nell Reed finds Tobias Wick beside an extinguished streetlamp with his throat slashed in the same precise manner.",
          "Tobias walked every lane at night and kept route notes about what he saw.",
          "Lamp oil has spilled in a perfect circle around the lamp base."
        ],
        "readingGroups": [
          [
            "xander",
            "marla",
            "jasper"
          ],
          [
            "lydia"
          ],
          [
            "nell"
          ],
          [
            "della"
          ],
          [
            "finn"
          ]
        ],
        "chain": [
          "xander",
          "marla",
          "jasper",
          "lydia",
          "nell",
          "della",
          "finn"
        ],
        "coverageRepeat": true
      },
      {
        "title": "Round 6 - Work Traces and the Identified Tool",
        "narration": "Compare the already released closing-duty sheet, private-appointment records, school visits and Nell's chipped-razor sighting. A work record can explain a trace without supplying an overnight alibi. The identified razor is more specific than an unexplained color or stain, but its sighting is not a confession. Correct earlier accusations based only on flour, chalk or spilled oil. No new death or old identity is introduced.",
        "publicText": "Correct earlier inferences using only already released evidence.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "Compare released work traces with the recorded visits.",
          "Correct unsupported accusations without a new discovery."
        ],
        "readingGroups": [
          [
            "xander",
            "jasper",
            "marla"
          ],
          [
            "lydia"
          ],
          [
            "nell"
          ],
          [
            "della"
          ],
          [
            "finn"
          ]
        ],
        "chain": [
          "xander",
          "jasper",
          "marla",
          "lydia",
          "nell",
          "della",
          "finn"
        ],
        "coverageRepeat": true
      },
      {
        "title": "Round 7 - The Mayor's Murder",
        "narration": "Office clerk Edith Shaw finds Mayor Aldric Thorne in his office chair with his throat slashed, the same precise cut. A polished straight razor lies on the desk, its ivory handle chipped beside the hinge. Edith calls Nell Reed and identifies the locked cabinet from which the papers on the desk came; its numbered index and broken wax seal allow the investigator to trace their source. A single old court document, signed by Thorne, orders the imprisonment of BENJAMIN BARKER and bears receipt 47. This is the first time that name enters the investigation. With it are the duplicate records referred to in Harper's index and Tobias's notebook. The investigator reads them aloud: Elias signed a false delivery entry placing Barker at a theft; Ronan signed a fabricated account of a confession; Harper altered a household record to support the charge; Tobias supplied a false night-route sighting. A retained letter from Thorne orders the changes, admits that he wanted Barker's wife and describes using imprisonment to separate them. The household record states that she was taken into Thorne's household under coercion, not by free choice. Barker's licensed occupation is barber. A likeness, address and tool inventory are attached, but the investigator leaves their identification to the witnesses whose accounts you are about to hear. These documents establish the original injustice and the four victims' roles. They do not announce which current neighbor committed the murders.  Hear every account before the final vote.\n\nThe investigator reads the supporting witness accounts before calling on the selected readers:\n\nWitness background for Jasper Crowe: Edith Shaw asks Jasper Crowe to explain a rumor he heard at the tavern about the woodworker once using a different name. He identifies its source as Ronan's remark about an old license, not personal knowledge of the imprisonment. Edith compares the signature on his ten-o'clock drink receipt with the appointment book preserved in Round 2; it confirms his earlier visit, while a separate eleven-o'clock entry admits a private visitor. His rosin flake explains a substance on the counter, but neither the rumor nor the flake identifies that later visitor or makes him a signer of the false statements in the court file.\n\nWitness background for Lydia Vance: Edith Shaw compares Lydia Vance's account of seeing the Mayor hide an old paper with the cabinet index recovered today. The teacher dates the sighting to a school-funding appointment entered in Edith's diary; Edith confirms she admitted her for that appointment and saw Thorne close the folder. The teacher could read receipt 47, but not the name hidden beneath his hand. This explains why the teacher questioned intrusive family records. Her chalk-marked folder and weekly lesson meetings establish access to school papers, not a signature on the falsified statements read from the court file.\n\nWitness background for Xander Hale: Edith Shaw identifies the court file's licensed likeness as Xander Hale; she compares the workshop address printed beside it with the signed shelf-repair invoice preserved in Round 2. The licensed name is Benjamin Barker. The barber's tool inventory describes an ivory razor with a chip beside the hinge, matching the blade Nell Reed saw in his hand in Round 4 and the one now on Thorne's desk. The fine stones and Harper's earlier-trade remark fit the documented occupation. The duplicate records identify the four people who helped Thorne destroy his former life. This joins identity, blade ownership and motive; the room must still decide its final accusation.\n\nWitness background for Marla Quinn: Edith Shaw checks Marla Quinn's account of an old visit by Thorne to the workshop home. The assistant remembers delivering a baker's basket there as a child; the retained delivery copy records the date and the house number. Edith compares those details with Thorne's appointment diary and confirms the visit. The account links a remembered visit to a documented place, but the assistant did not hear the conversation. Her repaired flour-marked boot still fits the closing chore established in Round 4, not a proven killing. Neither her childhood observation nor her recent bread delivery makes her one of the signers identified in the old file.\n\nThe host reads the original neighbors' recorded responses:\nXander Hale's recorded response: \"I heard Jasper Crowe's different-name rumor came from Ronan's old-license remark. His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin.\"\nMarla Quinn's recorded response: \"I learned Lydia Vance saw Thorne hide receipt 47 during her confirmed school-funding appointment. She couldn't read the name. I see why she questioned family records, not proof she falsified them.\"\nJasper Crowe's recorded response: \"I heard Edith match Xander Hale's licensed likeness and workshop address: Benjamin Barker, barber. His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse.\"\nLydia Vance's recorded response: \"I heard Edith confirm Marla Quinn's childhood delivery during Thorne's old workshop-home visit. She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot.\"\n\nThe supplied witness accounts support these comparisons:\nNell Reed identified the damaged razor in the earlier sighting.\nDella March's boot identification established work access, not print timing.\nFinn Moss's case account established an evening visit, not a witnessed murder.\nAda Bell's account left later private visitors possible.\nOwen Bell's accounts did not establish an overnight alibi.\nEdith Shaw matched the licensed likeness and address to Xander.\nTown Investigator read the retained duplicate records and Thorne's letter.\nDella's identification through Della's Granddaughter does not implicate Lydia in the old falsification.",
        "publicText": "Mayor Aldric Thorne: throat slashed; a polished razor with a chipped ivory handle on his desk. Edith Shaw identifies the cabinet and record index. Thorne's signed imprisonment order names Benjamin Barker under receipt 47. Duplicate records and his letter expose the four victims' false statements and his coercion. Witness identification follows in the player readings.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "Office clerk Edith Shaw finds Mayor Aldric Thorne in his office chair with his throat slashed, the same precise cut.",
          "A polished straight razor lies on the desk, its ivory handle chipped beside the hinge.",
          "Edith calls Nell Reed and identifies the locked cabinet from which the papers on the desk came; its numbered index and broken wax seal allow the investigator to trace their source."
        ],
        "readingGroups": [
          [
            "xander",
            "marla",
            "jasper"
          ],
          [
            "lydia"
          ],
          [
            "nell"
          ],
          [
            "della"
          ],
          [
            "finn"
          ]
        ],
        "chain": [
          "xander",
          "marla",
          "jasper",
          "lydia",
          "nell",
          "della",
          "finn"
        ],
        "coverageRepeat": true
      }
    ],
    "characters": [
      {
        "id": "xander",
        "name": "Xander Hale",
        "role": "Woodworker",
        "relationship": "A neighbor asked by the town investigator to help compare witness accounts of the Blackwater Row murders.",
        "tieIn": "A quiet craftsperson who repairs furniture and makes wooden fittings in a workshop off the market lane.",
        "optional": false,
        "ghost": null,
        "guest": "",
        "guestNote": "",
        "publicBlurb": "A quiet craftsperson who repairs furniture and makes wooden fittings in a workshop off the market lane.",
        "rounds": [
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I heard Nell saw {marla} leave the bakery's back door at nine with her red-handled brush. Her repaired, flour-packed heel resembles those prints. I still need their timing checked.",
              "observation": "I heard Nell saw {marla} leave the bakery's back door at nine with her red-handled brush.",
              "contradictingDetail": "Her repaired, flour-packed heel resembles those prints. I still need their timing checked."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I heard Ada saw {jasper}'s blue-strapped case on Ronan's counter at ten. His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors.",
              "observation": "I heard Ada saw {jasper}'s blue-strapped case on Ronan's counter at ten.",
              "contradictingDetail": "His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I read {marla}'s signed six-o'clock bread delivery to Harper's classroom door. Owen saw her wait by the open records drawer. I see access, but not a fatal-morning visit.",
              "observation": "I read {marla}'s signed six-o'clock bread delivery to Harper's classroom door.",
              "contradictingDetail": "Owen saw her wait by the open records drawer. I see access, but not a fatal-morning visit."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I heard {jasper}'s case rubbed the chalky desk over its flour streak. I must distinguish transferred work marks from evidence that he removed the student-record page.",
              "observation": "I heard {jasper}'s case rubbed the chalky desk over its flour streak.",
              "contradictingDetail": "I must distinguish transferred work marks from evidence that he removed the student-record page."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I read {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market. I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone.",
              "observation": "I read {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market.",
              "contradictingDetail": "I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I read {jasper}'s visit to the lamp in Della's account. I must not treat spilled oil on his sleeve as proof of a precise cut or an account of his later movements.",
              "observation": "I read {jasper}'s visit to the lamp in Della's account.",
              "contradictingDetail": "I must not treat spilled oil on his sleeve as proof of a precise cut or an account of his later movements."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I heard Edith confirm {marla}'s childhood delivery during Thorne's old workshop-home visit. She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot.",
              "observation": "I heard Edith confirm {marla}'s childhood delivery during Thorne's old workshop-home visit.",
              "contradictingDetail": "She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot."
            }
          }
        ]
      },
      {
        "id": "marla",
        "name": "Marla Quinn",
        "role": "Baker's assistant",
        "relationship": "Assistant to the first victim, the baker Elias Brim; asked to help compare witness accounts.",
        "tieIn": "Elias Brim's assistant, responsible for bread deliveries and the evening cleanup. A familiar face at doorsteps across town.",
        "optional": false,
        "ghost": null,
        "guest": "",
        "guestNote": "",
        "publicBlurb": "Elias Brim's assistant, responsible for bread deliveries and the evening cleanup. A familiar face at doorsteps across town.",
        "rounds": [
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I heard Finn saw {jasper} behind the bakery at nine-thirty with his blue-strapped case. A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave.",
              "observation": "I heard Finn saw {jasper} behind the bakery at nine-thirty with his blue-strapped case.",
              "contradictingDetail": "A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I read {xander}'s shelf invoice; Ada saw fine sharpening stones in his address-stamped sleeve. His repair cloth held amber shellac. I see another possible smear source, not proof he touched that mug.",
              "observation": "I read {xander}'s shelf invoice; Ada saw fine sharpening stones in his address-stamped sleeve.",
              "contradictingDetail": "His repair cloth held amber shellac. I see another possible smear source, not proof he touched that mug."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I read {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak. I see how marks transfer, but Owen didn't watch the yard entrance overnight.",
              "observation": "I read {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak.",
              "contradictingDetail": "I see how marks transfer, but Owen didn't watch the yard entrance overnight."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard {xander}'s drawer repair explained chalk on his cuff. I must not mistake a work mark for an explanation of the missing pages or his earlier blade skills.",
              "observation": "I heard {xander}'s drawer repair explained chalk on his cuff.",
              "contradictingDetail": "I must not mistake a work mark for an explanation of the missing pages or his earlier blade skills."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I heard Della saw {jasper} follow Tobias to the market lamp at ten. He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward.",
              "observation": "I heard Della saw {jasper} follow Tobias to the market lamp at ten.",
              "contradictingDetail": "He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard Nell identify {xander}'s chipped ivory razor. I must compare that identifiable tool with the repeated cuts, not call the sighting a confession.",
              "observation": "I heard Nell identify {xander}'s chipped ivory razor.",
              "contradictingDetail": "I must compare that identifiable tool with the repeated cuts, not call the sighting a confession."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I heard {jasper}'s different-name rumor came from Ronan's old-license remark. His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin.",
              "observation": "I heard {jasper}'s different-name rumor came from Ronan's old-license remark.",
              "contradictingDetail": "His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin."
            }
          }
        ]
      },
      {
        "id": "jasper",
        "name": "Jasper Crowe",
        "role": "Tavern musician",
        "relationship": "Musician at the tavern of the second victim, Ronan Pike; asked to help compare witness accounts.",
        "tieIn": "A musician at Ronan Pike's tavern who also plays for town events. Often out late carrying his instrument between jobs.",
        "optional": false,
        "ghost": null,
        "guest": "",
        "guestNote": "",
        "publicBlurb": "A musician at Ronan Pike's tavern who also plays for town events. Often out late carrying his instrument between jobs.",
        "rounds": [
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard Della saw Elias refuse to enter {xander}'s workshop over an old receipt. He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon.",
              "observation": "I heard Della saw Elias refuse to enter {xander}'s workshop over an old receipt.",
              "contradictingDetail": "He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I heard Della heard {marla} dispute Ronan's flour bill at seven. She showed a receipt and left toward the bakery. I can't confirm payment or a later return.",
              "observation": "I heard Della heard {marla} dispute Ronan's flour bill at seven.",
              "contradictingDetail": "She showed a receipt and left toward the bakery. I can't confirm payment or a later return."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair. Chalk explains his cuff mark to me, not missing pages or blade skills.",
              "observation": "I heard Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair.",
              "contradictingDetail": "Chalk explains his cuff mark to me, not missing pages or blade skills."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I read {marla}'s signed bread delivery at six. I must distinguish an evening delivery from a fatal-morning visit; access alone does not explain the missing page.",
              "observation": "I read {marla}'s signed bread delivery at six.",
              "contradictingDetail": "I must distinguish an evening delivery from a fatal-morning visit; access alone does not explain the missing page."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge. It went into his stamped sleeve. I worry about those precise cuts, not a confession.",
              "observation": "I heard Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge.",
              "contradictingDetail": "It went into his stamped sleeve. I worry about those precise cuts, not a confession."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I read {marla}'s closing duty to scrub the rear threshold. I must correct my earlier suspicion: flour in her repaired heel can come from work, not a witnessed killing.",
              "observation": "I read {marla}'s closing duty to scrub the rear threshold.",
              "contradictingDetail": "I must correct my earlier suspicion: flour in her repaired heel can come from work, not a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard Edith match {xander}'s licensed likeness and workshop address: Benjamin Barker, barber. His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse.",
              "observation": "I heard Edith match {xander}'s licensed likeness and workshop address: Benjamin Barker, barber.",
              "contradictingDetail": "His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse."
            }
          }
        ]
      },
      {
        "id": "lydia",
        "name": "Lydia Vance",
        "role": "Schoolteacher",
        "relationship": "Teacher working alongside the third victim, senior teacher Harper Wren; asked to help compare witness accounts.",
        "tieIn": "A teacher working alongside senior teacher Harper Wren. Attentive to local families and protective of their privacy.",
        "publicBlurb": "A teacher working alongside senior teacher Harper Wren. Attentive to local families and protective of their privacy.",
        "optional": false,
        "guest": "",
        "guestNote": "",
        "ghost": null,
        "rounds": [
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I learned Della saw Elias refuse to enter {xander}'s workshop over an old receipt. He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon.",
              "observation": "I learned Della saw Elias refuse to enter {xander}'s workshop over an old receipt.",
              "contradictingDetail": "He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I learned Della heard {marla} dispute Ronan's flour bill at seven. She showed a receipt and left toward the bakery. I can't confirm payment or a later return.",
              "observation": "I learned Della heard {marla} dispute Ronan's flour bill at seven.",
              "contradictingDetail": "She showed a receipt and left toward the bakery. I can't confirm payment or a later return."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I checked {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak. I see how marks transfer, but Owen didn't watch the yard entrance overnight.",
              "observation": "I checked {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak.",
              "contradictingDetail": "I see how marks transfer, but Owen didn't watch the yard entrance overnight."
            }
          },
          {
            "readAloud": {
              "accuses": "nell",
              "text": "I heard the account: {nell} recorded a chalk smear and narrow drag line through it. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: {nell} recorded a chalk smear and narrow drag line through it.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "della",
              "text": "I heard the account: {della} saw Jasper holding the flask before oil spilled on his sleeve. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {della} saw Jasper holding the flask before oil spilled on his sleeve.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "finn",
              "text": "I heard the account: {finn} left for the delivery cart without witnessing the bakery death. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: {finn} left for the delivery cart without witnessing the bakery death.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I learned Edith match {xander}'s licensed likeness and workshop address: Benjamin Barker, barber. His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse.",
              "observation": "I learned Edith match {xander}'s licensed likeness and workshop address: Benjamin Barker, barber.",
              "contradictingDetail": "His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse."
            }
          }
        ]
      },
      {
        "id": "nell",
        "name": "Nell Reed",
        "role": "Night watchwoman",
        "relationship": "An existing person in the supplied Blackwater Row accounts.",
        "tieIn": "Records the scene findings and supplies the razor sighting.",
        "publicBlurb": "Records the scene findings and supplies the razor sighting.",
        "optional": false,
        "guest": "",
        "guestNote": "",
        "ghost": null,
        "rounds": [
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I learned Nell saw {marla} leave the bakery's back door at nine with her red-handled brush. Her repaired, flour-packed heel resembles those prints. I still need their timing checked.",
              "observation": "I learned Nell saw {marla} leave the bakery's back door at nine with her red-handled brush.",
              "contradictingDetail": "Her repaired, flour-packed heel resembles those prints. I still need their timing checked."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I learned Ada saw {jasper}'s blue-strapped case on Ronan's counter at ten. His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors.",
              "observation": "I learned Ada saw {jasper}'s blue-strapped case on Ronan's counter at ten.",
              "contradictingDetail": "His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors."
            }
          },
          {
            "readAloud": {
              "accuses": "lydia",
              "text": "I learned Owen saw {lydia}'s green folder in Harper's classroom at six, discussing pupil privacy. Its chalk matches the desk height. I worry about access, but Owen left at seven.",
              "observation": "I learned Owen saw {lydia}'s green folder in Harper's classroom at six, discussing pupil privacy.",
              "contradictingDetail": "Its chalk matches the desk height. I worry about access, but Owen left at seven."
            }
          },
          {
            "readAloud": {
              "accuses": "della",
              "text": "I heard the account: {della} identified Lydia and the topic of the bakery argument. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: {della} identified Lydia and the topic of the bakery argument.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "finn",
              "text": "I heard the account: {finn} left for the delivery cart without witnessing the bakery death. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {finn} left for the delivery cart without witnessing the bakery death.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I learned Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge. It went into his stamped sleeve. I worry about those precise cuts, not a confession.",
              "observation": "I learned Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge.",
              "contradictingDetail": "It went into his stamped sleeve. I worry about those precise cuts, not a confession."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I learned Edith confirm {marla}'s childhood delivery during Thorne's old workshop-home visit. She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot.",
              "observation": "I learned Edith confirm {marla}'s childhood delivery during Thorne's old workshop-home visit.",
              "contradictingDetail": "She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot."
            }
          }
        ]
      },
      {
        "id": "della",
        "name": "Della March",
        "role": "Cobbler",
        "relationship": "An existing person in the supplied Blackwater Row accounts.",
        "tieIn": "Identifies the repaired boot and the neighbors in her recorded accounts.",
        "publicBlurb": "Identifies the repaired boot and the neighbors in her recorded accounts.",
        "optional": false,
        "guest": "",
        "guestNote": "",
        "ghost": null,
        "rounds": [
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I learned Finn saw {jasper} behind the bakery at nine-thirty with his blue-strapped case. A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave.",
              "observation": "I learned Finn saw {jasper} behind the bakery at nine-thirty with his blue-strapped case.",
              "contradictingDetail": "A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave."
            }
          },
          {
            "readAloud": {
              "accuses": "lydia",
              "text": "I learned Ada heard {lydia} warn Ronan about recording families at eight. She touched his book, leaving possible chalk. I can't prove a removed page or a later return.",
              "observation": "I learned Ada heard {lydia} warn Ronan about recording families at eight.",
              "contradictingDetail": "She touched his book, leaving possible chalk. I can't prove a removed page or a later return."
            }
          },
          {
            "readAloud": {
              "accuses": "nell",
              "text": "I heard the account: {nell} recorded a chalk smear and narrow drag line through it. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {nell} recorded a chalk smear and narrow drag line through it.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "finn",
              "text": "I heard the account: {finn} heard a promised parcel requested but saw no handover. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: {finn} heard a promised parcel requested but saw no handover.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I learned Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge. It went into his stamped sleeve. I worry about those precise cuts, not a confession.",
              "observation": "I learned Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge.",
              "contradictingDetail": "It went into his stamped sleeve. I worry about those precise cuts, not a confession."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I checked {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market. I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone.",
              "observation": "I checked {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market.",
              "contradictingDetail": "I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I learned {jasper}'s different-name rumor came from Ronan's old-license remark. His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin.",
              "observation": "I learned {jasper}'s different-name rumor came from Ronan's old-license remark.",
              "contradictingDetail": "His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin."
            }
          }
        ]
      },
      {
        "id": "finn",
        "name": "Finn Moss",
        "role": "Delivery porter",
        "relationship": "An existing person in the supplied Blackwater Row accounts.",
        "tieIn": "Finds Elias and reports the musician waiting behind the bakery.",
        "publicBlurb": "Finds Elias and reports the musician waiting behind the bakery.",
        "optional": false,
        "guest": "",
        "guestNote": "",
        "ghost": null,
        "rounds": [
          {
            "readAloud": {
              "accuses": "lydia",
              "text": "I learned Della saw {lydia} argue with Elias that morning, her green lesson folder tucked under her arm. A bread bill held family history. I wonder why he folded that paper.",
              "observation": "I learned Della saw {lydia} argue with Elias that morning, her green lesson folder tucked under her arm.",
              "contradictingDetail": "A bread bill held family history. I wonder why he folded that paper."
            }
          },
          {
            "readAloud": {
              "accuses": "nell",
              "text": "I heard the account: {nell} recorded a wiped mug without usable fingerprints. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {nell} recorded a wiped mug without usable fingerprints.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "della",
              "text": "I heard the account: {della} identified Lydia and the topic of the bakery argument. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {della} identified Lydia and the topic of the bakery argument.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I learned Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair. Chalk explains his cuff mark to me, not missing pages or blade skills.",
              "observation": "I learned Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair.",
              "contradictingDetail": "Chalk explains his cuff mark to me, not missing pages or blade skills."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I checked {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market. I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone.",
              "observation": "I checked {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market.",
              "contradictingDetail": "I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I learned Della saw {jasper} follow Tobias to the market lamp at ten. He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward.",
              "observation": "I learned Della saw {jasper} follow Tobias to the market lamp at ten.",
              "contradictingDetail": "He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward."
            }
          },
          {
            "readAloud": {
              "accuses": "lydia",
              "text": "I heard {lydia} saw Thorne hide receipt 47 during her confirmed school-funding appointment. She couldn't read the name. I see why she questioned family records, not proof she falsified them.",
              "observation": "I heard {lydia} saw Thorne hide receipt 47 during her confirmed school-funding appointment.",
              "contradictingDetail": "She couldn't read the name. I see why she questioned family records, not proof she falsified them."
            }
          }
        ]
      }
    ],
    "finale": {
      "narration": "All seven chapters and the final witness accounts have now been read. Compare the identified blade, the licensed likeness and address, and the duplicate records with the earlier observations. Decide which neighbor accounts for the complete chain, not just one suspicious trace. A reason for revenge can explain a crime without excusing it. Make your final accusation before the investigator announces the solution.",
      "votePrompt": "Who do you accuse based on the evidence heard so far?"
    },
    "solution": {
      "killerId": "xander",
      "explanation": "Xander Hale is Benjamin Barker, formerly Blackwater Row's trusted barber, and he committed all five murders. Thorne's letter and court file, first read in Round 7, establish that the Mayor wanted Barker's wife, framed him, ordered his imprisonment and forced her into his household. Elias's false delivery entry, Ronan's invented confession, Harper's altered household record and Tobias's false night sighting helped destroy Barker's married life. After release, Barker returned as the woodworker Xander Hale. The fine stones in his address-stamped sleeve and Harper's earlier-trade remark established a blade skill without naming it. Nell's direct observation of the chipped ivory razor in Round 5 supplied identifiable ownership; Edith's Round 7 comparison joined that razor, the licensed likeness and the repair invoice to the old identity. Receipt 47 linked the disturbed records; retained duplicates explained the target selection. Marla's repaired flour-marked boot had a documented closing-chore source. Jasper's case and rosin and Lydia's folder and chalk had witnessed work-related sources; their movements raised questions but did not explain the complete identity, weapon and motive chain. No stain alone proved a killing. Barker killed the four accomplices before reaching his final target, the Mayor. This was deliberate revenge, not justice.",
      "revealNarration": "The investigator closes the court file. \"The killer is {xander}. His former name was Benjamin Barker, and his former trade was barber. Nell identified the damaged razor in his hand; Edith matched the license and address to his current work. The earlier victims supplied the false statements that destroyed his former life. Thorne was his final target.\"\n\nThe host may read Barker's final words: \"Once this town knew me as Benjamin Barker. I had a trade, a wife and a home. Thorne wanted what was not his, and four respectable voices made his lie sound like law. When I returned, I called myself Xander Hale and worked in wood. I thought a new name could bury the old one. Instead I carried it through every door. I chose revenge, and I killed them. It did not restore my wife's freedom or the years we lost. Nothing they did makes these murders right.\"\n\nBlackwater Row must now reckon with both the original injustice and the five deaths that followed."
    },
    "masterPreserving": true,
    "conversion": {
      "source": "Committed four-player Blackwater Row revision 3.",
      "changes": [
        {
          "original": "Five discovery chapters and four playable neighbors.",
          "replacement": "Five unchanged discovery sequences with two intervening comparison chapters and a three-player core.",
          "reason": "Seven-round requirement and smallest-edition master. Identity remains in the last discovery chapter; no murders or facts are added."
        },
        {
          "original": "Per-chapter four-player reader handoffs and twenty player responses.",
          "replacement": "Named recorded responses in shared narration and count-specific group order.",
          "reason": "Preserve every witness source and original response while selecting a three-player loop."
        },
        {
          "original": "Solution timing references to Round 4 and Round 5.",
          "replacement": "Corresponding seven-chapter references to Round 5 and Round 7.",
          "reason": "Inserted comparison rounds shift chapter numbers without advancing evidence."
        }
      ],
      "originalResponses": [
        {
          "id": "xander",
          "rounds": [
            {
              "readAloud": {
                "accuses": "marla",
                "text": "I heard Nell saw {marla} leave the bakery's back door at nine with her red-handled brush. Her repaired, flour-packed heel resembles those prints. I still need their timing checked.",
                "observation": "I heard Nell saw {marla} leave the bakery's back door at nine with her red-handled brush.",
                "contradictingDetail": "Her repaired, flour-packed heel resembles those prints. I still need their timing checked."
              }
            },
            {
              "readAloud": {
                "accuses": "jasper",
                "text": "I heard Ada saw {jasper}'s blue-strapped case on Ronan's counter at ten. His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors.",
                "observation": "I heard Ada saw {jasper}'s blue-strapped case on Ronan's counter at ten.",
                "contradictingDetail": "His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors."
              }
            },
            {
              "readAloud": {
                "accuses": "lydia",
                "text": "I heard Owen saw {lydia}'s green folder in Harper's classroom at six, discussing pupil privacy. Its chalk matches the desk height. I worry about access, but Owen left at seven.",
                "observation": "I heard Owen saw {lydia}'s green folder in Harper's classroom at six, discussing pupil privacy.",
                "contradictingDetail": "Its chalk matches the desk height. I worry about access, but Owen left at seven."
              }
            },
            {
              "readAloud": {
                "accuses": "marla",
                "text": "I read {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market. I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone.",
                "observation": "I read {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market.",
                "contradictingDetail": "I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone."
              }
            },
            {
              "readAloud": {
                "accuses": "jasper",
                "text": "I heard {jasper}'s different-name rumor came from Ronan's old-license remark. His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin.",
                "observation": "I heard {jasper}'s different-name rumor came from Ronan's old-license remark.",
                "contradictingDetail": "His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin."
              }
            }
          ]
        },
        {
          "id": "marla",
          "rounds": [
            {
              "readAloud": {
                "accuses": "jasper",
                "text": "I heard Finn saw {jasper} behind the bakery at nine-thirty with his blue-strapped case. A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave.",
                "observation": "I heard Finn saw {jasper} behind the bakery at nine-thirty with his blue-strapped case.",
                "contradictingDetail": "A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave."
              }
            },
            {
              "readAloud": {
                "accuses": "lydia",
                "text": "I heard Ada heard {lydia} warn Ronan about recording families at eight. She touched his book, leaving possible chalk. I can't prove a removed page or a later return.",
                "observation": "I heard Ada heard {lydia} warn Ronan about recording families at eight.",
                "contradictingDetail": "She touched his book, leaving possible chalk. I can't prove a removed page or a later return."
              }
            },
            {
              "readAloud": {
                "accuses": "xander",
                "text": "I heard Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair. Chalk explains his cuff mark to me, not missing pages or blade skills.",
                "observation": "I heard Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair.",
                "contradictingDetail": "Chalk explains his cuff mark to me, not missing pages or blade skills."
              }
            },
            {
              "readAloud": {
                "accuses": "jasper",
                "text": "I heard Della saw {jasper} follow Tobias to the market lamp at ten. He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward.",
                "observation": "I heard Della saw {jasper} follow Tobias to the market lamp at ten.",
                "contradictingDetail": "He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward."
              }
            },
            {
              "readAloud": {
                "accuses": "lydia",
                "text": "I learned {lydia} saw Thorne hide receipt 47 during her confirmed school-funding appointment. She couldn't read the name. I see why she questioned family records, not proof she falsified them.",
                "observation": "I learned {lydia} saw Thorne hide receipt 47 during her confirmed school-funding appointment.",
                "contradictingDetail": "She couldn't read the name. I see why she questioned family records, not proof she falsified them."
              }
            }
          ]
        },
        {
          "id": "jasper",
          "rounds": [
            {
              "readAloud": {
                "accuses": "lydia",
                "text": "I heard Della saw {lydia} argue with Elias that morning, her green lesson folder tucked under her arm. A bread bill held family history. I wonder why he folded that paper.",
                "observation": "I heard Della saw {lydia} argue with Elias that morning, her green lesson folder tucked under her arm.",
                "contradictingDetail": "A bread bill held family history. I wonder why he folded that paper."
              }
            },
            {
              "readAloud": {
                "accuses": "xander",
                "text": "I read {xander}'s shelf invoice; Ada saw fine sharpening stones in his address-stamped sleeve. His repair cloth held amber shellac. I see another possible smear source, not proof he touched that mug.",
                "observation": "I read {xander}'s shelf invoice; Ada saw fine sharpening stones in his address-stamped sleeve.",
                "contradictingDetail": "His repair cloth held amber shellac. I see another possible smear source, not proof he touched that mug."
              }
            },
            {
              "readAloud": {
                "accuses": "marla",
                "text": "I read {marla}'s signed six-o'clock bread delivery to Harper's classroom door. Owen saw her wait by the open records drawer. I see access, but not a fatal-morning visit.",
                "observation": "I read {marla}'s signed six-o'clock bread delivery to Harper's classroom door.",
                "contradictingDetail": "Owen saw her wait by the open records drawer. I see access, but not a fatal-morning visit."
              }
            },
            {
              "readAloud": {
                "accuses": "lydia",
                "text": "I read {lydia}'s warning to Tobias: children's family affairs don't belong in street notes. Her weekly lesson meetings explain contact to me, not an overnight alibi or receipt 47's torn page.",
                "observation": "I read {lydia}'s warning to Tobias: children's family affairs don't belong in street notes.",
                "contradictingDetail": "Her weekly lesson meetings explain contact to me, not an overnight alibi or receipt 47's torn page."
              }
            },
            {
              "readAloud": {
                "accuses": "xander",
                "text": "I heard Edith match {xander}'s licensed likeness and workshop address: Benjamin Barker, barber. His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse.",
                "observation": "I heard Edith match {xander}'s licensed likeness and workshop address: Benjamin Barker, barber.",
                "contradictingDetail": "His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse."
              }
            }
          ]
        },
        {
          "id": "lydia",
          "rounds": [
            {
              "readAloud": {
                "accuses": "xander",
                "text": "I heard Della saw Elias refuse to enter {xander}'s workshop over an old receipt. He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon.",
                "observation": "I heard Della saw Elias refuse to enter {xander}'s workshop over an old receipt.",
                "contradictingDetail": "He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon."
              }
            },
            {
              "readAloud": {
                "accuses": "marla",
                "text": "I heard Della heard {marla} dispute Ronan's flour bill at seven. She showed a receipt and left toward the bakery. I can't confirm payment or a later return.",
                "observation": "I heard Della heard {marla} dispute Ronan's flour bill at seven.",
                "contradictingDetail": "She showed a receipt and left toward the bakery. I can't confirm payment or a later return."
              }
            },
            {
              "readAloud": {
                "accuses": "jasper",
                "text": "I read {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak. I see how marks transfer, but Owen didn't watch the yard entrance overnight.",
                "observation": "I read {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak.",
                "contradictingDetail": "I see how marks transfer, but Owen didn't watch the yard entrance overnight."
              }
            },
            {
              "readAloud": {
                "accuses": "xander",
                "text": "I heard Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge. It went into his stamped sleeve. I worry about those precise cuts, not a confession.",
                "observation": "I heard Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge.",
                "contradictingDetail": "It went into his stamped sleeve. I worry about those precise cuts, not a confession."
              }
            },
            {
              "readAloud": {
                "accuses": "marla",
                "text": "I heard Edith confirm {marla}'s childhood delivery during Thorne's old workshop-home visit. She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot.",
                "observation": "I heard Edith confirm {marla}'s childhood delivery during Thorne's old workshop-home visit.",
                "contradictingDetail": "She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot."
              }
            }
          ]
        }
      ]
    }
  },
  "8": {
    "schemaVersion": 2,
    "fixedPlayerCount": 8,
    "discloseKiller": false,
    "clueRouting": "rotating",
    "edition": {
      "family": "blackwater-scalable",
      "id": "blackwater-scalable-8-players",
      "playerCount": 8,
      "revision": 1
    },
    "title": "The Barber of Blackwater Row",
    "atmosphere": "victorian",
    "setting": "Blackwater Row, a riverside town of workshops, narrow lanes and gaslit streets in the late nineteenth century.",
    "intro": "Evening settles over Blackwater Row. Three neighbors help the town investigator compare the supplied accounts: Xander Hale, the woodworker; Marla Quinn, the baker's assistant; and Jasper Crowe, the tavern musician. The host reads every recorded witness account before the players respond. Other named people remain in the evidence even when they are not playable. Discuss only the chapter just heard; nobody invents a history, witnesses a new discovery or improvises a private part.",
    "hiddenThread": "Receipt 47 recurs in every victim's disturbed records and finally names the Mayor's old imprisonment order against Benjamin Barker.",
    "coverageRepeatNote": "The trio covers all six directed pairs in the first two rounds. Later repeats add released evidence or explicitly correct an unsupported earlier inference. Each supplemental reader targets every other selected character before repeating, never in consecutive rounds. Separate singleton readings preserve the master loop and evidence timing.",
    "specialMechanics": [
      "Receipt 47 ledger: each murder surfaces another record indexed under receipt 47 (delivery log, tavern scrap, student-record index, night-route page). Compare them across rounds; the Mayor's signed order in Round 7 finally connects the series to the old case."
    ],
    "victim": {
      "name": "Elias Brim",
      "description": "The town baker, known for dependable bread deliveries and careful records."
    },
    "rounds": [
      {
        "title": "Round 1 - The Baker's Murder",
        "narration": "At dawn, delivery porter Finn Moss finds Elias Brim behind his bakery with his throat slashed. The investigator reports one clean, precise cut; the death happened off-screen. Elias supplied nearly every doorstep and recorded deliveries and closing chores in separate books. Finn calls night watchwoman Nell Reed before anyone enters the yard. She records a chain of flour prints from the back door to the wet cobbles. Each right print has a crescent-shaped gap at the heel; the cobbles preserve nothing beyond it. A page is torn from an older delivery log. Its surviving edge carries the date and part of receipt 47, but not a customer name or the purpose of the entry. The closing-duty sheet is intact and is kept for later comparison. These are the findings at this scene, not an identification of the killer. The investigator has collected four separate accounts about the neighbors.  Hear all four before discussing which details establish access and which merely raise suspicion.\n\nThe investigator reads the supporting witness accounts before calling on the selected readers:\n\nWitness background for Marla Quinn: Nell Reed saw Marla Quinn leave the bakery back door at nine, carrying her red-handled scrubbing brush. Nell recognized the brass buckle and crescent-shaped repair in the right heel of her work boots because cobbler Della March had shown her that repair at collection yesterday. Flour was packed into the repaired heel. The shape resembles the yard prints recorded this morning. This ties the boots to bakery work and the doorway, but does not date when each print was made. The closing-duty sheet has not yet been checked against the sighting.\n\nWitness background for Jasper Crowe: Finn Moss saw Jasper Crowe waiting behind the bakery at half past nine, with a blue-strapped instrument case propped against the wall. Finn recognized the musician from the tavern and the case from carrying it after last week's performance. A pale streak ran across its lower corner where it touched a flour sack outside the door. Finn heard him ask Elias for a promised parcel, but did not see a parcel handed over or hear what it contained. Finn left for the delivery cart; he did not witness the death or the musician's departure.\n\nWitness background for Lydia Vance: Della March saw Lydia Vance arguing with Elias at the bakery front counter that morning. She recognized the teacher from collecting her granddaughter from school and saw the same green lesson folder under her arm. Della heard the teacher ask why a bread bill included a household's personal history. Elias folded a paper and refused to answer. The teacher left a chalky thumb mark on the counter when she leaned forward. Della identifies the person and the topic, but heard no threat and never saw the contents of the folded paper.\n\nWitness background for Xander Hale: Della March delivered a wooden chair to Xander Hale's workshop last week and saw Elias at the open door. She recognized both men from their regular work at her market stall. Elias refused to enter and said, \"I will not bring that old receipt here again.\" The woodworker stopped sanding, gripped the chair rail and asked which book Elias meant. Della saw fresh amber shellac on his apron beside the repair cloth, but no weapon. She can identify the reaction and the receipt dispute; she cannot identify the old transaction or turn that reaction into proof of murder.\n\nThe host reads the original neighbors' recorded responses:\nXander Hale's recorded response: \"I heard Nell saw Marla Quinn leave the bakery's back door at nine with her red-handled brush. Her repaired, flour-packed heel resembles those prints. I still need their timing checked.\"\nMarla Quinn's recorded response: \"I heard Finn saw Jasper Crowe behind the bakery at nine-thirty with his blue-strapped case. A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave.\"\nJasper Crowe's recorded response: \"I heard Della saw Lydia Vance argue with Elias that morning, her green lesson folder tucked under her arm. A bread bill held family history. I wonder why he folded that paper.\"\nLydia Vance's recorded response: \"I heard Della saw Elias refuse to enter Xander Hale's workshop over an old receipt. He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon.\"\n\nThe supplied witness accounts support these comparisons:\nNell Reed recorded flour prints with a crescent gap in the right heel.\nDella March recognized the repaired boot from its collection yesterday.\nFinn Moss found Elias and called Nell before anyone entered the yard.\nAda Bell has not supplied a tavern account at this stage.\nOwen Bell has not supplied a classroom account at this stage.\nEdith Shaw has not supplied an office account at this stage.\nTown Investigator reported one precise cut at the bakery.\nDella recognized Lydia through collecting Della's Granddaughter from school.",
        "publicText": "Elias Brim: throat slashed with one precise cut. Finn Moss found the body; Nell Reed recorded flour prints with a crescent gap in the right heel. An old delivery-log page is torn; only receipt 47 survives at its edge. The closing-duty sheet is intact.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "At dawn, delivery porter Finn Moss finds Elias Brim behind his bakery with his throat slashed.",
          "The investigator reports one clean, precise cut; the death happened off-screen.",
          "Elias supplied nearly every doorstep and recorded deliveries and closing chores in separate books."
        ],
        "readingGroups": [
          [
            "xander",
            "marla",
            "jasper"
          ],
          [
            "lydia"
          ],
          [
            "nell"
          ],
          [
            "della"
          ],
          [
            "finn"
          ],
          [
            "ada"
          ]
        ],
        "chain": [
          "xander",
          "marla",
          "jasper",
          "lydia",
          "nell",
          "della",
          "finn",
          "ada"
        ],
        "coverageRepeat": false
      },
      {
        "title": "Round 2 - The Barkeep's Murder",
        "narration": "The next morning, cleaner Ada Bell finds Ronan Pike slumped over his tavern counter with his throat slashed. The investigator records the same precise cut as at the bakery. Ronan kept accounts of debts and stayed late for private appointments. Ada does not touch the mug beside him; Nell Reed records that it has been wiped and has no usable fingerprints. A thin amber smear remains beneath its handle. No owner has been established for the mug or the smear. Beneath Ronan's account book lies a scrap bearing receipt 47 and four lines of dates. No names or explanation survive on the scrap. The matching number links two sets of records, but does not identify their subject. Ronan's service tally and appointment book are preserved separately so that the last drink served will not be confused with the last visitor admitted. Four witness accounts are ready.  Listen for who saw an object, how they identified its owner and whether their timing actually reaches the death.\n\nThe investigator reads the supporting witness accounts before calling on the selected readers:\n\nWitness background for Jasper Crowe: Ada Bell saw Jasper Crowe put his instrument case on Ronan's counter at ten and leave after the last public drink was served. She recognized the case by its repaired blue strap, which she had sewn herself. He uses amber rosin on his bow; Ada collected a flake from the spot where the case rested. Its color resembles the smear beneath the wiped mug, but color alone cannot establish that they are the same material. Ronan locked the public door afterward; Ada did not watch the side entrance or the later appointments.\n\nWitness background for Lydia Vance: Ada Bell heard Lydia Vance tell Ronan at eight, \"Those are dangerous notes; people did not give you permission to record their families.\" Ada recognized the green lesson folder under the teacher's arm from her school-cleaning rounds. The teacher tapped Ronan's account book, leaving a white powder trace on its dark cover. Ada collected it as a possible chalk transfer, not a laboratory identification. The warning concerns records, but Ada saw no page removed. The teacher walked out through the public door; Ada could not observe who returned later.\n\nWitness background for Xander Hale: Ronan's repair invoice records Xander Hale replacing the tavern shelf last week. Ada Bell identified him from the signed invoice and saw him open a leather tool sleeve stamped with the same workshop address. Inside were sharpening stones Ronan called \"too fine for woodworking\": one was much narrower and smoother than the broad stone used on the shelf chisel. Ada saw him wipe the sleeve with an amber shellac-stained cloth from his repair kit. That establishes ownership of the stones and a second possible source of amber residue; it does not prove who handled the wiped mug on the night of the murder.\n\nWitness background for Marla Quinn: Della March heard Marla Quinn dispute an unpaid flour bill with Ronan outside the tavern at seven. She recognized the baker's assistant by the stamped delivery basket she was carrying. Ronan held a bill with a torn lower corner; the assistant produced a coin receipt, but Della was too far away to compare its amount. She saw the assistant leave with the basket toward the bakery. The argument supplies a specific grievance and an observed departure, not proof of payment or a witnessed return to the counter where Ronan died.\n\nThe host reads the original neighbors' recorded responses:\nXander Hale's recorded response: \"I heard Ada saw Jasper Crowe's blue-strapped case on Ronan's counter at ten. His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors.\"\nMarla Quinn's recorded response: \"I heard Ada heard Lydia Vance warn Ronan about recording families at eight. She touched his book, leaving possible chalk. I can't prove a removed page or a later return.\"\nJasper Crowe's recorded response: \"I read Xander Hale's shelf invoice; Ada saw fine sharpening stones in his address-stamped sleeve. His repair cloth held amber shellac. I see another possible smear source, not proof he touched that mug.\"\nLydia Vance's recorded response: \"I heard Della heard Marla Quinn dispute Ronan's flour bill at seven. She showed a receipt and left toward the bakery. I can't confirm payment or a later return.\"\n\nThe supplied witness accounts support these comparisons:\nNell Reed recorded a wiped mug without usable fingerprints.\nDella March heard Marla dispute the flour bill and leave toward the bakery.\nFinn Moss did not witness the bakery death or the musician leaving.\nAda Bell found Ronan and left the mug untouched.\nOwen Bell has not supplied a classroom account at this stage.\nEdith Shaw has not supplied an office account at this stage.\nTown Investigator reported the same precise cut at the tavern.\nDella's school collection of Della's Granddaughter explains her recognition of Lydia.",
        "publicText": "Ronan Pike: throat slashed with the same precise cut. Ada Bell found him. A wiped mug has no usable fingerprints and an unidentified amber smear beneath its handle. A dated scrap bears receipt 47 but no names. Service and appointment records are preserved.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "The next morning, cleaner Ada Bell finds Ronan Pike slumped over his tavern counter with his throat slashed.",
          "The investigator records the same precise cut as at the bakery.",
          "Ronan kept accounts of debts and stayed late for private appointments."
        ],
        "readingGroups": [
          [
            "xander",
            "jasper",
            "marla"
          ],
          [
            "lydia"
          ],
          [
            "nell"
          ],
          [
            "della"
          ],
          [
            "finn"
          ],
          [
            "ada"
          ]
        ],
        "chain": [
          "xander",
          "jasper",
          "marla",
          "lydia",
          "nell",
          "della",
          "finn",
          "ada"
        ],
        "coverageRepeat": false
      },
      {
        "title": "Round 3 - The Schoolteacher's Murder",
        "narration": "Before sunrise, caretaker Owen Bell finds senior teacher Harper Wren in her classroom with her throat slashed, the same precise cut again. Harper taught most of the town's children and kept family records as carefully as lesson plans. Owen locks the room and fetches Nell Reed. She records a broad chalk smear across the desk and a narrow drag line through it, running from the student-record book toward its open drawer. A page is missing from that book. Its remaining index cites receipt 47; a margin note says, \"Copy kept with the original order.\" Neither the order's owner nor its location is recorded here. Owen also hands over the fundraiser attendance sheet and Harper's lesson diary, both intact. Three disturbed records now share a number. That is a link worth following, not yet an explanation.  Compare observed visits with the traces on the desk, and keep the identity of any missing document separate from guesses about it.\n\nThe investigator reads the supporting witness accounts before calling on the selected readers:\n\nWitness background for Lydia Vance: Owen Bell saw Lydia Vance enter Harper's classroom at six carrying her green lesson folder. He recognized her name written inside its cover when she left it beside the register. A broad chalk mark on the folder's edge matches the height of the smeared desk; Owen had watched her lean it there while discussing pupil privacy. Her warning was, \"A family record should not become a weapon.\" This explains regular access and a possible source of chalk transfer, but Owen left at seven and cannot account for the classroom overnight.\n\nWitness background for Xander Hale: Owen Bell recalls Harper pointing out Xander Hale's narrow whetstone while the woodworker repaired her drawer rail last Tuesday. Owen saw the stone in a leather sleeve stamped with the workshop's address; he checked that address on the repair invoice. Harper said he \"used to work with blades in another trade\" but did not name it. Owen also saw fresh blue chalk on the woodworker's cuff after measuring the rail with Harper's chalk line. That gives an ordinary source for the cuff mark, not an explanation of the missing page or the earlier blade skills.\n\nWitness background for Marla Quinn: Owen Bell signed for Marla Quinn's six-o'clock bread delivery to Harper on the morning before the death. He recognized the baker's stamped basket and the repaired brass-buckled boots described in Round 1. The delivery docket, signed by Harper, specifies the classroom door rather than the school kitchen. Owen saw the assistant wait while Harper opened the student-record drawer to find payment. This gives a witnessed reason for knowing Harper's schedule and seeing the drawer. Neither the flour on the boots nor that access proves a visit before sunrise on the fatal morning.\n\nWitness background for Jasper Crowe: Owen Bell checked Jasper Crowe's name on the fundraiser attendance sheet at nine the previous evening. He recognized the blue-strapped case and watched the musician leave it beside Harper's desk while stacking chairs. White chalk marked the case corner where it rubbed the desktop, covering part of the pale bakery streak described in Round 1. Owen identifies a source for the transfer and a reason for being in the room. He locked the public school door after the event, but did not remain to watch the classroom's separate yard entrance overnight.\n\nThe host reads the original neighbors' recorded responses:\nXander Hale's recorded response: \"I heard Owen saw Lydia Vance's green folder in Harper's classroom at six, discussing pupil privacy. Its chalk matches the desk height. I worry about access, but Owen left at seven.\"\nMarla Quinn's recorded response: \"I heard Harper said Xander Hale once worked with blades; Owen saw his narrow whetstone during her drawer repair. Chalk explains his cuff mark to me, not missing pages or blade skills.\"\nJasper Crowe's recorded response: \"I read Marla Quinn's signed six-o'clock bread delivery to Harper's classroom door. Owen saw her wait by the open records drawer. I see access, but not a fatal-morning visit.\"\nLydia Vance's recorded response: \"I read Jasper Crowe's nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak. I see how marks transfer, but Owen didn't watch the yard entrance overnight.\"\n\nThe supplied witness accounts support these comparisons:\nNell Reed recorded a chalk smear and narrow drag line through it.\nDella March identified Lydia and the topic of the bakery argument.\nFinn Moss heard a promised parcel requested but saw no handover.\nAda Bell saw the fine stones in an address-stamped sleeve.\nOwen Bell found Harper, locked the classroom and fetched Nell.\nEdith Shaw has not supplied an office account at this stage.\nTown Investigator connected three disturbed records by receipt 47.\nDella's collection of Della's Granddaughter identifies a teacher, not a threat.",
        "publicText": "Harper Wren: throat slashed with the same precise cut. Owen Bell found her; Nell Reed recorded chalk and a drag line beside a disturbed student-record book. Its index cites receipt 47 and a copy kept with an unnamed original order. Attendance and lesson records are intact.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "Before sunrise, caretaker Owen Bell finds senior teacher Harper Wren in her classroom with her throat slashed, the same precise cut again.",
          "Harper taught most of the town's children and kept family records as carefully as lesson plans.",
          "Owen locks the room and fetches Nell Reed."
        ],
        "readingGroups": [
          [
            "xander",
            "marla",
            "jasper"
          ],
          [
            "lydia"
          ],
          [
            "nell"
          ],
          [
            "della"
          ],
          [
            "finn"
          ],
          [
            "ada"
          ]
        ],
        "chain": [
          "xander",
          "marla",
          "jasper",
          "lydia",
          "nell",
          "della",
          "finn",
          "ada"
        ],
        "coverageRepeat": true
      },
      {
        "title": "Round 4 - Visits and Transferred Marks",
        "narration": "Compare only the findings already read at the bakery, tavern and school. An evening delivery is not a fatal-morning visit; flour, rosin, shellac and chalk have witnessed work-related sources. Receipt 47 links disturbed records but does not yet identify their subject. Correct an accusation that mistakes a work trace or access for a witnessed killing. No new death, name, trade or weapon identification is introduced.",
        "publicText": "Correct earlier inferences using only already released evidence.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "Compare released work traces with the recorded visits.",
          "Correct unsupported accusations without a new discovery."
        ],
        "readingGroups": [
          [
            "xander",
            "jasper",
            "marla"
          ],
          [
            "lydia"
          ],
          [
            "nell"
          ],
          [
            "della"
          ],
          [
            "finn"
          ],
          [
            "ada"
          ]
        ],
        "chain": [
          "xander",
          "jasper",
          "marla",
          "lydia",
          "nell",
          "della",
          "finn",
          "ada"
        ],
        "coverageRepeat": true
      },
      {
        "title": "Round 5 - The Lamplighter's Murder",
        "narration": "Before the morning market opens, Nell Reed finds Tobias Wick beside an extinguished streetlamp with his throat slashed in the same precise manner. Tobias walked every lane at night and kept route notes about what he saw. Lamp oil has spilled in a perfect circle around the lamp base. Nell records its position before moving the fallen oil flask; the shape of the spill alone cannot identify who was there. A page is torn from Tobias's old route notebook. The surviving index bears receipt 47 and the instruction, \"Retain duplicate with original order.\" Nell gathers the bakery closing-duty sheet, Ronan's appointment book and Harper's lesson diary for comparison with the earlier witness accounts. Their entries can explain a visit or correct a timing assumption, but they are not blanket alibis. The subject of the old records is still missing.  Let each account introduce its own new finding. Then compare the four scenes and ask which traces are ordinary work and which remain unexplained.\n\nThe investigator reads the supporting witness accounts before calling on the selected readers:\n\nWitness background for Marla Quinn: Nell Reed compares Marla Quinn's flour-marked repaired boot from Round 1 with the bakery closing-duty sheet. Elias initialed her nine-o'clock task: scrub the rear threshold, then deliver the waste pail to the market. The entry explains why the crescent heel and flour appeared at the doorway; it is not evidence that the print was made during the killing. Market seller Della March also records that the assistant reported Tobias arguing with an unidentified figure beside the oil stall last night. Della heard the report, not the argument, so she cannot identify that figure.\n\nWitness background for Jasper Crowe: Della March saw Jasper Crowe follow Tobias from the tavern to the market lamp at ten last night. She identified the musician by his blue-strapped case and by the tune he had just played at her stall. Tobias asked him to hold the oil flask while adjusting the wick; Della saw a drop spill onto his right sleeve. The stain therefore has an observed source, not merely an assumed link to lamplighting. Della closed her shutter before Tobias resumed his route. The musician's presence and oil stain establish contact, but not where either man went afterward.\n\nWitness background for Lydia Vance: Nell Reed finds Lydia Vance's warning to Tobias entered in his intact route book: \"Children's family affairs do not belong in street notes.\" The entry describes her green folder and the school gate, where Owen Bell confirms he saw them speak. Nell compares it with Harper's lesson diary, which schedules their weekly meetings to prepare lessons and handle family requests. These sources explain the teacher's meetings and concern about records without supplying an overnight alibi. They do not explain why the older page indexed under receipt 47 was torn out.\n\nWitness background for Xander Hale: Nell Reed saw Xander Hale beneath the workshop lamp yesterday evening, holding a straight razor rather than a woodworking chisel. She recognized him from the shelf-repair invoice she had collected at the tavern and spoke to him face to face. The open blade reflected the lamp; the ivory handle had a triangular chip beside its hinge. He closed it and put it into the address-stamped leather sleeve whose fine stones Ada Bell described in Round 2. Nell can identify the owner, object and distinctive damage, but she did not see an attack. The blade should be compared with the repeated precise cuts, not treated as a confession.\n\nThe host reads the original neighbors' recorded responses:\nXander Hale's recorded response: \"I read Marla Quinn's nine-o'clock closing duty: scrub the rear threshold, then take waste to market. I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone.\"\nMarla Quinn's recorded response: \"I heard Della saw Jasper Crowe follow Tobias to the market lamp at ten. He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward.\"\nJasper Crowe's recorded response: \"I read Lydia Vance's warning to Tobias: children's family affairs don't belong in street notes. Her weekly lesson meetings explain contact to me, not an overnight alibi or receipt 47's torn page.\"\nLydia Vance's recorded response: \"I heard Nell saw Xander Hale's straight razor: ivory handle, triangular chip beside its hinge. It went into his stamped sleeve. I worry about those precise cuts, not a confession.\"\n\nThe supplied witness accounts support these comparisons:\nNell Reed saw the chipped ivory razor enter the stamped sleeve.\nDella March saw Jasper holding the flask before oil spilled on his sleeve.\nFinn Moss left for the delivery cart without witnessing the bakery death.\nAda Bell saw the blue-strapped case on Ronan's counter at ten.\nOwen Bell left at seven without watching the separate yard entrance overnight.\nEdith Shaw has not supplied an office account at this stage.\nTown Investigator preserved the earlier work records for timing comparisons.\nDella's school collection of Della's Granddaughter does not identify a murderer.",
        "publicText": "Tobias Wick: throat slashed with the same precise cut. Nell Reed found him beside an extinguished lamp and a circle of spilled oil. A torn night-route page is indexed under receipt 47. Earlier work and appointment records are ready for comparison, not complete alibis.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "Before the morning market opens, Nell Reed finds Tobias Wick beside an extinguished streetlamp with his throat slashed in the same precise manner.",
          "Tobias walked every lane at night and kept route notes about what he saw.",
          "Lamp oil has spilled in a perfect circle around the lamp base."
        ],
        "readingGroups": [
          [
            "xander",
            "marla",
            "jasper"
          ],
          [
            "lydia"
          ],
          [
            "nell"
          ],
          [
            "della"
          ],
          [
            "finn"
          ],
          [
            "ada"
          ]
        ],
        "chain": [
          "xander",
          "marla",
          "jasper",
          "lydia",
          "nell",
          "della",
          "finn",
          "ada"
        ],
        "coverageRepeat": true
      },
      {
        "title": "Round 6 - Work Traces and the Identified Tool",
        "narration": "Compare the already released closing-duty sheet, private-appointment records, school visits and Nell's chipped-razor sighting. A work record can explain a trace without supplying an overnight alibi. The identified razor is more specific than an unexplained color or stain, but its sighting is not a confession. Correct earlier accusations based only on flour, chalk or spilled oil. No new death or old identity is introduced.",
        "publicText": "Correct earlier inferences using only already released evidence.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "Compare released work traces with the recorded visits.",
          "Correct unsupported accusations without a new discovery."
        ],
        "readingGroups": [
          [
            "xander",
            "jasper",
            "marla"
          ],
          [
            "lydia"
          ],
          [
            "nell"
          ],
          [
            "della"
          ],
          [
            "finn"
          ],
          [
            "ada"
          ]
        ],
        "chain": [
          "xander",
          "jasper",
          "marla",
          "lydia",
          "nell",
          "della",
          "finn",
          "ada"
        ],
        "coverageRepeat": true
      },
      {
        "title": "Round 7 - The Mayor's Murder",
        "narration": "Office clerk Edith Shaw finds Mayor Aldric Thorne in his office chair with his throat slashed, the same precise cut. A polished straight razor lies on the desk, its ivory handle chipped beside the hinge. Edith calls Nell Reed and identifies the locked cabinet from which the papers on the desk came; its numbered index and broken wax seal allow the investigator to trace their source. A single old court document, signed by Thorne, orders the imprisonment of BENJAMIN BARKER and bears receipt 47. This is the first time that name enters the investigation. With it are the duplicate records referred to in Harper's index and Tobias's notebook. The investigator reads them aloud: Elias signed a false delivery entry placing Barker at a theft; Ronan signed a fabricated account of a confession; Harper altered a household record to support the charge; Tobias supplied a false night-route sighting. A retained letter from Thorne orders the changes, admits that he wanted Barker's wife and describes using imprisonment to separate them. The household record states that she was taken into Thorne's household under coercion, not by free choice. Barker's licensed occupation is barber. A likeness, address and tool inventory are attached, but the investigator leaves their identification to the witnesses whose accounts you are about to hear. These documents establish the original injustice and the four victims' roles. They do not announce which current neighbor committed the murders.  Hear every account before the final vote.\n\nThe investigator reads the supporting witness accounts before calling on the selected readers:\n\nWitness background for Jasper Crowe: Edith Shaw asks Jasper Crowe to explain a rumor he heard at the tavern about the woodworker once using a different name. He identifies its source as Ronan's remark about an old license, not personal knowledge of the imprisonment. Edith compares the signature on his ten-o'clock drink receipt with the appointment book preserved in Round 2; it confirms his earlier visit, while a separate eleven-o'clock entry admits a private visitor. His rosin flake explains a substance on the counter, but neither the rumor nor the flake identifies that later visitor or makes him a signer of the false statements in the court file.\n\nWitness background for Lydia Vance: Edith Shaw compares Lydia Vance's account of seeing the Mayor hide an old paper with the cabinet index recovered today. The teacher dates the sighting to a school-funding appointment entered in Edith's diary; Edith confirms she admitted her for that appointment and saw Thorne close the folder. The teacher could read receipt 47, but not the name hidden beneath his hand. This explains why the teacher questioned intrusive family records. Her chalk-marked folder and weekly lesson meetings establish access to school papers, not a signature on the falsified statements read from the court file.\n\nWitness background for Xander Hale: Edith Shaw identifies the court file's licensed likeness as Xander Hale; she compares the workshop address printed beside it with the signed shelf-repair invoice preserved in Round 2. The licensed name is Benjamin Barker. The barber's tool inventory describes an ivory razor with a chip beside the hinge, matching the blade Nell Reed saw in his hand in Round 4 and the one now on Thorne's desk. The fine stones and Harper's earlier-trade remark fit the documented occupation. The duplicate records identify the four people who helped Thorne destroy his former life. This joins identity, blade ownership and motive; the room must still decide its final accusation.\n\nWitness background for Marla Quinn: Edith Shaw checks Marla Quinn's account of an old visit by Thorne to the workshop home. The assistant remembers delivering a baker's basket there as a child; the retained delivery copy records the date and the house number. Edith compares those details with Thorne's appointment diary and confirms the visit. The account links a remembered visit to a documented place, but the assistant did not hear the conversation. Her repaired flour-marked boot still fits the closing chore established in Round 4, not a proven killing. Neither her childhood observation nor her recent bread delivery makes her one of the signers identified in the old file.\n\nThe host reads the original neighbors' recorded responses:\nXander Hale's recorded response: \"I heard Jasper Crowe's different-name rumor came from Ronan's old-license remark. His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin.\"\nMarla Quinn's recorded response: \"I learned Lydia Vance saw Thorne hide receipt 47 during her confirmed school-funding appointment. She couldn't read the name. I see why she questioned family records, not proof she falsified them.\"\nJasper Crowe's recorded response: \"I heard Edith match Xander Hale's licensed likeness and workshop address: Benjamin Barker, barber. His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse.\"\nLydia Vance's recorded response: \"I heard Edith confirm Marla Quinn's childhood delivery during Thorne's old workshop-home visit. She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot.\"\n\nThe supplied witness accounts support these comparisons:\nNell Reed identified the damaged razor in the earlier sighting.\nDella March's boot identification established work access, not print timing.\nFinn Moss's case account established an evening visit, not a witnessed murder.\nAda Bell's account left later private visitors possible.\nOwen Bell's accounts did not establish an overnight alibi.\nEdith Shaw matched the licensed likeness and address to Xander.\nTown Investigator read the retained duplicate records and Thorne's letter.\nDella's identification through Della's Granddaughter does not implicate Lydia in the old falsification.",
        "publicText": "Mayor Aldric Thorne: throat slashed; a polished razor with a chipped ivory handle on his desk. Edith Shaw identifies the cabinet and record index. Thorne's signed imprisonment order names Benjamin Barker under receipt 47. Duplicate records and his letter expose the four victims' false statements and his coercion. Witness identification follows in the player readings.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "Office clerk Edith Shaw finds Mayor Aldric Thorne in his office chair with his throat slashed, the same precise cut.",
          "A polished straight razor lies on the desk, its ivory handle chipped beside the hinge.",
          "Edith calls Nell Reed and identifies the locked cabinet from which the papers on the desk came; its numbered index and broken wax seal allow the investigator to trace their source."
        ],
        "readingGroups": [
          [
            "xander",
            "marla",
            "jasper"
          ],
          [
            "lydia"
          ],
          [
            "nell"
          ],
          [
            "della"
          ],
          [
            "finn"
          ],
          [
            "ada"
          ]
        ],
        "chain": [
          "xander",
          "marla",
          "jasper",
          "lydia",
          "nell",
          "della",
          "finn",
          "ada"
        ],
        "coverageRepeat": true
      }
    ],
    "characters": [
      {
        "id": "xander",
        "name": "Xander Hale",
        "role": "Woodworker",
        "relationship": "A neighbor asked by the town investigator to help compare witness accounts of the Blackwater Row murders.",
        "tieIn": "A quiet craftsperson who repairs furniture and makes wooden fittings in a workshop off the market lane.",
        "optional": false,
        "ghost": null,
        "guest": "",
        "guestNote": "",
        "publicBlurb": "A quiet craftsperson who repairs furniture and makes wooden fittings in a workshop off the market lane.",
        "rounds": [
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I heard Nell saw {marla} leave the bakery's back door at nine with her red-handled brush. Her repaired, flour-packed heel resembles those prints. I still need their timing checked.",
              "observation": "I heard Nell saw {marla} leave the bakery's back door at nine with her red-handled brush.",
              "contradictingDetail": "Her repaired, flour-packed heel resembles those prints. I still need their timing checked."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I heard Ada saw {jasper}'s blue-strapped case on Ronan's counter at ten. His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors.",
              "observation": "I heard Ada saw {jasper}'s blue-strapped case on Ronan's counter at ten.",
              "contradictingDetail": "His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I read {marla}'s signed six-o'clock bread delivery to Harper's classroom door. Owen saw her wait by the open records drawer. I see access, but not a fatal-morning visit.",
              "observation": "I read {marla}'s signed six-o'clock bread delivery to Harper's classroom door.",
              "contradictingDetail": "Owen saw her wait by the open records drawer. I see access, but not a fatal-morning visit."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I heard {jasper}'s case rubbed the chalky desk over its flour streak. I must distinguish transferred work marks from evidence that he removed the student-record page.",
              "observation": "I heard {jasper}'s case rubbed the chalky desk over its flour streak.",
              "contradictingDetail": "I must distinguish transferred work marks from evidence that he removed the student-record page."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I read {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market. I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone.",
              "observation": "I read {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market.",
              "contradictingDetail": "I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I read {jasper}'s visit to the lamp in Della's account. I must not treat spilled oil on his sleeve as proof of a precise cut or an account of his later movements.",
              "observation": "I read {jasper}'s visit to the lamp in Della's account.",
              "contradictingDetail": "I must not treat spilled oil on his sleeve as proof of a precise cut or an account of his later movements."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I heard Edith confirm {marla}'s childhood delivery during Thorne's old workshop-home visit. She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot.",
              "observation": "I heard Edith confirm {marla}'s childhood delivery during Thorne's old workshop-home visit.",
              "contradictingDetail": "She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot."
            }
          }
        ]
      },
      {
        "id": "marla",
        "name": "Marla Quinn",
        "role": "Baker's assistant",
        "relationship": "Assistant to the first victim, the baker Elias Brim; asked to help compare witness accounts.",
        "tieIn": "Elias Brim's assistant, responsible for bread deliveries and the evening cleanup. A familiar face at doorsteps across town.",
        "optional": false,
        "ghost": null,
        "guest": "",
        "guestNote": "",
        "publicBlurb": "Elias Brim's assistant, responsible for bread deliveries and the evening cleanup. A familiar face at doorsteps across town.",
        "rounds": [
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I heard Finn saw {jasper} behind the bakery at nine-thirty with his blue-strapped case. A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave.",
              "observation": "I heard Finn saw {jasper} behind the bakery at nine-thirty with his blue-strapped case.",
              "contradictingDetail": "A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I read {xander}'s shelf invoice; Ada saw fine sharpening stones in his address-stamped sleeve. His repair cloth held amber shellac. I see another possible smear source, not proof he touched that mug.",
              "observation": "I read {xander}'s shelf invoice; Ada saw fine sharpening stones in his address-stamped sleeve.",
              "contradictingDetail": "His repair cloth held amber shellac. I see another possible smear source, not proof he touched that mug."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I read {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak. I see how marks transfer, but Owen didn't watch the yard entrance overnight.",
              "observation": "I read {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak.",
              "contradictingDetail": "I see how marks transfer, but Owen didn't watch the yard entrance overnight."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard {xander}'s drawer repair explained chalk on his cuff. I must not mistake a work mark for an explanation of the missing pages or his earlier blade skills.",
              "observation": "I heard {xander}'s drawer repair explained chalk on his cuff.",
              "contradictingDetail": "I must not mistake a work mark for an explanation of the missing pages or his earlier blade skills."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I heard Della saw {jasper} follow Tobias to the market lamp at ten. He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward.",
              "observation": "I heard Della saw {jasper} follow Tobias to the market lamp at ten.",
              "contradictingDetail": "He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard Nell identify {xander}'s chipped ivory razor. I must compare that identifiable tool with the repeated cuts, not call the sighting a confession.",
              "observation": "I heard Nell identify {xander}'s chipped ivory razor.",
              "contradictingDetail": "I must compare that identifiable tool with the repeated cuts, not call the sighting a confession."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I heard {jasper}'s different-name rumor came from Ronan's old-license remark. His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin.",
              "observation": "I heard {jasper}'s different-name rumor came from Ronan's old-license remark.",
              "contradictingDetail": "His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin."
            }
          }
        ]
      },
      {
        "id": "jasper",
        "name": "Jasper Crowe",
        "role": "Tavern musician",
        "relationship": "Musician at the tavern of the second victim, Ronan Pike; asked to help compare witness accounts.",
        "tieIn": "A musician at Ronan Pike's tavern who also plays for town events. Often out late carrying his instrument between jobs.",
        "optional": false,
        "ghost": null,
        "guest": "",
        "guestNote": "",
        "publicBlurb": "A musician at Ronan Pike's tavern who also plays for town events. Often out late carrying his instrument between jobs.",
        "rounds": [
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard Della saw Elias refuse to enter {xander}'s workshop over an old receipt. He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon.",
              "observation": "I heard Della saw Elias refuse to enter {xander}'s workshop over an old receipt.",
              "contradictingDetail": "He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I heard Della heard {marla} dispute Ronan's flour bill at seven. She showed a receipt and left toward the bakery. I can't confirm payment or a later return.",
              "observation": "I heard Della heard {marla} dispute Ronan's flour bill at seven.",
              "contradictingDetail": "She showed a receipt and left toward the bakery. I can't confirm payment or a later return."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair. Chalk explains his cuff mark to me, not missing pages or blade skills.",
              "observation": "I heard Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair.",
              "contradictingDetail": "Chalk explains his cuff mark to me, not missing pages or blade skills."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I read {marla}'s signed bread delivery at six. I must distinguish an evening delivery from a fatal-morning visit; access alone does not explain the missing page.",
              "observation": "I read {marla}'s signed bread delivery at six.",
              "contradictingDetail": "I must distinguish an evening delivery from a fatal-morning visit; access alone does not explain the missing page."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge. It went into his stamped sleeve. I worry about those precise cuts, not a confession.",
              "observation": "I heard Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge.",
              "contradictingDetail": "It went into his stamped sleeve. I worry about those precise cuts, not a confession."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I read {marla}'s closing duty to scrub the rear threshold. I must correct my earlier suspicion: flour in her repaired heel can come from work, not a witnessed killing.",
              "observation": "I read {marla}'s closing duty to scrub the rear threshold.",
              "contradictingDetail": "I must correct my earlier suspicion: flour in her repaired heel can come from work, not a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard Edith match {xander}'s licensed likeness and workshop address: Benjamin Barker, barber. His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse.",
              "observation": "I heard Edith match {xander}'s licensed likeness and workshop address: Benjamin Barker, barber.",
              "contradictingDetail": "His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse."
            }
          }
        ]
      },
      {
        "id": "lydia",
        "name": "Lydia Vance",
        "role": "Schoolteacher",
        "relationship": "Teacher working alongside the third victim, senior teacher Harper Wren; asked to help compare witness accounts.",
        "tieIn": "A teacher working alongside senior teacher Harper Wren. Attentive to local families and protective of their privacy.",
        "publicBlurb": "A teacher working alongside senior teacher Harper Wren. Attentive to local families and protective of their privacy.",
        "optional": false,
        "guest": "",
        "guestNote": "",
        "ghost": null,
        "rounds": [
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I learned Della saw Elias refuse to enter {xander}'s workshop over an old receipt. He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon.",
              "observation": "I learned Della saw Elias refuse to enter {xander}'s workshop over an old receipt.",
              "contradictingDetail": "He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I learned Della heard {marla} dispute Ronan's flour bill at seven. She showed a receipt and left toward the bakery. I can't confirm payment or a later return.",
              "observation": "I learned Della heard {marla} dispute Ronan's flour bill at seven.",
              "contradictingDetail": "She showed a receipt and left toward the bakery. I can't confirm payment or a later return."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I checked {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak. I see how marks transfer, but Owen didn't watch the yard entrance overnight.",
              "observation": "I checked {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak.",
              "contradictingDetail": "I see how marks transfer, but Owen didn't watch the yard entrance overnight."
            }
          },
          {
            "readAloud": {
              "accuses": "nell",
              "text": "I heard the account: {nell} recorded a chalk smear and narrow drag line through it. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: {nell} recorded a chalk smear and narrow drag line through it.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "della",
              "text": "I heard the account: {della} saw Jasper holding the flask before oil spilled on his sleeve. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {della} saw Jasper holding the flask before oil spilled on his sleeve.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "finn",
              "text": "I heard the account: {finn} left for the delivery cart without witnessing the bakery death. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: {finn} left for the delivery cart without witnessing the bakery death.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "ada",
              "text": "I heard the account: {ada}'s account left later private visitors possible. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {ada}'s account left later private visitors possible.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          }
        ]
      },
      {
        "id": "nell",
        "name": "Nell Reed",
        "role": "Night watchwoman",
        "relationship": "An existing person in the supplied Blackwater Row accounts.",
        "tieIn": "Records the scene findings and supplies the razor sighting.",
        "publicBlurb": "Records the scene findings and supplies the razor sighting.",
        "optional": false,
        "guest": "",
        "guestNote": "",
        "ghost": null,
        "rounds": [
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I learned Nell saw {marla} leave the bakery's back door at nine with her red-handled brush. Her repaired, flour-packed heel resembles those prints. I still need their timing checked.",
              "observation": "I learned Nell saw {marla} leave the bakery's back door at nine with her red-handled brush.",
              "contradictingDetail": "Her repaired, flour-packed heel resembles those prints. I still need their timing checked."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I learned Ada saw {jasper}'s blue-strapped case on Ronan's counter at ten. His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors.",
              "observation": "I learned Ada saw {jasper}'s blue-strapped case on Ronan's counter at ten.",
              "contradictingDetail": "His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors."
            }
          },
          {
            "readAloud": {
              "accuses": "lydia",
              "text": "I learned Owen saw {lydia}'s green folder in Harper's classroom at six, discussing pupil privacy. Its chalk matches the desk height. I worry about access, but Owen left at seven.",
              "observation": "I learned Owen saw {lydia}'s green folder in Harper's classroom at six, discussing pupil privacy.",
              "contradictingDetail": "Its chalk matches the desk height. I worry about access, but Owen left at seven."
            }
          },
          {
            "readAloud": {
              "accuses": "della",
              "text": "I heard the account: {della} identified Lydia and the topic of the bakery argument. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: {della} identified Lydia and the topic of the bakery argument.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "finn",
              "text": "I heard the account: {finn} left for the delivery cart without witnessing the bakery death. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {finn} left for the delivery cart without witnessing the bakery death.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "ada",
              "text": "I heard the account: {ada} saw the blue-strapped case on Ronan's counter at ten. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: {ada} saw the blue-strapped case on Ronan's counter at ten.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I learned Edith match {xander}'s licensed likeness and workshop address: Benjamin Barker, barber. His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse.",
              "observation": "I learned Edith match {xander}'s licensed likeness and workshop address: Benjamin Barker, barber.",
              "contradictingDetail": "His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse."
            }
          }
        ]
      },
      {
        "id": "della",
        "name": "Della March",
        "role": "Cobbler",
        "relationship": "An existing person in the supplied Blackwater Row accounts.",
        "tieIn": "Identifies the repaired boot and the neighbors in her recorded accounts.",
        "publicBlurb": "Identifies the repaired boot and the neighbors in her recorded accounts.",
        "optional": false,
        "guest": "",
        "guestNote": "",
        "ghost": null,
        "rounds": [
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I learned Finn saw {jasper} behind the bakery at nine-thirty with his blue-strapped case. A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave.",
              "observation": "I learned Finn saw {jasper} behind the bakery at nine-thirty with his blue-strapped case.",
              "contradictingDetail": "A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave."
            }
          },
          {
            "readAloud": {
              "accuses": "lydia",
              "text": "I learned Ada heard {lydia} warn Ronan about recording families at eight. She touched his book, leaving possible chalk. I can't prove a removed page or a later return.",
              "observation": "I learned Ada heard {lydia} warn Ronan about recording families at eight.",
              "contradictingDetail": "She touched his book, leaving possible chalk. I can't prove a removed page or a later return."
            }
          },
          {
            "readAloud": {
              "accuses": "nell",
              "text": "I heard the account: {nell} recorded a chalk smear and narrow drag line through it. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {nell} recorded a chalk smear and narrow drag line through it.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "finn",
              "text": "I heard the account: {finn} heard a promised parcel requested but saw no handover. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: {finn} heard a promised parcel requested but saw no handover.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "ada",
              "text": "I heard the account: {ada} saw the blue-strapped case on Ronan's counter at ten. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {ada} saw the blue-strapped case on Ronan's counter at ten.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I learned Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge. It went into his stamped sleeve. I worry about those precise cuts, not a confession.",
              "observation": "I learned Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge.",
              "contradictingDetail": "It went into his stamped sleeve. I worry about those precise cuts, not a confession."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I learned Edith confirm {marla}'s childhood delivery during Thorne's old workshop-home visit. She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot.",
              "observation": "I learned Edith confirm {marla}'s childhood delivery during Thorne's old workshop-home visit.",
              "contradictingDetail": "She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot."
            }
          }
        ]
      },
      {
        "id": "finn",
        "name": "Finn Moss",
        "role": "Delivery porter",
        "relationship": "An existing person in the supplied Blackwater Row accounts.",
        "tieIn": "Finds Elias and reports the musician waiting behind the bakery.",
        "publicBlurb": "Finds Elias and reports the musician waiting behind the bakery.",
        "optional": false,
        "guest": "",
        "guestNote": "",
        "ghost": null,
        "rounds": [
          {
            "readAloud": {
              "accuses": "lydia",
              "text": "I learned Della saw {lydia} argue with Elias that morning, her green lesson folder tucked under her arm. A bread bill held family history. I wonder why he folded that paper.",
              "observation": "I learned Della saw {lydia} argue with Elias that morning, her green lesson folder tucked under her arm.",
              "contradictingDetail": "A bread bill held family history. I wonder why he folded that paper."
            }
          },
          {
            "readAloud": {
              "accuses": "nell",
              "text": "I heard the account: {nell} recorded a wiped mug without usable fingerprints. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {nell} recorded a wiped mug without usable fingerprints.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "della",
              "text": "I heard the account: {della} identified Lydia and the topic of the bakery argument. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {della} identified Lydia and the topic of the bakery argument.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "ada",
              "text": "I heard the account: {ada} saw the fine stones in an address-stamped sleeve. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: {ada} saw the fine stones in an address-stamped sleeve.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I learned Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge. It went into his stamped sleeve. I worry about those precise cuts, not a confession.",
              "observation": "I learned Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge.",
              "contradictingDetail": "It went into his stamped sleeve. I worry about those precise cuts, not a confession."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I checked {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market. I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone.",
              "observation": "I checked {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market.",
              "contradictingDetail": "I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I learned {jasper}'s different-name rumor came from Ronan's old-license remark. His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin.",
              "observation": "I learned {jasper}'s different-name rumor came from Ronan's old-license remark.",
              "contradictingDetail": "His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin."
            }
          }
        ]
      },
      {
        "id": "ada",
        "name": "Ada Bell",
        "role": "Tavern cleaner",
        "relationship": "An existing person in the supplied Blackwater Row accounts.",
        "tieIn": "Finds Ronan and reports the tavern objects and appointments.",
        "publicBlurb": "Finds Ronan and reports the tavern objects and appointments.",
        "optional": false,
        "guest": "",
        "guestNote": "",
        "ghost": null,
        "rounds": [
          {
            "readAloud": {
              "accuses": "nell",
              "text": "I heard the account: {nell} recorded flour prints with a crescent gap in the right heel. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {nell} recorded flour prints with a crescent gap in the right heel.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "della",
              "text": "I heard the account: {della} heard Marla dispute the flour bill and leave toward the bakery. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {della} heard Marla dispute the flour bill and leave toward the bakery.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "finn",
              "text": "I heard the account: {finn} heard a promised parcel requested but saw no handover. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {finn} heard a promised parcel requested but saw no handover.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I learned Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair. Chalk explains his cuff mark to me, not missing pages or blade skills.",
              "observation": "I learned Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair.",
              "contradictingDetail": "Chalk explains his cuff mark to me, not missing pages or blade skills."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I checked {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market. I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone.",
              "observation": "I checked {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market.",
              "contradictingDetail": "I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I learned Della saw {jasper} follow Tobias to the market lamp at ten. He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward.",
              "observation": "I learned Della saw {jasper} follow Tobias to the market lamp at ten.",
              "contradictingDetail": "He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward."
            }
          },
          {
            "readAloud": {
              "accuses": "lydia",
              "text": "I heard {lydia} saw Thorne hide receipt 47 during her confirmed school-funding appointment. She couldn't read the name. I see why she questioned family records, not proof she falsified them.",
              "observation": "I heard {lydia} saw Thorne hide receipt 47 during her confirmed school-funding appointment.",
              "contradictingDetail": "She couldn't read the name. I see why she questioned family records, not proof she falsified them."
            }
          }
        ]
      }
    ],
    "finale": {
      "narration": "All seven chapters and the final witness accounts have now been read. Compare the identified blade, the licensed likeness and address, and the duplicate records with the earlier observations. Decide which neighbor accounts for the complete chain, not just one suspicious trace. A reason for revenge can explain a crime without excusing it. Make your final accusation before the investigator announces the solution.",
      "votePrompt": "Who do you accuse based on the evidence heard so far?"
    },
    "solution": {
      "killerId": "xander",
      "explanation": "Xander Hale is Benjamin Barker, formerly Blackwater Row's trusted barber, and he committed all five murders. Thorne's letter and court file, first read in Round 7, establish that the Mayor wanted Barker's wife, framed him, ordered his imprisonment and forced her into his household. Elias's false delivery entry, Ronan's invented confession, Harper's altered household record and Tobias's false night sighting helped destroy Barker's married life. After release, Barker returned as the woodworker Xander Hale. The fine stones in his address-stamped sleeve and Harper's earlier-trade remark established a blade skill without naming it. Nell's direct observation of the chipped ivory razor in Round 5 supplied identifiable ownership; Edith's Round 7 comparison joined that razor, the licensed likeness and the repair invoice to the old identity. Receipt 47 linked the disturbed records; retained duplicates explained the target selection. Marla's repaired flour-marked boot had a documented closing-chore source. Jasper's case and rosin and Lydia's folder and chalk had witnessed work-related sources; their movements raised questions but did not explain the complete identity, weapon and motive chain. No stain alone proved a killing. Barker killed the four accomplices before reaching his final target, the Mayor. This was deliberate revenge, not justice.",
      "revealNarration": "The investigator closes the court file. \"The killer is {xander}. His former name was Benjamin Barker, and his former trade was barber. Nell identified the damaged razor in his hand; Edith matched the license and address to his current work. The earlier victims supplied the false statements that destroyed his former life. Thorne was his final target.\"\n\nThe host may read Barker's final words: \"Once this town knew me as Benjamin Barker. I had a trade, a wife and a home. Thorne wanted what was not his, and four respectable voices made his lie sound like law. When I returned, I called myself Xander Hale and worked in wood. I thought a new name could bury the old one. Instead I carried it through every door. I chose revenge, and I killed them. It did not restore my wife's freedom or the years we lost. Nothing they did makes these murders right.\"\n\nBlackwater Row must now reckon with both the original injustice and the five deaths that followed."
    },
    "masterPreserving": true,
    "conversion": {
      "source": "Committed four-player Blackwater Row revision 3.",
      "changes": [
        {
          "original": "Five discovery chapters and four playable neighbors.",
          "replacement": "Five unchanged discovery sequences with two intervening comparison chapters and a three-player core.",
          "reason": "Seven-round requirement and smallest-edition master. Identity remains in the last discovery chapter; no murders or facts are added."
        },
        {
          "original": "Per-chapter four-player reader handoffs and twenty player responses.",
          "replacement": "Named recorded responses in shared narration and count-specific group order.",
          "reason": "Preserve every witness source and original response while selecting a three-player loop."
        },
        {
          "original": "Solution timing references to Round 4 and Round 5.",
          "replacement": "Corresponding seven-chapter references to Round 5 and Round 7.",
          "reason": "Inserted comparison rounds shift chapter numbers without advancing evidence."
        }
      ],
      "originalResponses": [
        {
          "id": "xander",
          "rounds": [
            {
              "readAloud": {
                "accuses": "marla",
                "text": "I heard Nell saw {marla} leave the bakery's back door at nine with her red-handled brush. Her repaired, flour-packed heel resembles those prints. I still need their timing checked.",
                "observation": "I heard Nell saw {marla} leave the bakery's back door at nine with her red-handled brush.",
                "contradictingDetail": "Her repaired, flour-packed heel resembles those prints. I still need their timing checked."
              }
            },
            {
              "readAloud": {
                "accuses": "jasper",
                "text": "I heard Ada saw {jasper}'s blue-strapped case on Ronan's counter at ten. His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors.",
                "observation": "I heard Ada saw {jasper}'s blue-strapped case on Ronan's counter at ten.",
                "contradictingDetail": "His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors."
              }
            },
            {
              "readAloud": {
                "accuses": "lydia",
                "text": "I heard Owen saw {lydia}'s green folder in Harper's classroom at six, discussing pupil privacy. Its chalk matches the desk height. I worry about access, but Owen left at seven.",
                "observation": "I heard Owen saw {lydia}'s green folder in Harper's classroom at six, discussing pupil privacy.",
                "contradictingDetail": "Its chalk matches the desk height. I worry about access, but Owen left at seven."
              }
            },
            {
              "readAloud": {
                "accuses": "marla",
                "text": "I read {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market. I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone.",
                "observation": "I read {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market.",
                "contradictingDetail": "I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone."
              }
            },
            {
              "readAloud": {
                "accuses": "jasper",
                "text": "I heard {jasper}'s different-name rumor came from Ronan's old-license remark. His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin.",
                "observation": "I heard {jasper}'s different-name rumor came from Ronan's old-license remark.",
                "contradictingDetail": "His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin."
              }
            }
          ]
        },
        {
          "id": "marla",
          "rounds": [
            {
              "readAloud": {
                "accuses": "jasper",
                "text": "I heard Finn saw {jasper} behind the bakery at nine-thirty with his blue-strapped case. A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave.",
                "observation": "I heard Finn saw {jasper} behind the bakery at nine-thirty with his blue-strapped case.",
                "contradictingDetail": "A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave."
              }
            },
            {
              "readAloud": {
                "accuses": "lydia",
                "text": "I heard Ada heard {lydia} warn Ronan about recording families at eight. She touched his book, leaving possible chalk. I can't prove a removed page or a later return.",
                "observation": "I heard Ada heard {lydia} warn Ronan about recording families at eight.",
                "contradictingDetail": "She touched his book, leaving possible chalk. I can't prove a removed page or a later return."
              }
            },
            {
              "readAloud": {
                "accuses": "xander",
                "text": "I heard Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair. Chalk explains his cuff mark to me, not missing pages or blade skills.",
                "observation": "I heard Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair.",
                "contradictingDetail": "Chalk explains his cuff mark to me, not missing pages or blade skills."
              }
            },
            {
              "readAloud": {
                "accuses": "jasper",
                "text": "I heard Della saw {jasper} follow Tobias to the market lamp at ten. He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward.",
                "observation": "I heard Della saw {jasper} follow Tobias to the market lamp at ten.",
                "contradictingDetail": "He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward."
              }
            },
            {
              "readAloud": {
                "accuses": "lydia",
                "text": "I learned {lydia} saw Thorne hide receipt 47 during her confirmed school-funding appointment. She couldn't read the name. I see why she questioned family records, not proof she falsified them.",
                "observation": "I learned {lydia} saw Thorne hide receipt 47 during her confirmed school-funding appointment.",
                "contradictingDetail": "She couldn't read the name. I see why she questioned family records, not proof she falsified them."
              }
            }
          ]
        },
        {
          "id": "jasper",
          "rounds": [
            {
              "readAloud": {
                "accuses": "lydia",
                "text": "I heard Della saw {lydia} argue with Elias that morning, her green lesson folder tucked under her arm. A bread bill held family history. I wonder why he folded that paper.",
                "observation": "I heard Della saw {lydia} argue with Elias that morning, her green lesson folder tucked under her arm.",
                "contradictingDetail": "A bread bill held family history. I wonder why he folded that paper."
              }
            },
            {
              "readAloud": {
                "accuses": "xander",
                "text": "I read {xander}'s shelf invoice; Ada saw fine sharpening stones in his address-stamped sleeve. His repair cloth held amber shellac. I see another possible smear source, not proof he touched that mug.",
                "observation": "I read {xander}'s shelf invoice; Ada saw fine sharpening stones in his address-stamped sleeve.",
                "contradictingDetail": "His repair cloth held amber shellac. I see another possible smear source, not proof he touched that mug."
              }
            },
            {
              "readAloud": {
                "accuses": "marla",
                "text": "I read {marla}'s signed six-o'clock bread delivery to Harper's classroom door. Owen saw her wait by the open records drawer. I see access, but not a fatal-morning visit.",
                "observation": "I read {marla}'s signed six-o'clock bread delivery to Harper's classroom door.",
                "contradictingDetail": "Owen saw her wait by the open records drawer. I see access, but not a fatal-morning visit."
              }
            },
            {
              "readAloud": {
                "accuses": "lydia",
                "text": "I read {lydia}'s warning to Tobias: children's family affairs don't belong in street notes. Her weekly lesson meetings explain contact to me, not an overnight alibi or receipt 47's torn page.",
                "observation": "I read {lydia}'s warning to Tobias: children's family affairs don't belong in street notes.",
                "contradictingDetail": "Her weekly lesson meetings explain contact to me, not an overnight alibi or receipt 47's torn page."
              }
            },
            {
              "readAloud": {
                "accuses": "xander",
                "text": "I heard Edith match {xander}'s licensed likeness and workshop address: Benjamin Barker, barber. His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse.",
                "observation": "I heard Edith match {xander}'s licensed likeness and workshop address: Benjamin Barker, barber.",
                "contradictingDetail": "His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse."
              }
            }
          ]
        },
        {
          "id": "lydia",
          "rounds": [
            {
              "readAloud": {
                "accuses": "xander",
                "text": "I heard Della saw Elias refuse to enter {xander}'s workshop over an old receipt. He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon.",
                "observation": "I heard Della saw Elias refuse to enter {xander}'s workshop over an old receipt.",
                "contradictingDetail": "He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon."
              }
            },
            {
              "readAloud": {
                "accuses": "marla",
                "text": "I heard Della heard {marla} dispute Ronan's flour bill at seven. She showed a receipt and left toward the bakery. I can't confirm payment or a later return.",
                "observation": "I heard Della heard {marla} dispute Ronan's flour bill at seven.",
                "contradictingDetail": "She showed a receipt and left toward the bakery. I can't confirm payment or a later return."
              }
            },
            {
              "readAloud": {
                "accuses": "jasper",
                "text": "I read {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak. I see how marks transfer, but Owen didn't watch the yard entrance overnight.",
                "observation": "I read {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak.",
                "contradictingDetail": "I see how marks transfer, but Owen didn't watch the yard entrance overnight."
              }
            },
            {
              "readAloud": {
                "accuses": "xander",
                "text": "I heard Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge. It went into his stamped sleeve. I worry about those precise cuts, not a confession.",
                "observation": "I heard Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge.",
                "contradictingDetail": "It went into his stamped sleeve. I worry about those precise cuts, not a confession."
              }
            },
            {
              "readAloud": {
                "accuses": "marla",
                "text": "I heard Edith confirm {marla}'s childhood delivery during Thorne's old workshop-home visit. She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot.",
                "observation": "I heard Edith confirm {marla}'s childhood delivery during Thorne's old workshop-home visit.",
                "contradictingDetail": "She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot."
              }
            }
          ]
        }
      ]
    }
  },
  "9": {
    "schemaVersion": 2,
    "fixedPlayerCount": 9,
    "discloseKiller": false,
    "clueRouting": "rotating",
    "edition": {
      "family": "blackwater-scalable",
      "id": "blackwater-scalable-9-players",
      "playerCount": 9,
      "revision": 1
    },
    "title": "The Barber of Blackwater Row",
    "atmosphere": "victorian",
    "setting": "Blackwater Row, a riverside town of workshops, narrow lanes and gaslit streets in the late nineteenth century.",
    "intro": "Evening settles over Blackwater Row. Three neighbors help the town investigator compare the supplied accounts: Xander Hale, the woodworker; Marla Quinn, the baker's assistant; and Jasper Crowe, the tavern musician. The host reads every recorded witness account before the players respond. Other named people remain in the evidence even when they are not playable. Discuss only the chapter just heard; nobody invents a history, witnesses a new discovery or improvises a private part.",
    "hiddenThread": "Receipt 47 recurs in every victim's disturbed records and finally names the Mayor's old imprisonment order against Benjamin Barker.",
    "coverageRepeatNote": "The trio covers all six directed pairs in the first two rounds. Later repeats add released evidence or explicitly correct an unsupported earlier inference. Each supplemental reader targets every other selected character before repeating, never in consecutive rounds. Separate singleton readings preserve the master loop and evidence timing.",
    "specialMechanics": [
      "Receipt 47 ledger: each murder surfaces another record indexed under receipt 47 (delivery log, tavern scrap, student-record index, night-route page). Compare them across rounds; the Mayor's signed order in Round 7 finally connects the series to the old case."
    ],
    "victim": {
      "name": "Elias Brim",
      "description": "The town baker, known for dependable bread deliveries and careful records."
    },
    "rounds": [
      {
        "title": "Round 1 - The Baker's Murder",
        "narration": "At dawn, delivery porter Finn Moss finds Elias Brim behind his bakery with his throat slashed. The investigator reports one clean, precise cut; the death happened off-screen. Elias supplied nearly every doorstep and recorded deliveries and closing chores in separate books. Finn calls night watchwoman Nell Reed before anyone enters the yard. She records a chain of flour prints from the back door to the wet cobbles. Each right print has a crescent-shaped gap at the heel; the cobbles preserve nothing beyond it. A page is torn from an older delivery log. Its surviving edge carries the date and part of receipt 47, but not a customer name or the purpose of the entry. The closing-duty sheet is intact and is kept for later comparison. These are the findings at this scene, not an identification of the killer. The investigator has collected four separate accounts about the neighbors.  Hear all four before discussing which details establish access and which merely raise suspicion.\n\nThe investigator reads the supporting witness accounts before calling on the selected readers:\n\nWitness background for Marla Quinn: Nell Reed saw Marla Quinn leave the bakery back door at nine, carrying her red-handled scrubbing brush. Nell recognized the brass buckle and crescent-shaped repair in the right heel of her work boots because cobbler Della March had shown her that repair at collection yesterday. Flour was packed into the repaired heel. The shape resembles the yard prints recorded this morning. This ties the boots to bakery work and the doorway, but does not date when each print was made. The closing-duty sheet has not yet been checked against the sighting.\n\nWitness background for Jasper Crowe: Finn Moss saw Jasper Crowe waiting behind the bakery at half past nine, with a blue-strapped instrument case propped against the wall. Finn recognized the musician from the tavern and the case from carrying it after last week's performance. A pale streak ran across its lower corner where it touched a flour sack outside the door. Finn heard him ask Elias for a promised parcel, but did not see a parcel handed over or hear what it contained. Finn left for the delivery cart; he did not witness the death or the musician's departure.\n\nWitness background for Lydia Vance: Della March saw Lydia Vance arguing with Elias at the bakery front counter that morning. She recognized the teacher from collecting her granddaughter from school and saw the same green lesson folder under her arm. Della heard the teacher ask why a bread bill included a household's personal history. Elias folded a paper and refused to answer. The teacher left a chalky thumb mark on the counter when she leaned forward. Della identifies the person and the topic, but heard no threat and never saw the contents of the folded paper.\n\nWitness background for Xander Hale: Della March delivered a wooden chair to Xander Hale's workshop last week and saw Elias at the open door. She recognized both men from their regular work at her market stall. Elias refused to enter and said, \"I will not bring that old receipt here again.\" The woodworker stopped sanding, gripped the chair rail and asked which book Elias meant. Della saw fresh amber shellac on his apron beside the repair cloth, but no weapon. She can identify the reaction and the receipt dispute; she cannot identify the old transaction or turn that reaction into proof of murder.\n\nThe host reads the original neighbors' recorded responses:\nXander Hale's recorded response: \"I heard Nell saw Marla Quinn leave the bakery's back door at nine with her red-handled brush. Her repaired, flour-packed heel resembles those prints. I still need their timing checked.\"\nMarla Quinn's recorded response: \"I heard Finn saw Jasper Crowe behind the bakery at nine-thirty with his blue-strapped case. A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave.\"\nJasper Crowe's recorded response: \"I heard Della saw Lydia Vance argue with Elias that morning, her green lesson folder tucked under her arm. A bread bill held family history. I wonder why he folded that paper.\"\nLydia Vance's recorded response: \"I heard Della saw Elias refuse to enter Xander Hale's workshop over an old receipt. He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon.\"\n\nThe supplied witness accounts support these comparisons:\nNell Reed recorded flour prints with a crescent gap in the right heel.\nDella March recognized the repaired boot from its collection yesterday.\nFinn Moss found Elias and called Nell before anyone entered the yard.\nAda Bell has not supplied a tavern account at this stage.\nOwen Bell has not supplied a classroom account at this stage.\nEdith Shaw has not supplied an office account at this stage.\nTown Investigator reported one precise cut at the bakery.\nDella recognized Lydia through collecting Della's Granddaughter from school.",
        "publicText": "Elias Brim: throat slashed with one precise cut. Finn Moss found the body; Nell Reed recorded flour prints with a crescent gap in the right heel. An old delivery-log page is torn; only receipt 47 survives at its edge. The closing-duty sheet is intact.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "At dawn, delivery porter Finn Moss finds Elias Brim behind his bakery with his throat slashed.",
          "The investigator reports one clean, precise cut; the death happened off-screen.",
          "Elias supplied nearly every doorstep and recorded deliveries and closing chores in separate books."
        ],
        "readingGroups": [
          [
            "xander",
            "marla",
            "jasper"
          ],
          [
            "lydia"
          ],
          [
            "nell"
          ],
          [
            "della"
          ],
          [
            "finn"
          ],
          [
            "ada"
          ],
          [
            "owen"
          ]
        ],
        "chain": [
          "xander",
          "marla",
          "jasper",
          "lydia",
          "nell",
          "della",
          "finn",
          "ada",
          "owen"
        ],
        "coverageRepeat": false
      },
      {
        "title": "Round 2 - The Barkeep's Murder",
        "narration": "The next morning, cleaner Ada Bell finds Ronan Pike slumped over his tavern counter with his throat slashed. The investigator records the same precise cut as at the bakery. Ronan kept accounts of debts and stayed late for private appointments. Ada does not touch the mug beside him; Nell Reed records that it has been wiped and has no usable fingerprints. A thin amber smear remains beneath its handle. No owner has been established for the mug or the smear. Beneath Ronan's account book lies a scrap bearing receipt 47 and four lines of dates. No names or explanation survive on the scrap. The matching number links two sets of records, but does not identify their subject. Ronan's service tally and appointment book are preserved separately so that the last drink served will not be confused with the last visitor admitted. Four witness accounts are ready.  Listen for who saw an object, how they identified its owner and whether their timing actually reaches the death.\n\nThe investigator reads the supporting witness accounts before calling on the selected readers:\n\nWitness background for Jasper Crowe: Ada Bell saw Jasper Crowe put his instrument case on Ronan's counter at ten and leave after the last public drink was served. She recognized the case by its repaired blue strap, which she had sewn herself. He uses amber rosin on his bow; Ada collected a flake from the spot where the case rested. Its color resembles the smear beneath the wiped mug, but color alone cannot establish that they are the same material. Ronan locked the public door afterward; Ada did not watch the side entrance or the later appointments.\n\nWitness background for Lydia Vance: Ada Bell heard Lydia Vance tell Ronan at eight, \"Those are dangerous notes; people did not give you permission to record their families.\" Ada recognized the green lesson folder under the teacher's arm from her school-cleaning rounds. The teacher tapped Ronan's account book, leaving a white powder trace on its dark cover. Ada collected it as a possible chalk transfer, not a laboratory identification. The warning concerns records, but Ada saw no page removed. The teacher walked out through the public door; Ada could not observe who returned later.\n\nWitness background for Xander Hale: Ronan's repair invoice records Xander Hale replacing the tavern shelf last week. Ada Bell identified him from the signed invoice and saw him open a leather tool sleeve stamped with the same workshop address. Inside were sharpening stones Ronan called \"too fine for woodworking\": one was much narrower and smoother than the broad stone used on the shelf chisel. Ada saw him wipe the sleeve with an amber shellac-stained cloth from his repair kit. That establishes ownership of the stones and a second possible source of amber residue; it does not prove who handled the wiped mug on the night of the murder.\n\nWitness background for Marla Quinn: Della March heard Marla Quinn dispute an unpaid flour bill with Ronan outside the tavern at seven. She recognized the baker's assistant by the stamped delivery basket she was carrying. Ronan held a bill with a torn lower corner; the assistant produced a coin receipt, but Della was too far away to compare its amount. She saw the assistant leave with the basket toward the bakery. The argument supplies a specific grievance and an observed departure, not proof of payment or a witnessed return to the counter where Ronan died.\n\nThe host reads the original neighbors' recorded responses:\nXander Hale's recorded response: \"I heard Ada saw Jasper Crowe's blue-strapped case on Ronan's counter at ten. His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors.\"\nMarla Quinn's recorded response: \"I heard Ada heard Lydia Vance warn Ronan about recording families at eight. She touched his book, leaving possible chalk. I can't prove a removed page or a later return.\"\nJasper Crowe's recorded response: \"I read Xander Hale's shelf invoice; Ada saw fine sharpening stones in his address-stamped sleeve. His repair cloth held amber shellac. I see another possible smear source, not proof he touched that mug.\"\nLydia Vance's recorded response: \"I heard Della heard Marla Quinn dispute Ronan's flour bill at seven. She showed a receipt and left toward the bakery. I can't confirm payment or a later return.\"\n\nThe supplied witness accounts support these comparisons:\nNell Reed recorded a wiped mug without usable fingerprints.\nDella March heard Marla dispute the flour bill and leave toward the bakery.\nFinn Moss did not witness the bakery death or the musician leaving.\nAda Bell found Ronan and left the mug untouched.\nOwen Bell has not supplied a classroom account at this stage.\nEdith Shaw has not supplied an office account at this stage.\nTown Investigator reported the same precise cut at the tavern.\nDella's school collection of Della's Granddaughter explains her recognition of Lydia.",
        "publicText": "Ronan Pike: throat slashed with the same precise cut. Ada Bell found him. A wiped mug has no usable fingerprints and an unidentified amber smear beneath its handle. A dated scrap bears receipt 47 but no names. Service and appointment records are preserved.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "The next morning, cleaner Ada Bell finds Ronan Pike slumped over his tavern counter with his throat slashed.",
          "The investigator records the same precise cut as at the bakery.",
          "Ronan kept accounts of debts and stayed late for private appointments."
        ],
        "readingGroups": [
          [
            "xander",
            "jasper",
            "marla"
          ],
          [
            "lydia"
          ],
          [
            "nell"
          ],
          [
            "della"
          ],
          [
            "finn"
          ],
          [
            "ada"
          ],
          [
            "owen"
          ]
        ],
        "chain": [
          "xander",
          "jasper",
          "marla",
          "lydia",
          "nell",
          "della",
          "finn",
          "ada",
          "owen"
        ],
        "coverageRepeat": false
      },
      {
        "title": "Round 3 - The Schoolteacher's Murder",
        "narration": "Before sunrise, caretaker Owen Bell finds senior teacher Harper Wren in her classroom with her throat slashed, the same precise cut again. Harper taught most of the town's children and kept family records as carefully as lesson plans. Owen locks the room and fetches Nell Reed. She records a broad chalk smear across the desk and a narrow drag line through it, running from the student-record book toward its open drawer. A page is missing from that book. Its remaining index cites receipt 47; a margin note says, \"Copy kept with the original order.\" Neither the order's owner nor its location is recorded here. Owen also hands over the fundraiser attendance sheet and Harper's lesson diary, both intact. Three disturbed records now share a number. That is a link worth following, not yet an explanation.  Compare observed visits with the traces on the desk, and keep the identity of any missing document separate from guesses about it.\n\nThe investigator reads the supporting witness accounts before calling on the selected readers:\n\nWitness background for Lydia Vance: Owen Bell saw Lydia Vance enter Harper's classroom at six carrying her green lesson folder. He recognized her name written inside its cover when she left it beside the register. A broad chalk mark on the folder's edge matches the height of the smeared desk; Owen had watched her lean it there while discussing pupil privacy. Her warning was, \"A family record should not become a weapon.\" This explains regular access and a possible source of chalk transfer, but Owen left at seven and cannot account for the classroom overnight.\n\nWitness background for Xander Hale: Owen Bell recalls Harper pointing out Xander Hale's narrow whetstone while the woodworker repaired her drawer rail last Tuesday. Owen saw the stone in a leather sleeve stamped with the workshop's address; he checked that address on the repair invoice. Harper said he \"used to work with blades in another trade\" but did not name it. Owen also saw fresh blue chalk on the woodworker's cuff after measuring the rail with Harper's chalk line. That gives an ordinary source for the cuff mark, not an explanation of the missing page or the earlier blade skills.\n\nWitness background for Marla Quinn: Owen Bell signed for Marla Quinn's six-o'clock bread delivery to Harper on the morning before the death. He recognized the baker's stamped basket and the repaired brass-buckled boots described in Round 1. The delivery docket, signed by Harper, specifies the classroom door rather than the school kitchen. Owen saw the assistant wait while Harper opened the student-record drawer to find payment. This gives a witnessed reason for knowing Harper's schedule and seeing the drawer. Neither the flour on the boots nor that access proves a visit before sunrise on the fatal morning.\n\nWitness background for Jasper Crowe: Owen Bell checked Jasper Crowe's name on the fundraiser attendance sheet at nine the previous evening. He recognized the blue-strapped case and watched the musician leave it beside Harper's desk while stacking chairs. White chalk marked the case corner where it rubbed the desktop, covering part of the pale bakery streak described in Round 1. Owen identifies a source for the transfer and a reason for being in the room. He locked the public school door after the event, but did not remain to watch the classroom's separate yard entrance overnight.\n\nThe host reads the original neighbors' recorded responses:\nXander Hale's recorded response: \"I heard Owen saw Lydia Vance's green folder in Harper's classroom at six, discussing pupil privacy. Its chalk matches the desk height. I worry about access, but Owen left at seven.\"\nMarla Quinn's recorded response: \"I heard Harper said Xander Hale once worked with blades; Owen saw his narrow whetstone during her drawer repair. Chalk explains his cuff mark to me, not missing pages or blade skills.\"\nJasper Crowe's recorded response: \"I read Marla Quinn's signed six-o'clock bread delivery to Harper's classroom door. Owen saw her wait by the open records drawer. I see access, but not a fatal-morning visit.\"\nLydia Vance's recorded response: \"I read Jasper Crowe's nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak. I see how marks transfer, but Owen didn't watch the yard entrance overnight.\"\n\nThe supplied witness accounts support these comparisons:\nNell Reed recorded a chalk smear and narrow drag line through it.\nDella March identified Lydia and the topic of the bakery argument.\nFinn Moss heard a promised parcel requested but saw no handover.\nAda Bell saw the fine stones in an address-stamped sleeve.\nOwen Bell found Harper, locked the classroom and fetched Nell.\nEdith Shaw has not supplied an office account at this stage.\nTown Investigator connected three disturbed records by receipt 47.\nDella's collection of Della's Granddaughter identifies a teacher, not a threat.",
        "publicText": "Harper Wren: throat slashed with the same precise cut. Owen Bell found her; Nell Reed recorded chalk and a drag line beside a disturbed student-record book. Its index cites receipt 47 and a copy kept with an unnamed original order. Attendance and lesson records are intact.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "Before sunrise, caretaker Owen Bell finds senior teacher Harper Wren in her classroom with her throat slashed, the same precise cut again.",
          "Harper taught most of the town's children and kept family records as carefully as lesson plans.",
          "Owen locks the room and fetches Nell Reed."
        ],
        "readingGroups": [
          [
            "xander",
            "marla",
            "jasper"
          ],
          [
            "lydia"
          ],
          [
            "nell"
          ],
          [
            "della"
          ],
          [
            "finn"
          ],
          [
            "ada"
          ],
          [
            "owen"
          ]
        ],
        "chain": [
          "xander",
          "marla",
          "jasper",
          "lydia",
          "nell",
          "della",
          "finn",
          "ada",
          "owen"
        ],
        "coverageRepeat": true
      },
      {
        "title": "Round 4 - Visits and Transferred Marks",
        "narration": "Compare only the findings already read at the bakery, tavern and school. An evening delivery is not a fatal-morning visit; flour, rosin, shellac and chalk have witnessed work-related sources. Receipt 47 links disturbed records but does not yet identify their subject. Correct an accusation that mistakes a work trace or access for a witnessed killing. No new death, name, trade or weapon identification is introduced.",
        "publicText": "Correct earlier inferences using only already released evidence.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "Compare released work traces with the recorded visits.",
          "Correct unsupported accusations without a new discovery."
        ],
        "readingGroups": [
          [
            "xander",
            "jasper",
            "marla"
          ],
          [
            "lydia"
          ],
          [
            "nell"
          ],
          [
            "della"
          ],
          [
            "finn"
          ],
          [
            "ada"
          ],
          [
            "owen"
          ]
        ],
        "chain": [
          "xander",
          "jasper",
          "marla",
          "lydia",
          "nell",
          "della",
          "finn",
          "ada",
          "owen"
        ],
        "coverageRepeat": true
      },
      {
        "title": "Round 5 - The Lamplighter's Murder",
        "narration": "Before the morning market opens, Nell Reed finds Tobias Wick beside an extinguished streetlamp with his throat slashed in the same precise manner. Tobias walked every lane at night and kept route notes about what he saw. Lamp oil has spilled in a perfect circle around the lamp base. Nell records its position before moving the fallen oil flask; the shape of the spill alone cannot identify who was there. A page is torn from Tobias's old route notebook. The surviving index bears receipt 47 and the instruction, \"Retain duplicate with original order.\" Nell gathers the bakery closing-duty sheet, Ronan's appointment book and Harper's lesson diary for comparison with the earlier witness accounts. Their entries can explain a visit or correct a timing assumption, but they are not blanket alibis. The subject of the old records is still missing.  Let each account introduce its own new finding. Then compare the four scenes and ask which traces are ordinary work and which remain unexplained.\n\nThe investigator reads the supporting witness accounts before calling on the selected readers:\n\nWitness background for Marla Quinn: Nell Reed compares Marla Quinn's flour-marked repaired boot from Round 1 with the bakery closing-duty sheet. Elias initialed her nine-o'clock task: scrub the rear threshold, then deliver the waste pail to the market. The entry explains why the crescent heel and flour appeared at the doorway; it is not evidence that the print was made during the killing. Market seller Della March also records that the assistant reported Tobias arguing with an unidentified figure beside the oil stall last night. Della heard the report, not the argument, so she cannot identify that figure.\n\nWitness background for Jasper Crowe: Della March saw Jasper Crowe follow Tobias from the tavern to the market lamp at ten last night. She identified the musician by his blue-strapped case and by the tune he had just played at her stall. Tobias asked him to hold the oil flask while adjusting the wick; Della saw a drop spill onto his right sleeve. The stain therefore has an observed source, not merely an assumed link to lamplighting. Della closed her shutter before Tobias resumed his route. The musician's presence and oil stain establish contact, but not where either man went afterward.\n\nWitness background for Lydia Vance: Nell Reed finds Lydia Vance's warning to Tobias entered in his intact route book: \"Children's family affairs do not belong in street notes.\" The entry describes her green folder and the school gate, where Owen Bell confirms he saw them speak. Nell compares it with Harper's lesson diary, which schedules their weekly meetings to prepare lessons and handle family requests. These sources explain the teacher's meetings and concern about records without supplying an overnight alibi. They do not explain why the older page indexed under receipt 47 was torn out.\n\nWitness background for Xander Hale: Nell Reed saw Xander Hale beneath the workshop lamp yesterday evening, holding a straight razor rather than a woodworking chisel. She recognized him from the shelf-repair invoice she had collected at the tavern and spoke to him face to face. The open blade reflected the lamp; the ivory handle had a triangular chip beside its hinge. He closed it and put it into the address-stamped leather sleeve whose fine stones Ada Bell described in Round 2. Nell can identify the owner, object and distinctive damage, but she did not see an attack. The blade should be compared with the repeated precise cuts, not treated as a confession.\n\nThe host reads the original neighbors' recorded responses:\nXander Hale's recorded response: \"I read Marla Quinn's nine-o'clock closing duty: scrub the rear threshold, then take waste to market. I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone.\"\nMarla Quinn's recorded response: \"I heard Della saw Jasper Crowe follow Tobias to the market lamp at ten. He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward.\"\nJasper Crowe's recorded response: \"I read Lydia Vance's warning to Tobias: children's family affairs don't belong in street notes. Her weekly lesson meetings explain contact to me, not an overnight alibi or receipt 47's torn page.\"\nLydia Vance's recorded response: \"I heard Nell saw Xander Hale's straight razor: ivory handle, triangular chip beside its hinge. It went into his stamped sleeve. I worry about those precise cuts, not a confession.\"\n\nThe supplied witness accounts support these comparisons:\nNell Reed saw the chipped ivory razor enter the stamped sleeve.\nDella March saw Jasper holding the flask before oil spilled on his sleeve.\nFinn Moss left for the delivery cart without witnessing the bakery death.\nAda Bell saw the blue-strapped case on Ronan's counter at ten.\nOwen Bell left at seven without watching the separate yard entrance overnight.\nEdith Shaw has not supplied an office account at this stage.\nTown Investigator preserved the earlier work records for timing comparisons.\nDella's school collection of Della's Granddaughter does not identify a murderer.",
        "publicText": "Tobias Wick: throat slashed with the same precise cut. Nell Reed found him beside an extinguished lamp and a circle of spilled oil. A torn night-route page is indexed under receipt 47. Earlier work and appointment records are ready for comparison, not complete alibis.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "Before the morning market opens, Nell Reed finds Tobias Wick beside an extinguished streetlamp with his throat slashed in the same precise manner.",
          "Tobias walked every lane at night and kept route notes about what he saw.",
          "Lamp oil has spilled in a perfect circle around the lamp base."
        ],
        "readingGroups": [
          [
            "xander",
            "marla",
            "jasper"
          ],
          [
            "lydia"
          ],
          [
            "nell"
          ],
          [
            "della"
          ],
          [
            "finn"
          ],
          [
            "ada"
          ],
          [
            "owen"
          ]
        ],
        "chain": [
          "xander",
          "marla",
          "jasper",
          "lydia",
          "nell",
          "della",
          "finn",
          "ada",
          "owen"
        ],
        "coverageRepeat": true
      },
      {
        "title": "Round 6 - Work Traces and the Identified Tool",
        "narration": "Compare the already released closing-duty sheet, private-appointment records, school visits and Nell's chipped-razor sighting. A work record can explain a trace without supplying an overnight alibi. The identified razor is more specific than an unexplained color or stain, but its sighting is not a confession. Correct earlier accusations based only on flour, chalk or spilled oil. No new death or old identity is introduced.",
        "publicText": "Correct earlier inferences using only already released evidence.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "Compare released work traces with the recorded visits.",
          "Correct unsupported accusations without a new discovery."
        ],
        "readingGroups": [
          [
            "xander",
            "jasper",
            "marla"
          ],
          [
            "lydia"
          ],
          [
            "nell"
          ],
          [
            "della"
          ],
          [
            "finn"
          ],
          [
            "ada"
          ],
          [
            "owen"
          ]
        ],
        "chain": [
          "xander",
          "jasper",
          "marla",
          "lydia",
          "nell",
          "della",
          "finn",
          "ada",
          "owen"
        ],
        "coverageRepeat": true
      },
      {
        "title": "Round 7 - The Mayor's Murder",
        "narration": "Office clerk Edith Shaw finds Mayor Aldric Thorne in his office chair with his throat slashed, the same precise cut. A polished straight razor lies on the desk, its ivory handle chipped beside the hinge. Edith calls Nell Reed and identifies the locked cabinet from which the papers on the desk came; its numbered index and broken wax seal allow the investigator to trace their source. A single old court document, signed by Thorne, orders the imprisonment of BENJAMIN BARKER and bears receipt 47. This is the first time that name enters the investigation. With it are the duplicate records referred to in Harper's index and Tobias's notebook. The investigator reads them aloud: Elias signed a false delivery entry placing Barker at a theft; Ronan signed a fabricated account of a confession; Harper altered a household record to support the charge; Tobias supplied a false night-route sighting. A retained letter from Thorne orders the changes, admits that he wanted Barker's wife and describes using imprisonment to separate them. The household record states that she was taken into Thorne's household under coercion, not by free choice. Barker's licensed occupation is barber. A likeness, address and tool inventory are attached, but the investigator leaves their identification to the witnesses whose accounts you are about to hear. These documents establish the original injustice and the four victims' roles. They do not announce which current neighbor committed the murders.  Hear every account before the final vote.\n\nThe investigator reads the supporting witness accounts before calling on the selected readers:\n\nWitness background for Jasper Crowe: Edith Shaw asks Jasper Crowe to explain a rumor he heard at the tavern about the woodworker once using a different name. He identifies its source as Ronan's remark about an old license, not personal knowledge of the imprisonment. Edith compares the signature on his ten-o'clock drink receipt with the appointment book preserved in Round 2; it confirms his earlier visit, while a separate eleven-o'clock entry admits a private visitor. His rosin flake explains a substance on the counter, but neither the rumor nor the flake identifies that later visitor or makes him a signer of the false statements in the court file.\n\nWitness background for Lydia Vance: Edith Shaw compares Lydia Vance's account of seeing the Mayor hide an old paper with the cabinet index recovered today. The teacher dates the sighting to a school-funding appointment entered in Edith's diary; Edith confirms she admitted her for that appointment and saw Thorne close the folder. The teacher could read receipt 47, but not the name hidden beneath his hand. This explains why the teacher questioned intrusive family records. Her chalk-marked folder and weekly lesson meetings establish access to school papers, not a signature on the falsified statements read from the court file.\n\nWitness background for Xander Hale: Edith Shaw identifies the court file's licensed likeness as Xander Hale; she compares the workshop address printed beside it with the signed shelf-repair invoice preserved in Round 2. The licensed name is Benjamin Barker. The barber's tool inventory describes an ivory razor with a chip beside the hinge, matching the blade Nell Reed saw in his hand in Round 4 and the one now on Thorne's desk. The fine stones and Harper's earlier-trade remark fit the documented occupation. The duplicate records identify the four people who helped Thorne destroy his former life. This joins identity, blade ownership and motive; the room must still decide its final accusation.\n\nWitness background for Marla Quinn: Edith Shaw checks Marla Quinn's account of an old visit by Thorne to the workshop home. The assistant remembers delivering a baker's basket there as a child; the retained delivery copy records the date and the house number. Edith compares those details with Thorne's appointment diary and confirms the visit. The account links a remembered visit to a documented place, but the assistant did not hear the conversation. Her repaired flour-marked boot still fits the closing chore established in Round 4, not a proven killing. Neither her childhood observation nor her recent bread delivery makes her one of the signers identified in the old file.\n\nThe host reads the original neighbors' recorded responses:\nXander Hale's recorded response: \"I heard Jasper Crowe's different-name rumor came from Ronan's old-license remark. His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin.\"\nMarla Quinn's recorded response: \"I learned Lydia Vance saw Thorne hide receipt 47 during her confirmed school-funding appointment. She couldn't read the name. I see why she questioned family records, not proof she falsified them.\"\nJasper Crowe's recorded response: \"I heard Edith match Xander Hale's licensed likeness and workshop address: Benjamin Barker, barber. His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse.\"\nLydia Vance's recorded response: \"I heard Edith confirm Marla Quinn's childhood delivery during Thorne's old workshop-home visit. She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot.\"\n\nThe supplied witness accounts support these comparisons:\nNell Reed identified the damaged razor in the earlier sighting.\nDella March's boot identification established work access, not print timing.\nFinn Moss's case account established an evening visit, not a witnessed murder.\nAda Bell's account left later private visitors possible.\nOwen Bell's accounts did not establish an overnight alibi.\nEdith Shaw matched the licensed likeness and address to Xander.\nTown Investigator read the retained duplicate records and Thorne's letter.\nDella's identification through Della's Granddaughter does not implicate Lydia in the old falsification.",
        "publicText": "Mayor Aldric Thorne: throat slashed; a polished razor with a chipped ivory handle on his desk. Edith Shaw identifies the cabinet and record index. Thorne's signed imprisonment order names Benjamin Barker under receipt 47. Duplicate records and his letter expose the four victims' false statements and his coercion. Witness identification follows in the player readings.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "Office clerk Edith Shaw finds Mayor Aldric Thorne in his office chair with his throat slashed, the same precise cut.",
          "A polished straight razor lies on the desk, its ivory handle chipped beside the hinge.",
          "Edith calls Nell Reed and identifies the locked cabinet from which the papers on the desk came; its numbered index and broken wax seal allow the investigator to trace their source."
        ],
        "readingGroups": [
          [
            "xander",
            "marla",
            "jasper"
          ],
          [
            "lydia"
          ],
          [
            "nell"
          ],
          [
            "della"
          ],
          [
            "finn"
          ],
          [
            "ada"
          ],
          [
            "owen"
          ]
        ],
        "chain": [
          "xander",
          "marla",
          "jasper",
          "lydia",
          "nell",
          "della",
          "finn",
          "ada",
          "owen"
        ],
        "coverageRepeat": true
      }
    ],
    "characters": [
      {
        "id": "xander",
        "name": "Xander Hale",
        "role": "Woodworker",
        "relationship": "A neighbor asked by the town investigator to help compare witness accounts of the Blackwater Row murders.",
        "tieIn": "A quiet craftsperson who repairs furniture and makes wooden fittings in a workshop off the market lane.",
        "optional": false,
        "ghost": null,
        "guest": "",
        "guestNote": "",
        "publicBlurb": "A quiet craftsperson who repairs furniture and makes wooden fittings in a workshop off the market lane.",
        "rounds": [
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I heard Nell saw {marla} leave the bakery's back door at nine with her red-handled brush. Her repaired, flour-packed heel resembles those prints. I still need their timing checked.",
              "observation": "I heard Nell saw {marla} leave the bakery's back door at nine with her red-handled brush.",
              "contradictingDetail": "Her repaired, flour-packed heel resembles those prints. I still need their timing checked."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I heard Ada saw {jasper}'s blue-strapped case on Ronan's counter at ten. His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors.",
              "observation": "I heard Ada saw {jasper}'s blue-strapped case on Ronan's counter at ten.",
              "contradictingDetail": "His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I read {marla}'s signed six-o'clock bread delivery to Harper's classroom door. Owen saw her wait by the open records drawer. I see access, but not a fatal-morning visit.",
              "observation": "I read {marla}'s signed six-o'clock bread delivery to Harper's classroom door.",
              "contradictingDetail": "Owen saw her wait by the open records drawer. I see access, but not a fatal-morning visit."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I heard {jasper}'s case rubbed the chalky desk over its flour streak. I must distinguish transferred work marks from evidence that he removed the student-record page.",
              "observation": "I heard {jasper}'s case rubbed the chalky desk over its flour streak.",
              "contradictingDetail": "I must distinguish transferred work marks from evidence that he removed the student-record page."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I read {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market. I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone.",
              "observation": "I read {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market.",
              "contradictingDetail": "I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I read {jasper}'s visit to the lamp in Della's account. I must not treat spilled oil on his sleeve as proof of a precise cut or an account of his later movements.",
              "observation": "I read {jasper}'s visit to the lamp in Della's account.",
              "contradictingDetail": "I must not treat spilled oil on his sleeve as proof of a precise cut or an account of his later movements."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I heard Edith confirm {marla}'s childhood delivery during Thorne's old workshop-home visit. She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot.",
              "observation": "I heard Edith confirm {marla}'s childhood delivery during Thorne's old workshop-home visit.",
              "contradictingDetail": "She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot."
            }
          }
        ]
      },
      {
        "id": "marla",
        "name": "Marla Quinn",
        "role": "Baker's assistant",
        "relationship": "Assistant to the first victim, the baker Elias Brim; asked to help compare witness accounts.",
        "tieIn": "Elias Brim's assistant, responsible for bread deliveries and the evening cleanup. A familiar face at doorsteps across town.",
        "optional": false,
        "ghost": null,
        "guest": "",
        "guestNote": "",
        "publicBlurb": "Elias Brim's assistant, responsible for bread deliveries and the evening cleanup. A familiar face at doorsteps across town.",
        "rounds": [
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I heard Finn saw {jasper} behind the bakery at nine-thirty with his blue-strapped case. A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave.",
              "observation": "I heard Finn saw {jasper} behind the bakery at nine-thirty with his blue-strapped case.",
              "contradictingDetail": "A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I read {xander}'s shelf invoice; Ada saw fine sharpening stones in his address-stamped sleeve. His repair cloth held amber shellac. I see another possible smear source, not proof he touched that mug.",
              "observation": "I read {xander}'s shelf invoice; Ada saw fine sharpening stones in his address-stamped sleeve.",
              "contradictingDetail": "His repair cloth held amber shellac. I see another possible smear source, not proof he touched that mug."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I read {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak. I see how marks transfer, but Owen didn't watch the yard entrance overnight.",
              "observation": "I read {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak.",
              "contradictingDetail": "I see how marks transfer, but Owen didn't watch the yard entrance overnight."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard {xander}'s drawer repair explained chalk on his cuff. I must not mistake a work mark for an explanation of the missing pages or his earlier blade skills.",
              "observation": "I heard {xander}'s drawer repair explained chalk on his cuff.",
              "contradictingDetail": "I must not mistake a work mark for an explanation of the missing pages or his earlier blade skills."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I heard Della saw {jasper} follow Tobias to the market lamp at ten. He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward.",
              "observation": "I heard Della saw {jasper} follow Tobias to the market lamp at ten.",
              "contradictingDetail": "He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard Nell identify {xander}'s chipped ivory razor. I must compare that identifiable tool with the repeated cuts, not call the sighting a confession.",
              "observation": "I heard Nell identify {xander}'s chipped ivory razor.",
              "contradictingDetail": "I must compare that identifiable tool with the repeated cuts, not call the sighting a confession."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I heard {jasper}'s different-name rumor came from Ronan's old-license remark. His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin.",
              "observation": "I heard {jasper}'s different-name rumor came from Ronan's old-license remark.",
              "contradictingDetail": "His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin."
            }
          }
        ]
      },
      {
        "id": "jasper",
        "name": "Jasper Crowe",
        "role": "Tavern musician",
        "relationship": "Musician at the tavern of the second victim, Ronan Pike; asked to help compare witness accounts.",
        "tieIn": "A musician at Ronan Pike's tavern who also plays for town events. Often out late carrying his instrument between jobs.",
        "optional": false,
        "ghost": null,
        "guest": "",
        "guestNote": "",
        "publicBlurb": "A musician at Ronan Pike's tavern who also plays for town events. Often out late carrying his instrument between jobs.",
        "rounds": [
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard Della saw Elias refuse to enter {xander}'s workshop over an old receipt. He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon.",
              "observation": "I heard Della saw Elias refuse to enter {xander}'s workshop over an old receipt.",
              "contradictingDetail": "He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I heard Della heard {marla} dispute Ronan's flour bill at seven. She showed a receipt and left toward the bakery. I can't confirm payment or a later return.",
              "observation": "I heard Della heard {marla} dispute Ronan's flour bill at seven.",
              "contradictingDetail": "She showed a receipt and left toward the bakery. I can't confirm payment or a later return."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair. Chalk explains his cuff mark to me, not missing pages or blade skills.",
              "observation": "I heard Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair.",
              "contradictingDetail": "Chalk explains his cuff mark to me, not missing pages or blade skills."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I read {marla}'s signed bread delivery at six. I must distinguish an evening delivery from a fatal-morning visit; access alone does not explain the missing page.",
              "observation": "I read {marla}'s signed bread delivery at six.",
              "contradictingDetail": "I must distinguish an evening delivery from a fatal-morning visit; access alone does not explain the missing page."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge. It went into his stamped sleeve. I worry about those precise cuts, not a confession.",
              "observation": "I heard Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge.",
              "contradictingDetail": "It went into his stamped sleeve. I worry about those precise cuts, not a confession."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I read {marla}'s closing duty to scrub the rear threshold. I must correct my earlier suspicion: flour in her repaired heel can come from work, not a witnessed killing.",
              "observation": "I read {marla}'s closing duty to scrub the rear threshold.",
              "contradictingDetail": "I must correct my earlier suspicion: flour in her repaired heel can come from work, not a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard Edith match {xander}'s licensed likeness and workshop address: Benjamin Barker, barber. His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse.",
              "observation": "I heard Edith match {xander}'s licensed likeness and workshop address: Benjamin Barker, barber.",
              "contradictingDetail": "His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse."
            }
          }
        ]
      },
      {
        "id": "lydia",
        "name": "Lydia Vance",
        "role": "Schoolteacher",
        "relationship": "Teacher working alongside the third victim, senior teacher Harper Wren; asked to help compare witness accounts.",
        "tieIn": "A teacher working alongside senior teacher Harper Wren. Attentive to local families and protective of their privacy.",
        "publicBlurb": "A teacher working alongside senior teacher Harper Wren. Attentive to local families and protective of their privacy.",
        "optional": false,
        "guest": "",
        "guestNote": "",
        "ghost": null,
        "rounds": [
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I learned Della saw Elias refuse to enter {xander}'s workshop over an old receipt. He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon.",
              "observation": "I learned Della saw Elias refuse to enter {xander}'s workshop over an old receipt.",
              "contradictingDetail": "He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I learned Della heard {marla} dispute Ronan's flour bill at seven. She showed a receipt and left toward the bakery. I can't confirm payment or a later return.",
              "observation": "I learned Della heard {marla} dispute Ronan's flour bill at seven.",
              "contradictingDetail": "She showed a receipt and left toward the bakery. I can't confirm payment or a later return."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I checked {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak. I see how marks transfer, but Owen didn't watch the yard entrance overnight.",
              "observation": "I checked {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak.",
              "contradictingDetail": "I see how marks transfer, but Owen didn't watch the yard entrance overnight."
            }
          },
          {
            "readAloud": {
              "accuses": "nell",
              "text": "I heard the account: {nell} recorded a chalk smear and narrow drag line through it. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: {nell} recorded a chalk smear and narrow drag line through it.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "della",
              "text": "I heard the account: {della} saw Jasper holding the flask before oil spilled on his sleeve. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {della} saw Jasper holding the flask before oil spilled on his sleeve.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "finn",
              "text": "I heard the account: {finn} left for the delivery cart without witnessing the bakery death. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: {finn} left for the delivery cart without witnessing the bakery death.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "ada",
              "text": "I heard the account: {ada}'s account left later private visitors possible. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {ada}'s account left later private visitors possible.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          }
        ]
      },
      {
        "id": "nell",
        "name": "Nell Reed",
        "role": "Night watchwoman",
        "relationship": "An existing person in the supplied Blackwater Row accounts.",
        "tieIn": "Records the scene findings and supplies the razor sighting.",
        "publicBlurb": "Records the scene findings and supplies the razor sighting.",
        "optional": false,
        "guest": "",
        "guestNote": "",
        "ghost": null,
        "rounds": [
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I learned Nell saw {marla} leave the bakery's back door at nine with her red-handled brush. Her repaired, flour-packed heel resembles those prints. I still need their timing checked.",
              "observation": "I learned Nell saw {marla} leave the bakery's back door at nine with her red-handled brush.",
              "contradictingDetail": "Her repaired, flour-packed heel resembles those prints. I still need their timing checked."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I learned Ada saw {jasper}'s blue-strapped case on Ronan's counter at ten. His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors.",
              "observation": "I learned Ada saw {jasper}'s blue-strapped case on Ronan's counter at ten.",
              "contradictingDetail": "His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors."
            }
          },
          {
            "readAloud": {
              "accuses": "lydia",
              "text": "I learned Owen saw {lydia}'s green folder in Harper's classroom at six, discussing pupil privacy. Its chalk matches the desk height. I worry about access, but Owen left at seven.",
              "observation": "I learned Owen saw {lydia}'s green folder in Harper's classroom at six, discussing pupil privacy.",
              "contradictingDetail": "Its chalk matches the desk height. I worry about access, but Owen left at seven."
            }
          },
          {
            "readAloud": {
              "accuses": "della",
              "text": "I heard the account: {della} identified Lydia and the topic of the bakery argument. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: {della} identified Lydia and the topic of the bakery argument.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "finn",
              "text": "I heard the account: {finn} left for the delivery cart without witnessing the bakery death. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {finn} left for the delivery cart without witnessing the bakery death.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "ada",
              "text": "I heard the account: {ada} saw the blue-strapped case on Ronan's counter at ten. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: {ada} saw the blue-strapped case on Ronan's counter at ten.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "owen",
              "text": "I heard the account: {owen}'s accounts did not establish an overnight alibi. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {owen}'s accounts did not establish an overnight alibi.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          }
        ]
      },
      {
        "id": "della",
        "name": "Della March",
        "role": "Cobbler",
        "relationship": "An existing person in the supplied Blackwater Row accounts.",
        "tieIn": "Identifies the repaired boot and the neighbors in her recorded accounts.",
        "publicBlurb": "Identifies the repaired boot and the neighbors in her recorded accounts.",
        "optional": false,
        "guest": "",
        "guestNote": "",
        "ghost": null,
        "rounds": [
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I learned Finn saw {jasper} behind the bakery at nine-thirty with his blue-strapped case. A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave.",
              "observation": "I learned Finn saw {jasper} behind the bakery at nine-thirty with his blue-strapped case.",
              "contradictingDetail": "A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave."
            }
          },
          {
            "readAloud": {
              "accuses": "lydia",
              "text": "I learned Ada heard {lydia} warn Ronan about recording families at eight. She touched his book, leaving possible chalk. I can't prove a removed page or a later return.",
              "observation": "I learned Ada heard {lydia} warn Ronan about recording families at eight.",
              "contradictingDetail": "She touched his book, leaving possible chalk. I can't prove a removed page or a later return."
            }
          },
          {
            "readAloud": {
              "accuses": "nell",
              "text": "I heard the account: {nell} recorded a chalk smear and narrow drag line through it. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {nell} recorded a chalk smear and narrow drag line through it.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "finn",
              "text": "I heard the account: {finn} heard a promised parcel requested but saw no handover. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: {finn} heard a promised parcel requested but saw no handover.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "ada",
              "text": "I heard the account: {ada} saw the blue-strapped case on Ronan's counter at ten. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {ada} saw the blue-strapped case on Ronan's counter at ten.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "owen",
              "text": "I heard the account: {owen} left at seven without watching the separate yard entrance overnight. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: {owen} left at seven without watching the separate yard entrance overnight.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I learned Edith match {xander}'s licensed likeness and workshop address: Benjamin Barker, barber. His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse.",
              "observation": "I learned Edith match {xander}'s licensed likeness and workshop address: Benjamin Barker, barber.",
              "contradictingDetail": "His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse."
            }
          }
        ]
      },
      {
        "id": "finn",
        "name": "Finn Moss",
        "role": "Delivery porter",
        "relationship": "An existing person in the supplied Blackwater Row accounts.",
        "tieIn": "Finds Elias and reports the musician waiting behind the bakery.",
        "publicBlurb": "Finds Elias and reports the musician waiting behind the bakery.",
        "optional": false,
        "guest": "",
        "guestNote": "",
        "ghost": null,
        "rounds": [
          {
            "readAloud": {
              "accuses": "lydia",
              "text": "I learned Della saw {lydia} argue with Elias that morning, her green lesson folder tucked under her arm. A bread bill held family history. I wonder why he folded that paper.",
              "observation": "I learned Della saw {lydia} argue with Elias that morning, her green lesson folder tucked under her arm.",
              "contradictingDetail": "A bread bill held family history. I wonder why he folded that paper."
            }
          },
          {
            "readAloud": {
              "accuses": "nell",
              "text": "I heard the account: {nell} recorded a wiped mug without usable fingerprints. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {nell} recorded a wiped mug without usable fingerprints.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "della",
              "text": "I heard the account: {della} identified Lydia and the topic of the bakery argument. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {della} identified Lydia and the topic of the bakery argument.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "ada",
              "text": "I heard the account: {ada} saw the fine stones in an address-stamped sleeve. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: {ada} saw the fine stones in an address-stamped sleeve.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "owen",
              "text": "I heard the account: {owen} left at seven without watching the separate yard entrance overnight. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {owen} left at seven without watching the separate yard entrance overnight.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I learned Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge. It went into his stamped sleeve. I worry about those precise cuts, not a confession.",
              "observation": "I learned Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge.",
              "contradictingDetail": "It went into his stamped sleeve. I worry about those precise cuts, not a confession."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I learned Edith confirm {marla}'s childhood delivery during Thorne's old workshop-home visit. She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot.",
              "observation": "I learned Edith confirm {marla}'s childhood delivery during Thorne's old workshop-home visit.",
              "contradictingDetail": "She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot."
            }
          }
        ]
      },
      {
        "id": "ada",
        "name": "Ada Bell",
        "role": "Tavern cleaner",
        "relationship": "An existing person in the supplied Blackwater Row accounts.",
        "tieIn": "Finds Ronan and reports the tavern objects and appointments.",
        "publicBlurb": "Finds Ronan and reports the tavern objects and appointments.",
        "optional": false,
        "guest": "",
        "guestNote": "",
        "ghost": null,
        "rounds": [
          {
            "readAloud": {
              "accuses": "nell",
              "text": "I heard the account: {nell} recorded flour prints with a crescent gap in the right heel. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {nell} recorded flour prints with a crescent gap in the right heel.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "della",
              "text": "I heard the account: {della} heard Marla dispute the flour bill and leave toward the bakery. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {della} heard Marla dispute the flour bill and leave toward the bakery.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "finn",
              "text": "I heard the account: {finn} heard a promised parcel requested but saw no handover. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {finn} heard a promised parcel requested but saw no handover.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "owen",
              "text": "I heard the account: {owen} found Harper, locked the classroom and fetched Nell. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: {owen} found Harper, locked the classroom and fetched Nell.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I learned Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge. It went into his stamped sleeve. I worry about those precise cuts, not a confession.",
              "observation": "I learned Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge.",
              "contradictingDetail": "It went into his stamped sleeve. I worry about those precise cuts, not a confession."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I checked {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market. I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone.",
              "observation": "I checked {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market.",
              "contradictingDetail": "I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I learned {jasper}'s different-name rumor came from Ronan's old-license remark. His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin.",
              "observation": "I learned {jasper}'s different-name rumor came from Ronan's old-license remark.",
              "contradictingDetail": "His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin."
            }
          }
        ]
      },
      {
        "id": "owen",
        "name": "Owen Bell",
        "role": "School caretaker",
        "relationship": "An existing person in the supplied Blackwater Row accounts.",
        "tieIn": "Finds Harper and supplies the school visit accounts and records.",
        "publicBlurb": "Finds Harper and supplies the school visit accounts and records.",
        "optional": false,
        "guest": "",
        "guestNote": "",
        "ghost": null,
        "rounds": [
          {
            "readAloud": {
              "accuses": "della",
              "text": "I heard the account: {della} recognized the repaired boot from its collection yesterday. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {della} recognized the repaired boot from its collection yesterday.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "finn",
              "text": "I heard the account: {finn} did not witness the bakery death or the musician leaving. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {finn} did not witness the bakery death or the musician leaving.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "ada",
              "text": "I heard the account: {ada} saw the fine stones in an address-stamped sleeve. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {ada} saw the fine stones in an address-stamped sleeve.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I learned Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair. Chalk explains his cuff mark to me, not missing pages or blade skills.",
              "observation": "I learned Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair.",
              "contradictingDetail": "Chalk explains his cuff mark to me, not missing pages or blade skills."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I checked {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market. I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone.",
              "observation": "I checked {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market.",
              "contradictingDetail": "I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I learned Della saw {jasper} follow Tobias to the market lamp at ten. He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward.",
              "observation": "I learned Della saw {jasper} follow Tobias to the market lamp at ten.",
              "contradictingDetail": "He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward."
            }
          },
          {
            "readAloud": {
              "accuses": "lydia",
              "text": "I heard {lydia} saw Thorne hide receipt 47 during her confirmed school-funding appointment. She couldn't read the name. I see why she questioned family records, not proof she falsified them.",
              "observation": "I heard {lydia} saw Thorne hide receipt 47 during her confirmed school-funding appointment.",
              "contradictingDetail": "She couldn't read the name. I see why she questioned family records, not proof she falsified them."
            }
          }
        ]
      }
    ],
    "finale": {
      "narration": "All seven chapters and the final witness accounts have now been read. Compare the identified blade, the licensed likeness and address, and the duplicate records with the earlier observations. Decide which neighbor accounts for the complete chain, not just one suspicious trace. A reason for revenge can explain a crime without excusing it. Make your final accusation before the investigator announces the solution.",
      "votePrompt": "Who do you accuse based on the evidence heard so far?"
    },
    "solution": {
      "killerId": "xander",
      "explanation": "Xander Hale is Benjamin Barker, formerly Blackwater Row's trusted barber, and he committed all five murders. Thorne's letter and court file, first read in Round 7, establish that the Mayor wanted Barker's wife, framed him, ordered his imprisonment and forced her into his household. Elias's false delivery entry, Ronan's invented confession, Harper's altered household record and Tobias's false night sighting helped destroy Barker's married life. After release, Barker returned as the woodworker Xander Hale. The fine stones in his address-stamped sleeve and Harper's earlier-trade remark established a blade skill without naming it. Nell's direct observation of the chipped ivory razor in Round 5 supplied identifiable ownership; Edith's Round 7 comparison joined that razor, the licensed likeness and the repair invoice to the old identity. Receipt 47 linked the disturbed records; retained duplicates explained the target selection. Marla's repaired flour-marked boot had a documented closing-chore source. Jasper's case and rosin and Lydia's folder and chalk had witnessed work-related sources; their movements raised questions but did not explain the complete identity, weapon and motive chain. No stain alone proved a killing. Barker killed the four accomplices before reaching his final target, the Mayor. This was deliberate revenge, not justice.",
      "revealNarration": "The investigator closes the court file. \"The killer is {xander}. His former name was Benjamin Barker, and his former trade was barber. Nell identified the damaged razor in his hand; Edith matched the license and address to his current work. The earlier victims supplied the false statements that destroyed his former life. Thorne was his final target.\"\n\nThe host may read Barker's final words: \"Once this town knew me as Benjamin Barker. I had a trade, a wife and a home. Thorne wanted what was not his, and four respectable voices made his lie sound like law. When I returned, I called myself Xander Hale and worked in wood. I thought a new name could bury the old one. Instead I carried it through every door. I chose revenge, and I killed them. It did not restore my wife's freedom or the years we lost. Nothing they did makes these murders right.\"\n\nBlackwater Row must now reckon with both the original injustice and the five deaths that followed."
    },
    "masterPreserving": true,
    "conversion": {
      "source": "Committed four-player Blackwater Row revision 3.",
      "changes": [
        {
          "original": "Five discovery chapters and four playable neighbors.",
          "replacement": "Five unchanged discovery sequences with two intervening comparison chapters and a three-player core.",
          "reason": "Seven-round requirement and smallest-edition master. Identity remains in the last discovery chapter; no murders or facts are added."
        },
        {
          "original": "Per-chapter four-player reader handoffs and twenty player responses.",
          "replacement": "Named recorded responses in shared narration and count-specific group order.",
          "reason": "Preserve every witness source and original response while selecting a three-player loop."
        },
        {
          "original": "Solution timing references to Round 4 and Round 5.",
          "replacement": "Corresponding seven-chapter references to Round 5 and Round 7.",
          "reason": "Inserted comparison rounds shift chapter numbers without advancing evidence."
        }
      ],
      "originalResponses": [
        {
          "id": "xander",
          "rounds": [
            {
              "readAloud": {
                "accuses": "marla",
                "text": "I heard Nell saw {marla} leave the bakery's back door at nine with her red-handled brush. Her repaired, flour-packed heel resembles those prints. I still need their timing checked.",
                "observation": "I heard Nell saw {marla} leave the bakery's back door at nine with her red-handled brush.",
                "contradictingDetail": "Her repaired, flour-packed heel resembles those prints. I still need their timing checked."
              }
            },
            {
              "readAloud": {
                "accuses": "jasper",
                "text": "I heard Ada saw {jasper}'s blue-strapped case on Ronan's counter at ten. His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors.",
                "observation": "I heard Ada saw {jasper}'s blue-strapped case on Ronan's counter at ten.",
                "contradictingDetail": "His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors."
              }
            },
            {
              "readAloud": {
                "accuses": "lydia",
                "text": "I heard Owen saw {lydia}'s green folder in Harper's classroom at six, discussing pupil privacy. Its chalk matches the desk height. I worry about access, but Owen left at seven.",
                "observation": "I heard Owen saw {lydia}'s green folder in Harper's classroom at six, discussing pupil privacy.",
                "contradictingDetail": "Its chalk matches the desk height. I worry about access, but Owen left at seven."
              }
            },
            {
              "readAloud": {
                "accuses": "marla",
                "text": "I read {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market. I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone.",
                "observation": "I read {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market.",
                "contradictingDetail": "I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone."
              }
            },
            {
              "readAloud": {
                "accuses": "jasper",
                "text": "I heard {jasper}'s different-name rumor came from Ronan's old-license remark. His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin.",
                "observation": "I heard {jasper}'s different-name rumor came from Ronan's old-license remark.",
                "contradictingDetail": "His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin."
              }
            }
          ]
        },
        {
          "id": "marla",
          "rounds": [
            {
              "readAloud": {
                "accuses": "jasper",
                "text": "I heard Finn saw {jasper} behind the bakery at nine-thirty with his blue-strapped case. A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave.",
                "observation": "I heard Finn saw {jasper} behind the bakery at nine-thirty with his blue-strapped case.",
                "contradictingDetail": "A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave."
              }
            },
            {
              "readAloud": {
                "accuses": "lydia",
                "text": "I heard Ada heard {lydia} warn Ronan about recording families at eight. She touched his book, leaving possible chalk. I can't prove a removed page or a later return.",
                "observation": "I heard Ada heard {lydia} warn Ronan about recording families at eight.",
                "contradictingDetail": "She touched his book, leaving possible chalk. I can't prove a removed page or a later return."
              }
            },
            {
              "readAloud": {
                "accuses": "xander",
                "text": "I heard Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair. Chalk explains his cuff mark to me, not missing pages or blade skills.",
                "observation": "I heard Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair.",
                "contradictingDetail": "Chalk explains his cuff mark to me, not missing pages or blade skills."
              }
            },
            {
              "readAloud": {
                "accuses": "jasper",
                "text": "I heard Della saw {jasper} follow Tobias to the market lamp at ten. He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward.",
                "observation": "I heard Della saw {jasper} follow Tobias to the market lamp at ten.",
                "contradictingDetail": "He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward."
              }
            },
            {
              "readAloud": {
                "accuses": "lydia",
                "text": "I learned {lydia} saw Thorne hide receipt 47 during her confirmed school-funding appointment. She couldn't read the name. I see why she questioned family records, not proof she falsified them.",
                "observation": "I learned {lydia} saw Thorne hide receipt 47 during her confirmed school-funding appointment.",
                "contradictingDetail": "She couldn't read the name. I see why she questioned family records, not proof she falsified them."
              }
            }
          ]
        },
        {
          "id": "jasper",
          "rounds": [
            {
              "readAloud": {
                "accuses": "lydia",
                "text": "I heard Della saw {lydia} argue with Elias that morning, her green lesson folder tucked under her arm. A bread bill held family history. I wonder why he folded that paper.",
                "observation": "I heard Della saw {lydia} argue with Elias that morning, her green lesson folder tucked under her arm.",
                "contradictingDetail": "A bread bill held family history. I wonder why he folded that paper."
              }
            },
            {
              "readAloud": {
                "accuses": "xander",
                "text": "I read {xander}'s shelf invoice; Ada saw fine sharpening stones in his address-stamped sleeve. His repair cloth held amber shellac. I see another possible smear source, not proof he touched that mug.",
                "observation": "I read {xander}'s shelf invoice; Ada saw fine sharpening stones in his address-stamped sleeve.",
                "contradictingDetail": "His repair cloth held amber shellac. I see another possible smear source, not proof he touched that mug."
              }
            },
            {
              "readAloud": {
                "accuses": "marla",
                "text": "I read {marla}'s signed six-o'clock bread delivery to Harper's classroom door. Owen saw her wait by the open records drawer. I see access, but not a fatal-morning visit.",
                "observation": "I read {marla}'s signed six-o'clock bread delivery to Harper's classroom door.",
                "contradictingDetail": "Owen saw her wait by the open records drawer. I see access, but not a fatal-morning visit."
              }
            },
            {
              "readAloud": {
                "accuses": "lydia",
                "text": "I read {lydia}'s warning to Tobias: children's family affairs don't belong in street notes. Her weekly lesson meetings explain contact to me, not an overnight alibi or receipt 47's torn page.",
                "observation": "I read {lydia}'s warning to Tobias: children's family affairs don't belong in street notes.",
                "contradictingDetail": "Her weekly lesson meetings explain contact to me, not an overnight alibi or receipt 47's torn page."
              }
            },
            {
              "readAloud": {
                "accuses": "xander",
                "text": "I heard Edith match {xander}'s licensed likeness and workshop address: Benjamin Barker, barber. His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse.",
                "observation": "I heard Edith match {xander}'s licensed likeness and workshop address: Benjamin Barker, barber.",
                "contradictingDetail": "His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse."
              }
            }
          ]
        },
        {
          "id": "lydia",
          "rounds": [
            {
              "readAloud": {
                "accuses": "xander",
                "text": "I heard Della saw Elias refuse to enter {xander}'s workshop over an old receipt. He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon.",
                "observation": "I heard Della saw Elias refuse to enter {xander}'s workshop over an old receipt.",
                "contradictingDetail": "He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon."
              }
            },
            {
              "readAloud": {
                "accuses": "marla",
                "text": "I heard Della heard {marla} dispute Ronan's flour bill at seven. She showed a receipt and left toward the bakery. I can't confirm payment or a later return.",
                "observation": "I heard Della heard {marla} dispute Ronan's flour bill at seven.",
                "contradictingDetail": "She showed a receipt and left toward the bakery. I can't confirm payment or a later return."
              }
            },
            {
              "readAloud": {
                "accuses": "jasper",
                "text": "I read {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak. I see how marks transfer, but Owen didn't watch the yard entrance overnight.",
                "observation": "I read {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak.",
                "contradictingDetail": "I see how marks transfer, but Owen didn't watch the yard entrance overnight."
              }
            },
            {
              "readAloud": {
                "accuses": "xander",
                "text": "I heard Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge. It went into his stamped sleeve. I worry about those precise cuts, not a confession.",
                "observation": "I heard Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge.",
                "contradictingDetail": "It went into his stamped sleeve. I worry about those precise cuts, not a confession."
              }
            },
            {
              "readAloud": {
                "accuses": "marla",
                "text": "I heard Edith confirm {marla}'s childhood delivery during Thorne's old workshop-home visit. She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot.",
                "observation": "I heard Edith confirm {marla}'s childhood delivery during Thorne's old workshop-home visit.",
                "contradictingDetail": "She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot."
              }
            }
          ]
        }
      ]
    }
  },
  "10": {
    "schemaVersion": 2,
    "fixedPlayerCount": 10,
    "discloseKiller": false,
    "clueRouting": "rotating",
    "edition": {
      "family": "blackwater-scalable",
      "id": "blackwater-scalable-10-players",
      "playerCount": 10,
      "revision": 1
    },
    "title": "The Barber of Blackwater Row",
    "atmosphere": "victorian",
    "setting": "Blackwater Row, a riverside town of workshops, narrow lanes and gaslit streets in the late nineteenth century.",
    "intro": "Evening settles over Blackwater Row. Three neighbors help the town investigator compare the supplied accounts: Xander Hale, the woodworker; Marla Quinn, the baker's assistant; and Jasper Crowe, the tavern musician. The host reads every recorded witness account before the players respond. Other named people remain in the evidence even when they are not playable. Discuss only the chapter just heard; nobody invents a history, witnesses a new discovery or improvises a private part.",
    "hiddenThread": "Receipt 47 recurs in every victim's disturbed records and finally names the Mayor's old imprisonment order against Benjamin Barker.",
    "coverageRepeatNote": "The trio covers all six directed pairs in the first two rounds. Later repeats add released evidence or explicitly correct an unsupported earlier inference. Each supplemental reader targets every other selected character before repeating, never in consecutive rounds. Separate singleton readings preserve the master loop and evidence timing.",
    "specialMechanics": [
      "Receipt 47 ledger: each murder surfaces another record indexed under receipt 47 (delivery log, tavern scrap, student-record index, night-route page). Compare them across rounds; the Mayor's signed order in Round 7 finally connects the series to the old case."
    ],
    "victim": {
      "name": "Elias Brim",
      "description": "The town baker, known for dependable bread deliveries and careful records."
    },
    "rounds": [
      {
        "title": "Round 1 - The Baker's Murder",
        "narration": "At dawn, delivery porter Finn Moss finds Elias Brim behind his bakery with his throat slashed. The investigator reports one clean, precise cut; the death happened off-screen. Elias supplied nearly every doorstep and recorded deliveries and closing chores in separate books. Finn calls night watchwoman Nell Reed before anyone enters the yard. She records a chain of flour prints from the back door to the wet cobbles. Each right print has a crescent-shaped gap at the heel; the cobbles preserve nothing beyond it. A page is torn from an older delivery log. Its surviving edge carries the date and part of receipt 47, but not a customer name or the purpose of the entry. The closing-duty sheet is intact and is kept for later comparison. These are the findings at this scene, not an identification of the killer. The investigator has collected four separate accounts about the neighbors.  Hear all four before discussing which details establish access and which merely raise suspicion.\n\nThe investigator reads the supporting witness accounts before calling on the selected readers:\n\nWitness background for Marla Quinn: Nell Reed saw Marla Quinn leave the bakery back door at nine, carrying her red-handled scrubbing brush. Nell recognized the brass buckle and crescent-shaped repair in the right heel of her work boots because cobbler Della March had shown her that repair at collection yesterday. Flour was packed into the repaired heel. The shape resembles the yard prints recorded this morning. This ties the boots to bakery work and the doorway, but does not date when each print was made. The closing-duty sheet has not yet been checked against the sighting.\n\nWitness background for Jasper Crowe: Finn Moss saw Jasper Crowe waiting behind the bakery at half past nine, with a blue-strapped instrument case propped against the wall. Finn recognized the musician from the tavern and the case from carrying it after last week's performance. A pale streak ran across its lower corner where it touched a flour sack outside the door. Finn heard him ask Elias for a promised parcel, but did not see a parcel handed over or hear what it contained. Finn left for the delivery cart; he did not witness the death or the musician's departure.\n\nWitness background for Lydia Vance: Della March saw Lydia Vance arguing with Elias at the bakery front counter that morning. She recognized the teacher from collecting her granddaughter from school and saw the same green lesson folder under her arm. Della heard the teacher ask why a bread bill included a household's personal history. Elias folded a paper and refused to answer. The teacher left a chalky thumb mark on the counter when she leaned forward. Della identifies the person and the topic, but heard no threat and never saw the contents of the folded paper.\n\nWitness background for Xander Hale: Della March delivered a wooden chair to Xander Hale's workshop last week and saw Elias at the open door. She recognized both men from their regular work at her market stall. Elias refused to enter and said, \"I will not bring that old receipt here again.\" The woodworker stopped sanding, gripped the chair rail and asked which book Elias meant. Della saw fresh amber shellac on his apron beside the repair cloth, but no weapon. She can identify the reaction and the receipt dispute; she cannot identify the old transaction or turn that reaction into proof of murder.\n\nThe host reads the original neighbors' recorded responses:\nXander Hale's recorded response: \"I heard Nell saw Marla Quinn leave the bakery's back door at nine with her red-handled brush. Her repaired, flour-packed heel resembles those prints. I still need their timing checked.\"\nMarla Quinn's recorded response: \"I heard Finn saw Jasper Crowe behind the bakery at nine-thirty with his blue-strapped case. A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave.\"\nJasper Crowe's recorded response: \"I heard Della saw Lydia Vance argue with Elias that morning, her green lesson folder tucked under her arm. A bread bill held family history. I wonder why he folded that paper.\"\nLydia Vance's recorded response: \"I heard Della saw Elias refuse to enter Xander Hale's workshop over an old receipt. He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon.\"\n\nThe supplied witness accounts support these comparisons:\nNell Reed recorded flour prints with a crescent gap in the right heel.\nDella March recognized the repaired boot from its collection yesterday.\nFinn Moss found Elias and called Nell before anyone entered the yard.\nAda Bell has not supplied a tavern account at this stage.\nOwen Bell has not supplied a classroom account at this stage.\nEdith Shaw has not supplied an office account at this stage.\nTown Investigator reported one precise cut at the bakery.\nDella recognized Lydia through collecting Della's Granddaughter from school.",
        "publicText": "Elias Brim: throat slashed with one precise cut. Finn Moss found the body; Nell Reed recorded flour prints with a crescent gap in the right heel. An old delivery-log page is torn; only receipt 47 survives at its edge. The closing-duty sheet is intact.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "At dawn, delivery porter Finn Moss finds Elias Brim behind his bakery with his throat slashed.",
          "The investigator reports one clean, precise cut; the death happened off-screen.",
          "Elias supplied nearly every doorstep and recorded deliveries and closing chores in separate books."
        ],
        "readingGroups": [
          [
            "xander",
            "marla",
            "jasper"
          ],
          [
            "lydia"
          ],
          [
            "nell"
          ],
          [
            "della"
          ],
          [
            "finn"
          ],
          [
            "ada"
          ],
          [
            "owen"
          ],
          [
            "edith"
          ]
        ],
        "chain": [
          "xander",
          "marla",
          "jasper",
          "lydia",
          "nell",
          "della",
          "finn",
          "ada",
          "owen",
          "edith"
        ],
        "coverageRepeat": false
      },
      {
        "title": "Round 2 - The Barkeep's Murder",
        "narration": "The next morning, cleaner Ada Bell finds Ronan Pike slumped over his tavern counter with his throat slashed. The investigator records the same precise cut as at the bakery. Ronan kept accounts of debts and stayed late for private appointments. Ada does not touch the mug beside him; Nell Reed records that it has been wiped and has no usable fingerprints. A thin amber smear remains beneath its handle. No owner has been established for the mug or the smear. Beneath Ronan's account book lies a scrap bearing receipt 47 and four lines of dates. No names or explanation survive on the scrap. The matching number links two sets of records, but does not identify their subject. Ronan's service tally and appointment book are preserved separately so that the last drink served will not be confused with the last visitor admitted. Four witness accounts are ready.  Listen for who saw an object, how they identified its owner and whether their timing actually reaches the death.\n\nThe investigator reads the supporting witness accounts before calling on the selected readers:\n\nWitness background for Jasper Crowe: Ada Bell saw Jasper Crowe put his instrument case on Ronan's counter at ten and leave after the last public drink was served. She recognized the case by its repaired blue strap, which she had sewn herself. He uses amber rosin on his bow; Ada collected a flake from the spot where the case rested. Its color resembles the smear beneath the wiped mug, but color alone cannot establish that they are the same material. Ronan locked the public door afterward; Ada did not watch the side entrance or the later appointments.\n\nWitness background for Lydia Vance: Ada Bell heard Lydia Vance tell Ronan at eight, \"Those are dangerous notes; people did not give you permission to record their families.\" Ada recognized the green lesson folder under the teacher's arm from her school-cleaning rounds. The teacher tapped Ronan's account book, leaving a white powder trace on its dark cover. Ada collected it as a possible chalk transfer, not a laboratory identification. The warning concerns records, but Ada saw no page removed. The teacher walked out through the public door; Ada could not observe who returned later.\n\nWitness background for Xander Hale: Ronan's repair invoice records Xander Hale replacing the tavern shelf last week. Ada Bell identified him from the signed invoice and saw him open a leather tool sleeve stamped with the same workshop address. Inside were sharpening stones Ronan called \"too fine for woodworking\": one was much narrower and smoother than the broad stone used on the shelf chisel. Ada saw him wipe the sleeve with an amber shellac-stained cloth from his repair kit. That establishes ownership of the stones and a second possible source of amber residue; it does not prove who handled the wiped mug on the night of the murder.\n\nWitness background for Marla Quinn: Della March heard Marla Quinn dispute an unpaid flour bill with Ronan outside the tavern at seven. She recognized the baker's assistant by the stamped delivery basket she was carrying. Ronan held a bill with a torn lower corner; the assistant produced a coin receipt, but Della was too far away to compare its amount. She saw the assistant leave with the basket toward the bakery. The argument supplies a specific grievance and an observed departure, not proof of payment or a witnessed return to the counter where Ronan died.\n\nThe host reads the original neighbors' recorded responses:\nXander Hale's recorded response: \"I heard Ada saw Jasper Crowe's blue-strapped case on Ronan's counter at ten. His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors.\"\nMarla Quinn's recorded response: \"I heard Ada heard Lydia Vance warn Ronan about recording families at eight. She touched his book, leaving possible chalk. I can't prove a removed page or a later return.\"\nJasper Crowe's recorded response: \"I read Xander Hale's shelf invoice; Ada saw fine sharpening stones in his address-stamped sleeve. His repair cloth held amber shellac. I see another possible smear source, not proof he touched that mug.\"\nLydia Vance's recorded response: \"I heard Della heard Marla Quinn dispute Ronan's flour bill at seven. She showed a receipt and left toward the bakery. I can't confirm payment or a later return.\"\n\nThe supplied witness accounts support these comparisons:\nNell Reed recorded a wiped mug without usable fingerprints.\nDella March heard Marla dispute the flour bill and leave toward the bakery.\nFinn Moss did not witness the bakery death or the musician leaving.\nAda Bell found Ronan and left the mug untouched.\nOwen Bell has not supplied a classroom account at this stage.\nEdith Shaw has not supplied an office account at this stage.\nTown Investigator reported the same precise cut at the tavern.\nDella's school collection of Della's Granddaughter explains her recognition of Lydia.",
        "publicText": "Ronan Pike: throat slashed with the same precise cut. Ada Bell found him. A wiped mug has no usable fingerprints and an unidentified amber smear beneath its handle. A dated scrap bears receipt 47 but no names. Service and appointment records are preserved.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "The next morning, cleaner Ada Bell finds Ronan Pike slumped over his tavern counter with his throat slashed.",
          "The investigator records the same precise cut as at the bakery.",
          "Ronan kept accounts of debts and stayed late for private appointments."
        ],
        "readingGroups": [
          [
            "xander",
            "jasper",
            "marla"
          ],
          [
            "lydia"
          ],
          [
            "nell"
          ],
          [
            "della"
          ],
          [
            "finn"
          ],
          [
            "ada"
          ],
          [
            "owen"
          ],
          [
            "edith"
          ]
        ],
        "chain": [
          "xander",
          "jasper",
          "marla",
          "lydia",
          "nell",
          "della",
          "finn",
          "ada",
          "owen",
          "edith"
        ],
        "coverageRepeat": false
      },
      {
        "title": "Round 3 - The Schoolteacher's Murder",
        "narration": "Before sunrise, caretaker Owen Bell finds senior teacher Harper Wren in her classroom with her throat slashed, the same precise cut again. Harper taught most of the town's children and kept family records as carefully as lesson plans. Owen locks the room and fetches Nell Reed. She records a broad chalk smear across the desk and a narrow drag line through it, running from the student-record book toward its open drawer. A page is missing from that book. Its remaining index cites receipt 47; a margin note says, \"Copy kept with the original order.\" Neither the order's owner nor its location is recorded here. Owen also hands over the fundraiser attendance sheet and Harper's lesson diary, both intact. Three disturbed records now share a number. That is a link worth following, not yet an explanation.  Compare observed visits with the traces on the desk, and keep the identity of any missing document separate from guesses about it.\n\nThe investigator reads the supporting witness accounts before calling on the selected readers:\n\nWitness background for Lydia Vance: Owen Bell saw Lydia Vance enter Harper's classroom at six carrying her green lesson folder. He recognized her name written inside its cover when she left it beside the register. A broad chalk mark on the folder's edge matches the height of the smeared desk; Owen had watched her lean it there while discussing pupil privacy. Her warning was, \"A family record should not become a weapon.\" This explains regular access and a possible source of chalk transfer, but Owen left at seven and cannot account for the classroom overnight.\n\nWitness background for Xander Hale: Owen Bell recalls Harper pointing out Xander Hale's narrow whetstone while the woodworker repaired her drawer rail last Tuesday. Owen saw the stone in a leather sleeve stamped with the workshop's address; he checked that address on the repair invoice. Harper said he \"used to work with blades in another trade\" but did not name it. Owen also saw fresh blue chalk on the woodworker's cuff after measuring the rail with Harper's chalk line. That gives an ordinary source for the cuff mark, not an explanation of the missing page or the earlier blade skills.\n\nWitness background for Marla Quinn: Owen Bell signed for Marla Quinn's six-o'clock bread delivery to Harper on the morning before the death. He recognized the baker's stamped basket and the repaired brass-buckled boots described in Round 1. The delivery docket, signed by Harper, specifies the classroom door rather than the school kitchen. Owen saw the assistant wait while Harper opened the student-record drawer to find payment. This gives a witnessed reason for knowing Harper's schedule and seeing the drawer. Neither the flour on the boots nor that access proves a visit before sunrise on the fatal morning.\n\nWitness background for Jasper Crowe: Owen Bell checked Jasper Crowe's name on the fundraiser attendance sheet at nine the previous evening. He recognized the blue-strapped case and watched the musician leave it beside Harper's desk while stacking chairs. White chalk marked the case corner where it rubbed the desktop, covering part of the pale bakery streak described in Round 1. Owen identifies a source for the transfer and a reason for being in the room. He locked the public school door after the event, but did not remain to watch the classroom's separate yard entrance overnight.\n\nThe host reads the original neighbors' recorded responses:\nXander Hale's recorded response: \"I heard Owen saw Lydia Vance's green folder in Harper's classroom at six, discussing pupil privacy. Its chalk matches the desk height. I worry about access, but Owen left at seven.\"\nMarla Quinn's recorded response: \"I heard Harper said Xander Hale once worked with blades; Owen saw his narrow whetstone during her drawer repair. Chalk explains his cuff mark to me, not missing pages or blade skills.\"\nJasper Crowe's recorded response: \"I read Marla Quinn's signed six-o'clock bread delivery to Harper's classroom door. Owen saw her wait by the open records drawer. I see access, but not a fatal-morning visit.\"\nLydia Vance's recorded response: \"I read Jasper Crowe's nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak. I see how marks transfer, but Owen didn't watch the yard entrance overnight.\"\n\nThe supplied witness accounts support these comparisons:\nNell Reed recorded a chalk smear and narrow drag line through it.\nDella March identified Lydia and the topic of the bakery argument.\nFinn Moss heard a promised parcel requested but saw no handover.\nAda Bell saw the fine stones in an address-stamped sleeve.\nOwen Bell found Harper, locked the classroom and fetched Nell.\nEdith Shaw has not supplied an office account at this stage.\nTown Investigator connected three disturbed records by receipt 47.\nDella's collection of Della's Granddaughter identifies a teacher, not a threat.",
        "publicText": "Harper Wren: throat slashed with the same precise cut. Owen Bell found her; Nell Reed recorded chalk and a drag line beside a disturbed student-record book. Its index cites receipt 47 and a copy kept with an unnamed original order. Attendance and lesson records are intact.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "Before sunrise, caretaker Owen Bell finds senior teacher Harper Wren in her classroom with her throat slashed, the same precise cut again.",
          "Harper taught most of the town's children and kept family records as carefully as lesson plans.",
          "Owen locks the room and fetches Nell Reed."
        ],
        "readingGroups": [
          [
            "xander",
            "marla",
            "jasper"
          ],
          [
            "lydia"
          ],
          [
            "nell"
          ],
          [
            "della"
          ],
          [
            "finn"
          ],
          [
            "ada"
          ],
          [
            "owen"
          ],
          [
            "edith"
          ]
        ],
        "chain": [
          "xander",
          "marla",
          "jasper",
          "lydia",
          "nell",
          "della",
          "finn",
          "ada",
          "owen",
          "edith"
        ],
        "coverageRepeat": true
      },
      {
        "title": "Round 4 - Visits and Transferred Marks",
        "narration": "Compare only the findings already read at the bakery, tavern and school. An evening delivery is not a fatal-morning visit; flour, rosin, shellac and chalk have witnessed work-related sources. Receipt 47 links disturbed records but does not yet identify their subject. Correct an accusation that mistakes a work trace or access for a witnessed killing. No new death, name, trade or weapon identification is introduced.",
        "publicText": "Correct earlier inferences using only already released evidence.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "Compare released work traces with the recorded visits.",
          "Correct unsupported accusations without a new discovery."
        ],
        "readingGroups": [
          [
            "xander",
            "jasper",
            "marla"
          ],
          [
            "lydia"
          ],
          [
            "nell"
          ],
          [
            "della"
          ],
          [
            "finn"
          ],
          [
            "ada"
          ],
          [
            "owen"
          ],
          [
            "edith"
          ]
        ],
        "chain": [
          "xander",
          "jasper",
          "marla",
          "lydia",
          "nell",
          "della",
          "finn",
          "ada",
          "owen",
          "edith"
        ],
        "coverageRepeat": true
      },
      {
        "title": "Round 5 - The Lamplighter's Murder",
        "narration": "Before the morning market opens, Nell Reed finds Tobias Wick beside an extinguished streetlamp with his throat slashed in the same precise manner. Tobias walked every lane at night and kept route notes about what he saw. Lamp oil has spilled in a perfect circle around the lamp base. Nell records its position before moving the fallen oil flask; the shape of the spill alone cannot identify who was there. A page is torn from Tobias's old route notebook. The surviving index bears receipt 47 and the instruction, \"Retain duplicate with original order.\" Nell gathers the bakery closing-duty sheet, Ronan's appointment book and Harper's lesson diary for comparison with the earlier witness accounts. Their entries can explain a visit or correct a timing assumption, but they are not blanket alibis. The subject of the old records is still missing.  Let each account introduce its own new finding. Then compare the four scenes and ask which traces are ordinary work and which remain unexplained.\n\nThe investigator reads the supporting witness accounts before calling on the selected readers:\n\nWitness background for Marla Quinn: Nell Reed compares Marla Quinn's flour-marked repaired boot from Round 1 with the bakery closing-duty sheet. Elias initialed her nine-o'clock task: scrub the rear threshold, then deliver the waste pail to the market. The entry explains why the crescent heel and flour appeared at the doorway; it is not evidence that the print was made during the killing. Market seller Della March also records that the assistant reported Tobias arguing with an unidentified figure beside the oil stall last night. Della heard the report, not the argument, so she cannot identify that figure.\n\nWitness background for Jasper Crowe: Della March saw Jasper Crowe follow Tobias from the tavern to the market lamp at ten last night. She identified the musician by his blue-strapped case and by the tune he had just played at her stall. Tobias asked him to hold the oil flask while adjusting the wick; Della saw a drop spill onto his right sleeve. The stain therefore has an observed source, not merely an assumed link to lamplighting. Della closed her shutter before Tobias resumed his route. The musician's presence and oil stain establish contact, but not where either man went afterward.\n\nWitness background for Lydia Vance: Nell Reed finds Lydia Vance's warning to Tobias entered in his intact route book: \"Children's family affairs do not belong in street notes.\" The entry describes her green folder and the school gate, where Owen Bell confirms he saw them speak. Nell compares it with Harper's lesson diary, which schedules their weekly meetings to prepare lessons and handle family requests. These sources explain the teacher's meetings and concern about records without supplying an overnight alibi. They do not explain why the older page indexed under receipt 47 was torn out.\n\nWitness background for Xander Hale: Nell Reed saw Xander Hale beneath the workshop lamp yesterday evening, holding a straight razor rather than a woodworking chisel. She recognized him from the shelf-repair invoice she had collected at the tavern and spoke to him face to face. The open blade reflected the lamp; the ivory handle had a triangular chip beside its hinge. He closed it and put it into the address-stamped leather sleeve whose fine stones Ada Bell described in Round 2. Nell can identify the owner, object and distinctive damage, but she did not see an attack. The blade should be compared with the repeated precise cuts, not treated as a confession.\n\nThe host reads the original neighbors' recorded responses:\nXander Hale's recorded response: \"I read Marla Quinn's nine-o'clock closing duty: scrub the rear threshold, then take waste to market. I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone.\"\nMarla Quinn's recorded response: \"I heard Della saw Jasper Crowe follow Tobias to the market lamp at ten. He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward.\"\nJasper Crowe's recorded response: \"I read Lydia Vance's warning to Tobias: children's family affairs don't belong in street notes. Her weekly lesson meetings explain contact to me, not an overnight alibi or receipt 47's torn page.\"\nLydia Vance's recorded response: \"I heard Nell saw Xander Hale's straight razor: ivory handle, triangular chip beside its hinge. It went into his stamped sleeve. I worry about those precise cuts, not a confession.\"\n\nThe supplied witness accounts support these comparisons:\nNell Reed saw the chipped ivory razor enter the stamped sleeve.\nDella March saw Jasper holding the flask before oil spilled on his sleeve.\nFinn Moss left for the delivery cart without witnessing the bakery death.\nAda Bell saw the blue-strapped case on Ronan's counter at ten.\nOwen Bell left at seven without watching the separate yard entrance overnight.\nEdith Shaw has not supplied an office account at this stage.\nTown Investigator preserved the earlier work records for timing comparisons.\nDella's school collection of Della's Granddaughter does not identify a murderer.",
        "publicText": "Tobias Wick: throat slashed with the same precise cut. Nell Reed found him beside an extinguished lamp and a circle of spilled oil. A torn night-route page is indexed under receipt 47. Earlier work and appointment records are ready for comparison, not complete alibis.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "Before the morning market opens, Nell Reed finds Tobias Wick beside an extinguished streetlamp with his throat slashed in the same precise manner.",
          "Tobias walked every lane at night and kept route notes about what he saw.",
          "Lamp oil has spilled in a perfect circle around the lamp base."
        ],
        "readingGroups": [
          [
            "xander",
            "marla",
            "jasper"
          ],
          [
            "lydia"
          ],
          [
            "nell"
          ],
          [
            "della"
          ],
          [
            "finn"
          ],
          [
            "ada"
          ],
          [
            "owen"
          ],
          [
            "edith"
          ]
        ],
        "chain": [
          "xander",
          "marla",
          "jasper",
          "lydia",
          "nell",
          "della",
          "finn",
          "ada",
          "owen",
          "edith"
        ],
        "coverageRepeat": true
      },
      {
        "title": "Round 6 - Work Traces and the Identified Tool",
        "narration": "Compare the already released closing-duty sheet, private-appointment records, school visits and Nell's chipped-razor sighting. A work record can explain a trace without supplying an overnight alibi. The identified razor is more specific than an unexplained color or stain, but its sighting is not a confession. Correct earlier accusations based only on flour, chalk or spilled oil. No new death or old identity is introduced.",
        "publicText": "Correct earlier inferences using only already released evidence.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "Compare released work traces with the recorded visits.",
          "Correct unsupported accusations without a new discovery."
        ],
        "readingGroups": [
          [
            "xander",
            "jasper",
            "marla"
          ],
          [
            "lydia"
          ],
          [
            "nell"
          ],
          [
            "della"
          ],
          [
            "finn"
          ],
          [
            "ada"
          ],
          [
            "owen"
          ],
          [
            "edith"
          ]
        ],
        "chain": [
          "xander",
          "jasper",
          "marla",
          "lydia",
          "nell",
          "della",
          "finn",
          "ada",
          "owen",
          "edith"
        ],
        "coverageRepeat": true
      },
      {
        "title": "Round 7 - The Mayor's Murder",
        "narration": "Office clerk Edith Shaw finds Mayor Aldric Thorne in his office chair with his throat slashed, the same precise cut. A polished straight razor lies on the desk, its ivory handle chipped beside the hinge. Edith calls Nell Reed and identifies the locked cabinet from which the papers on the desk came; its numbered index and broken wax seal allow the investigator to trace their source. A single old court document, signed by Thorne, orders the imprisonment of BENJAMIN BARKER and bears receipt 47. This is the first time that name enters the investigation. With it are the duplicate records referred to in Harper's index and Tobias's notebook. The investigator reads them aloud: Elias signed a false delivery entry placing Barker at a theft; Ronan signed a fabricated account of a confession; Harper altered a household record to support the charge; Tobias supplied a false night-route sighting. A retained letter from Thorne orders the changes, admits that he wanted Barker's wife and describes using imprisonment to separate them. The household record states that she was taken into Thorne's household under coercion, not by free choice. Barker's licensed occupation is barber. A likeness, address and tool inventory are attached, but the investigator leaves their identification to the witnesses whose accounts you are about to hear. These documents establish the original injustice and the four victims' roles. They do not announce which current neighbor committed the murders.  Hear every account before the final vote.\n\nThe investigator reads the supporting witness accounts before calling on the selected readers:\n\nWitness background for Jasper Crowe: Edith Shaw asks Jasper Crowe to explain a rumor he heard at the tavern about the woodworker once using a different name. He identifies its source as Ronan's remark about an old license, not personal knowledge of the imprisonment. Edith compares the signature on his ten-o'clock drink receipt with the appointment book preserved in Round 2; it confirms his earlier visit, while a separate eleven-o'clock entry admits a private visitor. His rosin flake explains a substance on the counter, but neither the rumor nor the flake identifies that later visitor or makes him a signer of the false statements in the court file.\n\nWitness background for Lydia Vance: Edith Shaw compares Lydia Vance's account of seeing the Mayor hide an old paper with the cabinet index recovered today. The teacher dates the sighting to a school-funding appointment entered in Edith's diary; Edith confirms she admitted her for that appointment and saw Thorne close the folder. The teacher could read receipt 47, but not the name hidden beneath his hand. This explains why the teacher questioned intrusive family records. Her chalk-marked folder and weekly lesson meetings establish access to school papers, not a signature on the falsified statements read from the court file.\n\nWitness background for Xander Hale: Edith Shaw identifies the court file's licensed likeness as Xander Hale; she compares the workshop address printed beside it with the signed shelf-repair invoice preserved in Round 2. The licensed name is Benjamin Barker. The barber's tool inventory describes an ivory razor with a chip beside the hinge, matching the blade Nell Reed saw in his hand in Round 4 and the one now on Thorne's desk. The fine stones and Harper's earlier-trade remark fit the documented occupation. The duplicate records identify the four people who helped Thorne destroy his former life. This joins identity, blade ownership and motive; the room must still decide its final accusation.\n\nWitness background for Marla Quinn: Edith Shaw checks Marla Quinn's account of an old visit by Thorne to the workshop home. The assistant remembers delivering a baker's basket there as a child; the retained delivery copy records the date and the house number. Edith compares those details with Thorne's appointment diary and confirms the visit. The account links a remembered visit to a documented place, but the assistant did not hear the conversation. Her repaired flour-marked boot still fits the closing chore established in Round 4, not a proven killing. Neither her childhood observation nor her recent bread delivery makes her one of the signers identified in the old file.\n\nThe host reads the original neighbors' recorded responses:\nXander Hale's recorded response: \"I heard Jasper Crowe's different-name rumor came from Ronan's old-license remark. His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin.\"\nMarla Quinn's recorded response: \"I learned Lydia Vance saw Thorne hide receipt 47 during her confirmed school-funding appointment. She couldn't read the name. I see why she questioned family records, not proof she falsified them.\"\nJasper Crowe's recorded response: \"I heard Edith match Xander Hale's licensed likeness and workshop address: Benjamin Barker, barber. His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse.\"\nLydia Vance's recorded response: \"I heard Edith confirm Marla Quinn's childhood delivery during Thorne's old workshop-home visit. She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot.\"\n\nThe supplied witness accounts support these comparisons:\nNell Reed identified the damaged razor in the earlier sighting.\nDella March's boot identification established work access, not print timing.\nFinn Moss's case account established an evening visit, not a witnessed murder.\nAda Bell's account left later private visitors possible.\nOwen Bell's accounts did not establish an overnight alibi.\nEdith Shaw matched the licensed likeness and address to Xander.\nTown Investigator read the retained duplicate records and Thorne's letter.\nDella's identification through Della's Granddaughter does not implicate Lydia in the old falsification.",
        "publicText": "Mayor Aldric Thorne: throat slashed; a polished razor with a chipped ivory handle on his desk. Edith Shaw identifies the cabinet and record index. Thorne's signed imprisonment order names Benjamin Barker under receipt 47. Duplicate records and his letter expose the four victims' false statements and his coercion. Witness identification follows in the player readings.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "Office clerk Edith Shaw finds Mayor Aldric Thorne in his office chair with his throat slashed, the same precise cut.",
          "A polished straight razor lies on the desk, its ivory handle chipped beside the hinge.",
          "Edith calls Nell Reed and identifies the locked cabinet from which the papers on the desk came; its numbered index and broken wax seal allow the investigator to trace their source."
        ],
        "readingGroups": [
          [
            "xander",
            "marla",
            "jasper"
          ],
          [
            "lydia"
          ],
          [
            "nell"
          ],
          [
            "della"
          ],
          [
            "finn"
          ],
          [
            "ada"
          ],
          [
            "owen"
          ],
          [
            "edith"
          ]
        ],
        "chain": [
          "xander",
          "marla",
          "jasper",
          "lydia",
          "nell",
          "della",
          "finn",
          "ada",
          "owen",
          "edith"
        ],
        "coverageRepeat": true
      }
    ],
    "characters": [
      {
        "id": "xander",
        "name": "Xander Hale",
        "role": "Woodworker",
        "relationship": "A neighbor asked by the town investigator to help compare witness accounts of the Blackwater Row murders.",
        "tieIn": "A quiet craftsperson who repairs furniture and makes wooden fittings in a workshop off the market lane.",
        "optional": false,
        "ghost": null,
        "guest": "",
        "guestNote": "",
        "publicBlurb": "A quiet craftsperson who repairs furniture and makes wooden fittings in a workshop off the market lane.",
        "rounds": [
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I heard Nell saw {marla} leave the bakery's back door at nine with her red-handled brush. Her repaired, flour-packed heel resembles those prints. I still need their timing checked.",
              "observation": "I heard Nell saw {marla} leave the bakery's back door at nine with her red-handled brush.",
              "contradictingDetail": "Her repaired, flour-packed heel resembles those prints. I still need their timing checked."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I heard Ada saw {jasper}'s blue-strapped case on Ronan's counter at ten. His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors.",
              "observation": "I heard Ada saw {jasper}'s blue-strapped case on Ronan's counter at ten.",
              "contradictingDetail": "His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I read {marla}'s signed six-o'clock bread delivery to Harper's classroom door. Owen saw her wait by the open records drawer. I see access, but not a fatal-morning visit.",
              "observation": "I read {marla}'s signed six-o'clock bread delivery to Harper's classroom door.",
              "contradictingDetail": "Owen saw her wait by the open records drawer. I see access, but not a fatal-morning visit."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I heard {jasper}'s case rubbed the chalky desk over its flour streak. I must distinguish transferred work marks from evidence that he removed the student-record page.",
              "observation": "I heard {jasper}'s case rubbed the chalky desk over its flour streak.",
              "contradictingDetail": "I must distinguish transferred work marks from evidence that he removed the student-record page."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I read {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market. I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone.",
              "observation": "I read {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market.",
              "contradictingDetail": "I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I read {jasper}'s visit to the lamp in Della's account. I must not treat spilled oil on his sleeve as proof of a precise cut or an account of his later movements.",
              "observation": "I read {jasper}'s visit to the lamp in Della's account.",
              "contradictingDetail": "I must not treat spilled oil on his sleeve as proof of a precise cut or an account of his later movements."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I heard Edith confirm {marla}'s childhood delivery during Thorne's old workshop-home visit. She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot.",
              "observation": "I heard Edith confirm {marla}'s childhood delivery during Thorne's old workshop-home visit.",
              "contradictingDetail": "She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot."
            }
          }
        ]
      },
      {
        "id": "marla",
        "name": "Marla Quinn",
        "role": "Baker's assistant",
        "relationship": "Assistant to the first victim, the baker Elias Brim; asked to help compare witness accounts.",
        "tieIn": "Elias Brim's assistant, responsible for bread deliveries and the evening cleanup. A familiar face at doorsteps across town.",
        "optional": false,
        "ghost": null,
        "guest": "",
        "guestNote": "",
        "publicBlurb": "Elias Brim's assistant, responsible for bread deliveries and the evening cleanup. A familiar face at doorsteps across town.",
        "rounds": [
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I heard Finn saw {jasper} behind the bakery at nine-thirty with his blue-strapped case. A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave.",
              "observation": "I heard Finn saw {jasper} behind the bakery at nine-thirty with his blue-strapped case.",
              "contradictingDetail": "A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I read {xander}'s shelf invoice; Ada saw fine sharpening stones in his address-stamped sleeve. His repair cloth held amber shellac. I see another possible smear source, not proof he touched that mug.",
              "observation": "I read {xander}'s shelf invoice; Ada saw fine sharpening stones in his address-stamped sleeve.",
              "contradictingDetail": "His repair cloth held amber shellac. I see another possible smear source, not proof he touched that mug."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I read {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak. I see how marks transfer, but Owen didn't watch the yard entrance overnight.",
              "observation": "I read {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak.",
              "contradictingDetail": "I see how marks transfer, but Owen didn't watch the yard entrance overnight."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard {xander}'s drawer repair explained chalk on his cuff. I must not mistake a work mark for an explanation of the missing pages or his earlier blade skills.",
              "observation": "I heard {xander}'s drawer repair explained chalk on his cuff.",
              "contradictingDetail": "I must not mistake a work mark for an explanation of the missing pages or his earlier blade skills."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I heard Della saw {jasper} follow Tobias to the market lamp at ten. He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward.",
              "observation": "I heard Della saw {jasper} follow Tobias to the market lamp at ten.",
              "contradictingDetail": "He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard Nell identify {xander}'s chipped ivory razor. I must compare that identifiable tool with the repeated cuts, not call the sighting a confession.",
              "observation": "I heard Nell identify {xander}'s chipped ivory razor.",
              "contradictingDetail": "I must compare that identifiable tool with the repeated cuts, not call the sighting a confession."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I heard {jasper}'s different-name rumor came from Ronan's old-license remark. His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin.",
              "observation": "I heard {jasper}'s different-name rumor came from Ronan's old-license remark.",
              "contradictingDetail": "His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin."
            }
          }
        ]
      },
      {
        "id": "jasper",
        "name": "Jasper Crowe",
        "role": "Tavern musician",
        "relationship": "Musician at the tavern of the second victim, Ronan Pike; asked to help compare witness accounts.",
        "tieIn": "A musician at Ronan Pike's tavern who also plays for town events. Often out late carrying his instrument between jobs.",
        "optional": false,
        "ghost": null,
        "guest": "",
        "guestNote": "",
        "publicBlurb": "A musician at Ronan Pike's tavern who also plays for town events. Often out late carrying his instrument between jobs.",
        "rounds": [
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard Della saw Elias refuse to enter {xander}'s workshop over an old receipt. He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon.",
              "observation": "I heard Della saw Elias refuse to enter {xander}'s workshop over an old receipt.",
              "contradictingDetail": "He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I heard Della heard {marla} dispute Ronan's flour bill at seven. She showed a receipt and left toward the bakery. I can't confirm payment or a later return.",
              "observation": "I heard Della heard {marla} dispute Ronan's flour bill at seven.",
              "contradictingDetail": "She showed a receipt and left toward the bakery. I can't confirm payment or a later return."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair. Chalk explains his cuff mark to me, not missing pages or blade skills.",
              "observation": "I heard Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair.",
              "contradictingDetail": "Chalk explains his cuff mark to me, not missing pages or blade skills."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I read {marla}'s signed bread delivery at six. I must distinguish an evening delivery from a fatal-morning visit; access alone does not explain the missing page.",
              "observation": "I read {marla}'s signed bread delivery at six.",
              "contradictingDetail": "I must distinguish an evening delivery from a fatal-morning visit; access alone does not explain the missing page."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge. It went into his stamped sleeve. I worry about those precise cuts, not a confession.",
              "observation": "I heard Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge.",
              "contradictingDetail": "It went into his stamped sleeve. I worry about those precise cuts, not a confession."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I read {marla}'s closing duty to scrub the rear threshold. I must correct my earlier suspicion: flour in her repaired heel can come from work, not a witnessed killing.",
              "observation": "I read {marla}'s closing duty to scrub the rear threshold.",
              "contradictingDetail": "I must correct my earlier suspicion: flour in her repaired heel can come from work, not a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard Edith match {xander}'s licensed likeness and workshop address: Benjamin Barker, barber. His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse.",
              "observation": "I heard Edith match {xander}'s licensed likeness and workshop address: Benjamin Barker, barber.",
              "contradictingDetail": "His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse."
            }
          }
        ]
      },
      {
        "id": "lydia",
        "name": "Lydia Vance",
        "role": "Schoolteacher",
        "relationship": "Teacher working alongside the third victim, senior teacher Harper Wren; asked to help compare witness accounts.",
        "tieIn": "A teacher working alongside senior teacher Harper Wren. Attentive to local families and protective of their privacy.",
        "publicBlurb": "A teacher working alongside senior teacher Harper Wren. Attentive to local families and protective of their privacy.",
        "optional": false,
        "guest": "",
        "guestNote": "",
        "ghost": null,
        "rounds": [
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I learned Della saw Elias refuse to enter {xander}'s workshop over an old receipt. He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon.",
              "observation": "I learned Della saw Elias refuse to enter {xander}'s workshop over an old receipt.",
              "contradictingDetail": "He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I learned Della heard {marla} dispute Ronan's flour bill at seven. She showed a receipt and left toward the bakery. I can't confirm payment or a later return.",
              "observation": "I learned Della heard {marla} dispute Ronan's flour bill at seven.",
              "contradictingDetail": "She showed a receipt and left toward the bakery. I can't confirm payment or a later return."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I checked {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak. I see how marks transfer, but Owen didn't watch the yard entrance overnight.",
              "observation": "I checked {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak.",
              "contradictingDetail": "I see how marks transfer, but Owen didn't watch the yard entrance overnight."
            }
          },
          {
            "readAloud": {
              "accuses": "nell",
              "text": "I heard the account: {nell} recorded a chalk smear and narrow drag line through it. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: {nell} recorded a chalk smear and narrow drag line through it.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "della",
              "text": "I heard the account: {della} saw Jasper holding the flask before oil spilled on his sleeve. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {della} saw Jasper holding the flask before oil spilled on his sleeve.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "finn",
              "text": "I heard the account: {finn} left for the delivery cart without witnessing the bakery death. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: {finn} left for the delivery cart without witnessing the bakery death.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "ada",
              "text": "I heard the account: {ada}'s account left later private visitors possible. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {ada}'s account left later private visitors possible.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          }
        ]
      },
      {
        "id": "nell",
        "name": "Nell Reed",
        "role": "Night watchwoman",
        "relationship": "An existing person in the supplied Blackwater Row accounts.",
        "tieIn": "Records the scene findings and supplies the razor sighting.",
        "publicBlurb": "Records the scene findings and supplies the razor sighting.",
        "optional": false,
        "guest": "",
        "guestNote": "",
        "ghost": null,
        "rounds": [
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I learned Nell saw {marla} leave the bakery's back door at nine with her red-handled brush. Her repaired, flour-packed heel resembles those prints. I still need their timing checked.",
              "observation": "I learned Nell saw {marla} leave the bakery's back door at nine with her red-handled brush.",
              "contradictingDetail": "Her repaired, flour-packed heel resembles those prints. I still need their timing checked."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I learned Ada saw {jasper}'s blue-strapped case on Ronan's counter at ten. His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors.",
              "observation": "I learned Ada saw {jasper}'s blue-strapped case on Ronan's counter at ten.",
              "contradictingDetail": "His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors."
            }
          },
          {
            "readAloud": {
              "accuses": "lydia",
              "text": "I learned Owen saw {lydia}'s green folder in Harper's classroom at six, discussing pupil privacy. Its chalk matches the desk height. I worry about access, but Owen left at seven.",
              "observation": "I learned Owen saw {lydia}'s green folder in Harper's classroom at six, discussing pupil privacy.",
              "contradictingDetail": "Its chalk matches the desk height. I worry about access, but Owen left at seven."
            }
          },
          {
            "readAloud": {
              "accuses": "della",
              "text": "I heard the account: {della} identified Lydia and the topic of the bakery argument. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: {della} identified Lydia and the topic of the bakery argument.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "finn",
              "text": "I heard the account: {finn} left for the delivery cart without witnessing the bakery death. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {finn} left for the delivery cart without witnessing the bakery death.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "ada",
              "text": "I heard the account: {ada} saw the blue-strapped case on Ronan's counter at ten. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: {ada} saw the blue-strapped case on Ronan's counter at ten.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "owen",
              "text": "I heard the account: {owen}'s accounts did not establish an overnight alibi. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {owen}'s accounts did not establish an overnight alibi.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          }
        ]
      },
      {
        "id": "della",
        "name": "Della March",
        "role": "Cobbler",
        "relationship": "An existing person in the supplied Blackwater Row accounts.",
        "tieIn": "Identifies the repaired boot and the neighbors in her recorded accounts.",
        "publicBlurb": "Identifies the repaired boot and the neighbors in her recorded accounts.",
        "optional": false,
        "guest": "",
        "guestNote": "",
        "ghost": null,
        "rounds": [
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I learned Finn saw {jasper} behind the bakery at nine-thirty with his blue-strapped case. A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave.",
              "observation": "I learned Finn saw {jasper} behind the bakery at nine-thirty with his blue-strapped case.",
              "contradictingDetail": "A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave."
            }
          },
          {
            "readAloud": {
              "accuses": "lydia",
              "text": "I learned Ada heard {lydia} warn Ronan about recording families at eight. She touched his book, leaving possible chalk. I can't prove a removed page or a later return.",
              "observation": "I learned Ada heard {lydia} warn Ronan about recording families at eight.",
              "contradictingDetail": "She touched his book, leaving possible chalk. I can't prove a removed page or a later return."
            }
          },
          {
            "readAloud": {
              "accuses": "nell",
              "text": "I heard the account: {nell} recorded a chalk smear and narrow drag line through it. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {nell} recorded a chalk smear and narrow drag line through it.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "finn",
              "text": "I heard the account: {finn} heard a promised parcel requested but saw no handover. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: {finn} heard a promised parcel requested but saw no handover.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "ada",
              "text": "I heard the account: {ada} saw the blue-strapped case on Ronan's counter at ten. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {ada} saw the blue-strapped case on Ronan's counter at ten.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "owen",
              "text": "I heard the account: {owen} left at seven without watching the separate yard entrance overnight. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: {owen} left at seven without watching the separate yard entrance overnight.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "edith",
              "text": "I heard the account: {edith} matched the licensed likeness and address to Xander. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {edith} matched the licensed likeness and address to Xander.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          }
        ]
      },
      {
        "id": "finn",
        "name": "Finn Moss",
        "role": "Delivery porter",
        "relationship": "An existing person in the supplied Blackwater Row accounts.",
        "tieIn": "Finds Elias and reports the musician waiting behind the bakery.",
        "publicBlurb": "Finds Elias and reports the musician waiting behind the bakery.",
        "optional": false,
        "guest": "",
        "guestNote": "",
        "ghost": null,
        "rounds": [
          {
            "readAloud": {
              "accuses": "lydia",
              "text": "I learned Della saw {lydia} argue with Elias that morning, her green lesson folder tucked under her arm. A bread bill held family history. I wonder why he folded that paper.",
              "observation": "I learned Della saw {lydia} argue with Elias that morning, her green lesson folder tucked under her arm.",
              "contradictingDetail": "A bread bill held family history. I wonder why he folded that paper."
            }
          },
          {
            "readAloud": {
              "accuses": "nell",
              "text": "I heard the account: {nell} recorded a wiped mug without usable fingerprints. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {nell} recorded a wiped mug without usable fingerprints.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "della",
              "text": "I heard the account: {della} identified Lydia and the topic of the bakery argument. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {della} identified Lydia and the topic of the bakery argument.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "ada",
              "text": "I heard the account: {ada} saw the fine stones in an address-stamped sleeve. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: {ada} saw the fine stones in an address-stamped sleeve.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "owen",
              "text": "I heard the account: {owen} left at seven without watching the separate yard entrance overnight. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {owen} left at seven without watching the separate yard entrance overnight.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "edith",
              "text": "I heard the account: {edith} has not supplied an office account at this stage. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: {edith} has not supplied an office account at this stage.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I learned Edith match {xander}'s licensed likeness and workshop address: Benjamin Barker, barber. His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse.",
              "observation": "I learned Edith match {xander}'s licensed likeness and workshop address: Benjamin Barker, barber.",
              "contradictingDetail": "His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse."
            }
          }
        ]
      },
      {
        "id": "ada",
        "name": "Ada Bell",
        "role": "Tavern cleaner",
        "relationship": "An existing person in the supplied Blackwater Row accounts.",
        "tieIn": "Finds Ronan and reports the tavern objects and appointments.",
        "publicBlurb": "Finds Ronan and reports the tavern objects and appointments.",
        "optional": false,
        "guest": "",
        "guestNote": "",
        "ghost": null,
        "rounds": [
          {
            "readAloud": {
              "accuses": "nell",
              "text": "I heard the account: {nell} recorded flour prints with a crescent gap in the right heel. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {nell} recorded flour prints with a crescent gap in the right heel.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "della",
              "text": "I heard the account: {della} heard Marla dispute the flour bill and leave toward the bakery. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {della} heard Marla dispute the flour bill and leave toward the bakery.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "finn",
              "text": "I heard the account: {finn} heard a promised parcel requested but saw no handover. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {finn} heard a promised parcel requested but saw no handover.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "owen",
              "text": "I heard the account: {owen} found Harper, locked the classroom and fetched Nell. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: {owen} found Harper, locked the classroom and fetched Nell.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "edith",
              "text": "I heard the account: {edith} has not supplied an office account at this stage. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {edith} has not supplied an office account at this stage.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I learned Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge. It went into his stamped sleeve. I worry about those precise cuts, not a confession.",
              "observation": "I learned Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge.",
              "contradictingDetail": "It went into his stamped sleeve. I worry about those precise cuts, not a confession."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I learned Edith confirm {marla}'s childhood delivery during Thorne's old workshop-home visit. She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot.",
              "observation": "I learned Edith confirm {marla}'s childhood delivery during Thorne's old workshop-home visit.",
              "contradictingDetail": "She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot."
            }
          }
        ]
      },
      {
        "id": "owen",
        "name": "Owen Bell",
        "role": "School caretaker",
        "relationship": "An existing person in the supplied Blackwater Row accounts.",
        "tieIn": "Finds Harper and supplies the school visit accounts and records.",
        "publicBlurb": "Finds Harper and supplies the school visit accounts and records.",
        "optional": false,
        "guest": "",
        "guestNote": "",
        "ghost": null,
        "rounds": [
          {
            "readAloud": {
              "accuses": "della",
              "text": "I heard the account: {della} recognized the repaired boot from its collection yesterday. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {della} recognized the repaired boot from its collection yesterday.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "finn",
              "text": "I heard the account: {finn} did not witness the bakery death or the musician leaving. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {finn} did not witness the bakery death or the musician leaving.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "ada",
              "text": "I heard the account: {ada} saw the fine stones in an address-stamped sleeve. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {ada} saw the fine stones in an address-stamped sleeve.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "edith",
              "text": "I heard the account: {edith} has not supplied an office account at this stage. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: {edith} has not supplied an office account at this stage.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I learned Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge. It went into his stamped sleeve. I worry about those precise cuts, not a confession.",
              "observation": "I learned Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge.",
              "contradictingDetail": "It went into his stamped sleeve. I worry about those precise cuts, not a confession."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I checked {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market. I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone.",
              "observation": "I checked {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market.",
              "contradictingDetail": "I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I learned {jasper}'s different-name rumor came from Ronan's old-license remark. His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin.",
              "observation": "I learned {jasper}'s different-name rumor came from Ronan's old-license remark.",
              "contradictingDetail": "His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin."
            }
          }
        ]
      },
      {
        "id": "edith",
        "name": "Edith Shaw",
        "role": "Office clerk",
        "relationship": "An existing person in the supplied Blackwater Row accounts.",
        "tieIn": "Finds Thorne and traces the final documents to the office cabinet.",
        "publicBlurb": "Finds Thorne and traces the final documents to the office cabinet.",
        "optional": false,
        "guest": "",
        "guestNote": "",
        "ghost": null,
        "rounds": [
          {
            "readAloud": {
              "accuses": "finn",
              "text": "I heard the account: {finn} found Elias and called Nell before anyone entered the yard. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {finn} found Elias and called Nell before anyone entered the yard.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "ada",
              "text": "I heard the account: {ada} found Ronan and left the mug untouched. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {ada} found Ronan and left the mug untouched.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "owen",
              "text": "I heard the account: {owen} found Harper, locked the classroom and fetched Nell. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {owen} found Harper, locked the classroom and fetched Nell.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I learned Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair. Chalk explains his cuff mark to me, not missing pages or blade skills.",
              "observation": "I learned Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair.",
              "contradictingDetail": "Chalk explains his cuff mark to me, not missing pages or blade skills."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I checked {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market. I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone.",
              "observation": "I checked {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market.",
              "contradictingDetail": "I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I learned Della saw {jasper} follow Tobias to the market lamp at ten. He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward.",
              "observation": "I learned Della saw {jasper} follow Tobias to the market lamp at ten.",
              "contradictingDetail": "He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward."
            }
          },
          {
            "readAloud": {
              "accuses": "lydia",
              "text": "I heard {lydia} saw Thorne hide receipt 47 during her confirmed school-funding appointment. She couldn't read the name. I see why she questioned family records, not proof she falsified them.",
              "observation": "I heard {lydia} saw Thorne hide receipt 47 during her confirmed school-funding appointment.",
              "contradictingDetail": "She couldn't read the name. I see why she questioned family records, not proof she falsified them."
            }
          }
        ]
      }
    ],
    "finale": {
      "narration": "All seven chapters and the final witness accounts have now been read. Compare the identified blade, the licensed likeness and address, and the duplicate records with the earlier observations. Decide which neighbor accounts for the complete chain, not just one suspicious trace. A reason for revenge can explain a crime without excusing it. Make your final accusation before the investigator announces the solution.",
      "votePrompt": "Who do you accuse based on the evidence heard so far?"
    },
    "solution": {
      "killerId": "xander",
      "explanation": "Xander Hale is Benjamin Barker, formerly Blackwater Row's trusted barber, and he committed all five murders. Thorne's letter and court file, first read in Round 7, establish that the Mayor wanted Barker's wife, framed him, ordered his imprisonment and forced her into his household. Elias's false delivery entry, Ronan's invented confession, Harper's altered household record and Tobias's false night sighting helped destroy Barker's married life. After release, Barker returned as the woodworker Xander Hale. The fine stones in his address-stamped sleeve and Harper's earlier-trade remark established a blade skill without naming it. Nell's direct observation of the chipped ivory razor in Round 5 supplied identifiable ownership; Edith's Round 7 comparison joined that razor, the licensed likeness and the repair invoice to the old identity. Receipt 47 linked the disturbed records; retained duplicates explained the target selection. Marla's repaired flour-marked boot had a documented closing-chore source. Jasper's case and rosin and Lydia's folder and chalk had witnessed work-related sources; their movements raised questions but did not explain the complete identity, weapon and motive chain. No stain alone proved a killing. Barker killed the four accomplices before reaching his final target, the Mayor. This was deliberate revenge, not justice.",
      "revealNarration": "The investigator closes the court file. \"The killer is {xander}. His former name was Benjamin Barker, and his former trade was barber. Nell identified the damaged razor in his hand; Edith matched the license and address to his current work. The earlier victims supplied the false statements that destroyed his former life. Thorne was his final target.\"\n\nThe host may read Barker's final words: \"Once this town knew me as Benjamin Barker. I had a trade, a wife and a home. Thorne wanted what was not his, and four respectable voices made his lie sound like law. When I returned, I called myself Xander Hale and worked in wood. I thought a new name could bury the old one. Instead I carried it through every door. I chose revenge, and I killed them. It did not restore my wife's freedom or the years we lost. Nothing they did makes these murders right.\"\n\nBlackwater Row must now reckon with both the original injustice and the five deaths that followed."
    },
    "masterPreserving": true,
    "conversion": {
      "source": "Committed four-player Blackwater Row revision 3.",
      "changes": [
        {
          "original": "Five discovery chapters and four playable neighbors.",
          "replacement": "Five unchanged discovery sequences with two intervening comparison chapters and a three-player core.",
          "reason": "Seven-round requirement and smallest-edition master. Identity remains in the last discovery chapter; no murders or facts are added."
        },
        {
          "original": "Per-chapter four-player reader handoffs and twenty player responses.",
          "replacement": "Named recorded responses in shared narration and count-specific group order.",
          "reason": "Preserve every witness source and original response while selecting a three-player loop."
        },
        {
          "original": "Solution timing references to Round 4 and Round 5.",
          "replacement": "Corresponding seven-chapter references to Round 5 and Round 7.",
          "reason": "Inserted comparison rounds shift chapter numbers without advancing evidence."
        }
      ],
      "originalResponses": [
        {
          "id": "xander",
          "rounds": [
            {
              "readAloud": {
                "accuses": "marla",
                "text": "I heard Nell saw {marla} leave the bakery's back door at nine with her red-handled brush. Her repaired, flour-packed heel resembles those prints. I still need their timing checked.",
                "observation": "I heard Nell saw {marla} leave the bakery's back door at nine with her red-handled brush.",
                "contradictingDetail": "Her repaired, flour-packed heel resembles those prints. I still need their timing checked."
              }
            },
            {
              "readAloud": {
                "accuses": "jasper",
                "text": "I heard Ada saw {jasper}'s blue-strapped case on Ronan's counter at ten. His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors.",
                "observation": "I heard Ada saw {jasper}'s blue-strapped case on Ronan's counter at ten.",
                "contradictingDetail": "His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors."
              }
            },
            {
              "readAloud": {
                "accuses": "lydia",
                "text": "I heard Owen saw {lydia}'s green folder in Harper's classroom at six, discussing pupil privacy. Its chalk matches the desk height. I worry about access, but Owen left at seven.",
                "observation": "I heard Owen saw {lydia}'s green folder in Harper's classroom at six, discussing pupil privacy.",
                "contradictingDetail": "Its chalk matches the desk height. I worry about access, but Owen left at seven."
              }
            },
            {
              "readAloud": {
                "accuses": "marla",
                "text": "I read {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market. I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone.",
                "observation": "I read {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market.",
                "contradictingDetail": "I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone."
              }
            },
            {
              "readAloud": {
                "accuses": "jasper",
                "text": "I heard {jasper}'s different-name rumor came from Ronan's old-license remark. His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin.",
                "observation": "I heard {jasper}'s different-name rumor came from Ronan's old-license remark.",
                "contradictingDetail": "His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin."
              }
            }
          ]
        },
        {
          "id": "marla",
          "rounds": [
            {
              "readAloud": {
                "accuses": "jasper",
                "text": "I heard Finn saw {jasper} behind the bakery at nine-thirty with his blue-strapped case. A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave.",
                "observation": "I heard Finn saw {jasper} behind the bakery at nine-thirty with his blue-strapped case.",
                "contradictingDetail": "A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave."
              }
            },
            {
              "readAloud": {
                "accuses": "lydia",
                "text": "I heard Ada heard {lydia} warn Ronan about recording families at eight. She touched his book, leaving possible chalk. I can't prove a removed page or a later return.",
                "observation": "I heard Ada heard {lydia} warn Ronan about recording families at eight.",
                "contradictingDetail": "She touched his book, leaving possible chalk. I can't prove a removed page or a later return."
              }
            },
            {
              "readAloud": {
                "accuses": "xander",
                "text": "I heard Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair. Chalk explains his cuff mark to me, not missing pages or blade skills.",
                "observation": "I heard Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair.",
                "contradictingDetail": "Chalk explains his cuff mark to me, not missing pages or blade skills."
              }
            },
            {
              "readAloud": {
                "accuses": "jasper",
                "text": "I heard Della saw {jasper} follow Tobias to the market lamp at ten. He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward.",
                "observation": "I heard Della saw {jasper} follow Tobias to the market lamp at ten.",
                "contradictingDetail": "He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward."
              }
            },
            {
              "readAloud": {
                "accuses": "lydia",
                "text": "I learned {lydia} saw Thorne hide receipt 47 during her confirmed school-funding appointment. She couldn't read the name. I see why she questioned family records, not proof she falsified them.",
                "observation": "I learned {lydia} saw Thorne hide receipt 47 during her confirmed school-funding appointment.",
                "contradictingDetail": "She couldn't read the name. I see why she questioned family records, not proof she falsified them."
              }
            }
          ]
        },
        {
          "id": "jasper",
          "rounds": [
            {
              "readAloud": {
                "accuses": "lydia",
                "text": "I heard Della saw {lydia} argue with Elias that morning, her green lesson folder tucked under her arm. A bread bill held family history. I wonder why he folded that paper.",
                "observation": "I heard Della saw {lydia} argue with Elias that morning, her green lesson folder tucked under her arm.",
                "contradictingDetail": "A bread bill held family history. I wonder why he folded that paper."
              }
            },
            {
              "readAloud": {
                "accuses": "xander",
                "text": "I read {xander}'s shelf invoice; Ada saw fine sharpening stones in his address-stamped sleeve. His repair cloth held amber shellac. I see another possible smear source, not proof he touched that mug.",
                "observation": "I read {xander}'s shelf invoice; Ada saw fine sharpening stones in his address-stamped sleeve.",
                "contradictingDetail": "His repair cloth held amber shellac. I see another possible smear source, not proof he touched that mug."
              }
            },
            {
              "readAloud": {
                "accuses": "marla",
                "text": "I read {marla}'s signed six-o'clock bread delivery to Harper's classroom door. Owen saw her wait by the open records drawer. I see access, but not a fatal-morning visit.",
                "observation": "I read {marla}'s signed six-o'clock bread delivery to Harper's classroom door.",
                "contradictingDetail": "Owen saw her wait by the open records drawer. I see access, but not a fatal-morning visit."
              }
            },
            {
              "readAloud": {
                "accuses": "lydia",
                "text": "I read {lydia}'s warning to Tobias: children's family affairs don't belong in street notes. Her weekly lesson meetings explain contact to me, not an overnight alibi or receipt 47's torn page.",
                "observation": "I read {lydia}'s warning to Tobias: children's family affairs don't belong in street notes.",
                "contradictingDetail": "Her weekly lesson meetings explain contact to me, not an overnight alibi or receipt 47's torn page."
              }
            },
            {
              "readAloud": {
                "accuses": "xander",
                "text": "I heard Edith match {xander}'s licensed likeness and workshop address: Benjamin Barker, barber. His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse.",
                "observation": "I heard Edith match {xander}'s licensed likeness and workshop address: Benjamin Barker, barber.",
                "contradictingDetail": "His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse."
              }
            }
          ]
        },
        {
          "id": "lydia",
          "rounds": [
            {
              "readAloud": {
                "accuses": "xander",
                "text": "I heard Della saw Elias refuse to enter {xander}'s workshop over an old receipt. He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon.",
                "observation": "I heard Della saw Elias refuse to enter {xander}'s workshop over an old receipt.",
                "contradictingDetail": "He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon."
              }
            },
            {
              "readAloud": {
                "accuses": "marla",
                "text": "I heard Della heard {marla} dispute Ronan's flour bill at seven. She showed a receipt and left toward the bakery. I can't confirm payment or a later return.",
                "observation": "I heard Della heard {marla} dispute Ronan's flour bill at seven.",
                "contradictingDetail": "She showed a receipt and left toward the bakery. I can't confirm payment or a later return."
              }
            },
            {
              "readAloud": {
                "accuses": "jasper",
                "text": "I read {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak. I see how marks transfer, but Owen didn't watch the yard entrance overnight.",
                "observation": "I read {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak.",
                "contradictingDetail": "I see how marks transfer, but Owen didn't watch the yard entrance overnight."
              }
            },
            {
              "readAloud": {
                "accuses": "xander",
                "text": "I heard Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge. It went into his stamped sleeve. I worry about those precise cuts, not a confession.",
                "observation": "I heard Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge.",
                "contradictingDetail": "It went into his stamped sleeve. I worry about those precise cuts, not a confession."
              }
            },
            {
              "readAloud": {
                "accuses": "marla",
                "text": "I heard Edith confirm {marla}'s childhood delivery during Thorne's old workshop-home visit. She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot.",
                "observation": "I heard Edith confirm {marla}'s childhood delivery during Thorne's old workshop-home visit.",
                "contradictingDetail": "She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot."
              }
            }
          ]
        }
      ]
    }
  },
  "11": {
    "schemaVersion": 2,
    "fixedPlayerCount": 11,
    "discloseKiller": false,
    "clueRouting": "rotating",
    "edition": {
      "family": "blackwater-scalable",
      "id": "blackwater-scalable-11-players",
      "playerCount": 11,
      "revision": 1
    },
    "title": "The Barber of Blackwater Row",
    "atmosphere": "victorian",
    "setting": "Blackwater Row, a riverside town of workshops, narrow lanes and gaslit streets in the late nineteenth century.",
    "intro": "Evening settles over Blackwater Row. Three neighbors help the town investigator compare the supplied accounts: Xander Hale, the woodworker; Marla Quinn, the baker's assistant; and Jasper Crowe, the tavern musician. The host reads every recorded witness account before the players respond. Other named people remain in the evidence even when they are not playable. Discuss only the chapter just heard; nobody invents a history, witnesses a new discovery or improvises a private part.",
    "hiddenThread": "Receipt 47 recurs in every victim's disturbed records and finally names the Mayor's old imprisonment order against Benjamin Barker.",
    "coverageRepeatNote": "The trio covers all six directed pairs in the first two rounds. Later repeats add released evidence or explicitly correct an unsupported earlier inference. Each supplemental reader targets every other selected character before repeating, never in consecutive rounds. Separate singleton readings preserve the master loop and evidence timing.",
    "specialMechanics": [
      "Receipt 47 ledger: each murder surfaces another record indexed under receipt 47 (delivery log, tavern scrap, student-record index, night-route page). Compare them across rounds; the Mayor's signed order in Round 7 finally connects the series to the old case."
    ],
    "victim": {
      "name": "Elias Brim",
      "description": "The town baker, known for dependable bread deliveries and careful records."
    },
    "rounds": [
      {
        "title": "Round 1 - The Baker's Murder",
        "narration": "At dawn, delivery porter Finn Moss finds Elias Brim behind his bakery with his throat slashed. The investigator reports one clean, precise cut; the death happened off-screen. Elias supplied nearly every doorstep and recorded deliveries and closing chores in separate books. Finn calls night watchwoman Nell Reed before anyone enters the yard. She records a chain of flour prints from the back door to the wet cobbles. Each right print has a crescent-shaped gap at the heel; the cobbles preserve nothing beyond it. A page is torn from an older delivery log. Its surviving edge carries the date and part of receipt 47, but not a customer name or the purpose of the entry. The closing-duty sheet is intact and is kept for later comparison. These are the findings at this scene, not an identification of the killer. The investigator has collected four separate accounts about the neighbors.  Hear all four before discussing which details establish access and which merely raise suspicion.\n\nThe investigator reads the supporting witness accounts before calling on the selected readers:\n\nWitness background for Marla Quinn: Nell Reed saw Marla Quinn leave the bakery back door at nine, carrying her red-handled scrubbing brush. Nell recognized the brass buckle and crescent-shaped repair in the right heel of her work boots because cobbler Della March had shown her that repair at collection yesterday. Flour was packed into the repaired heel. The shape resembles the yard prints recorded this morning. This ties the boots to bakery work and the doorway, but does not date when each print was made. The closing-duty sheet has not yet been checked against the sighting.\n\nWitness background for Jasper Crowe: Finn Moss saw Jasper Crowe waiting behind the bakery at half past nine, with a blue-strapped instrument case propped against the wall. Finn recognized the musician from the tavern and the case from carrying it after last week's performance. A pale streak ran across its lower corner where it touched a flour sack outside the door. Finn heard him ask Elias for a promised parcel, but did not see a parcel handed over or hear what it contained. Finn left for the delivery cart; he did not witness the death or the musician's departure.\n\nWitness background for Lydia Vance: Della March saw Lydia Vance arguing with Elias at the bakery front counter that morning. She recognized the teacher from collecting her granddaughter from school and saw the same green lesson folder under her arm. Della heard the teacher ask why a bread bill included a household's personal history. Elias folded a paper and refused to answer. The teacher left a chalky thumb mark on the counter when she leaned forward. Della identifies the person and the topic, but heard no threat and never saw the contents of the folded paper.\n\nWitness background for Xander Hale: Della March delivered a wooden chair to Xander Hale's workshop last week and saw Elias at the open door. She recognized both men from their regular work at her market stall. Elias refused to enter and said, \"I will not bring that old receipt here again.\" The woodworker stopped sanding, gripped the chair rail and asked which book Elias meant. Della saw fresh amber shellac on his apron beside the repair cloth, but no weapon. She can identify the reaction and the receipt dispute; she cannot identify the old transaction or turn that reaction into proof of murder.\n\nThe host reads the original neighbors' recorded responses:\nXander Hale's recorded response: \"I heard Nell saw Marla Quinn leave the bakery's back door at nine with her red-handled brush. Her repaired, flour-packed heel resembles those prints. I still need their timing checked.\"\nMarla Quinn's recorded response: \"I heard Finn saw Jasper Crowe behind the bakery at nine-thirty with his blue-strapped case. A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave.\"\nJasper Crowe's recorded response: \"I heard Della saw Lydia Vance argue with Elias that morning, her green lesson folder tucked under her arm. A bread bill held family history. I wonder why he folded that paper.\"\nLydia Vance's recorded response: \"I heard Della saw Elias refuse to enter Xander Hale's workshop over an old receipt. He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon.\"\n\nThe supplied witness accounts support these comparisons:\nNell Reed recorded flour prints with a crescent gap in the right heel.\nDella March recognized the repaired boot from its collection yesterday.\nFinn Moss found Elias and called Nell before anyone entered the yard.\nAda Bell has not supplied a tavern account at this stage.\nOwen Bell has not supplied a classroom account at this stage.\nEdith Shaw has not supplied an office account at this stage.\nTown Investigator reported one precise cut at the bakery.\nDella recognized Lydia through collecting Della's Granddaughter from school.",
        "publicText": "Elias Brim: throat slashed with one precise cut. Finn Moss found the body; Nell Reed recorded flour prints with a crescent gap in the right heel. An old delivery-log page is torn; only receipt 47 survives at its edge. The closing-duty sheet is intact.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "At dawn, delivery porter Finn Moss finds Elias Brim behind his bakery with his throat slashed.",
          "The investigator reports one clean, precise cut; the death happened off-screen.",
          "Elias supplied nearly every doorstep and recorded deliveries and closing chores in separate books."
        ],
        "readingGroups": [
          [
            "xander",
            "marla",
            "jasper"
          ],
          [
            "lydia"
          ],
          [
            "nell"
          ],
          [
            "della"
          ],
          [
            "finn"
          ],
          [
            "ada"
          ],
          [
            "owen"
          ],
          [
            "edith"
          ],
          [
            "investigator"
          ]
        ],
        "chain": [
          "xander",
          "marla",
          "jasper",
          "lydia",
          "nell",
          "della",
          "finn",
          "ada",
          "owen",
          "edith",
          "investigator"
        ],
        "coverageRepeat": false
      },
      {
        "title": "Round 2 - The Barkeep's Murder",
        "narration": "The next morning, cleaner Ada Bell finds Ronan Pike slumped over his tavern counter with his throat slashed. The investigator records the same precise cut as at the bakery. Ronan kept accounts of debts and stayed late for private appointments. Ada does not touch the mug beside him; Nell Reed records that it has been wiped and has no usable fingerprints. A thin amber smear remains beneath its handle. No owner has been established for the mug or the smear. Beneath Ronan's account book lies a scrap bearing receipt 47 and four lines of dates. No names or explanation survive on the scrap. The matching number links two sets of records, but does not identify their subject. Ronan's service tally and appointment book are preserved separately so that the last drink served will not be confused with the last visitor admitted. Four witness accounts are ready.  Listen for who saw an object, how they identified its owner and whether their timing actually reaches the death.\n\nThe investigator reads the supporting witness accounts before calling on the selected readers:\n\nWitness background for Jasper Crowe: Ada Bell saw Jasper Crowe put his instrument case on Ronan's counter at ten and leave after the last public drink was served. She recognized the case by its repaired blue strap, which she had sewn herself. He uses amber rosin on his bow; Ada collected a flake from the spot where the case rested. Its color resembles the smear beneath the wiped mug, but color alone cannot establish that they are the same material. Ronan locked the public door afterward; Ada did not watch the side entrance or the later appointments.\n\nWitness background for Lydia Vance: Ada Bell heard Lydia Vance tell Ronan at eight, \"Those are dangerous notes; people did not give you permission to record their families.\" Ada recognized the green lesson folder under the teacher's arm from her school-cleaning rounds. The teacher tapped Ronan's account book, leaving a white powder trace on its dark cover. Ada collected it as a possible chalk transfer, not a laboratory identification. The warning concerns records, but Ada saw no page removed. The teacher walked out through the public door; Ada could not observe who returned later.\n\nWitness background for Xander Hale: Ronan's repair invoice records Xander Hale replacing the tavern shelf last week. Ada Bell identified him from the signed invoice and saw him open a leather tool sleeve stamped with the same workshop address. Inside were sharpening stones Ronan called \"too fine for woodworking\": one was much narrower and smoother than the broad stone used on the shelf chisel. Ada saw him wipe the sleeve with an amber shellac-stained cloth from his repair kit. That establishes ownership of the stones and a second possible source of amber residue; it does not prove who handled the wiped mug on the night of the murder.\n\nWitness background for Marla Quinn: Della March heard Marla Quinn dispute an unpaid flour bill with Ronan outside the tavern at seven. She recognized the baker's assistant by the stamped delivery basket she was carrying. Ronan held a bill with a torn lower corner; the assistant produced a coin receipt, but Della was too far away to compare its amount. She saw the assistant leave with the basket toward the bakery. The argument supplies a specific grievance and an observed departure, not proof of payment or a witnessed return to the counter where Ronan died.\n\nThe host reads the original neighbors' recorded responses:\nXander Hale's recorded response: \"I heard Ada saw Jasper Crowe's blue-strapped case on Ronan's counter at ten. His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors.\"\nMarla Quinn's recorded response: \"I heard Ada heard Lydia Vance warn Ronan about recording families at eight. She touched his book, leaving possible chalk. I can't prove a removed page or a later return.\"\nJasper Crowe's recorded response: \"I read Xander Hale's shelf invoice; Ada saw fine sharpening stones in his address-stamped sleeve. His repair cloth held amber shellac. I see another possible smear source, not proof he touched that mug.\"\nLydia Vance's recorded response: \"I heard Della heard Marla Quinn dispute Ronan's flour bill at seven. She showed a receipt and left toward the bakery. I can't confirm payment or a later return.\"\n\nThe supplied witness accounts support these comparisons:\nNell Reed recorded a wiped mug without usable fingerprints.\nDella March heard Marla dispute the flour bill and leave toward the bakery.\nFinn Moss did not witness the bakery death or the musician leaving.\nAda Bell found Ronan and left the mug untouched.\nOwen Bell has not supplied a classroom account at this stage.\nEdith Shaw has not supplied an office account at this stage.\nTown Investigator reported the same precise cut at the tavern.\nDella's school collection of Della's Granddaughter explains her recognition of Lydia.",
        "publicText": "Ronan Pike: throat slashed with the same precise cut. Ada Bell found him. A wiped mug has no usable fingerprints and an unidentified amber smear beneath its handle. A dated scrap bears receipt 47 but no names. Service and appointment records are preserved.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "The next morning, cleaner Ada Bell finds Ronan Pike slumped over his tavern counter with his throat slashed.",
          "The investigator records the same precise cut as at the bakery.",
          "Ronan kept accounts of debts and stayed late for private appointments."
        ],
        "readingGroups": [
          [
            "xander",
            "jasper",
            "marla"
          ],
          [
            "lydia"
          ],
          [
            "nell"
          ],
          [
            "della"
          ],
          [
            "finn"
          ],
          [
            "ada"
          ],
          [
            "owen"
          ],
          [
            "edith"
          ],
          [
            "investigator"
          ]
        ],
        "chain": [
          "xander",
          "jasper",
          "marla",
          "lydia",
          "nell",
          "della",
          "finn",
          "ada",
          "owen",
          "edith",
          "investigator"
        ],
        "coverageRepeat": false
      },
      {
        "title": "Round 3 - The Schoolteacher's Murder",
        "narration": "Before sunrise, caretaker Owen Bell finds senior teacher Harper Wren in her classroom with her throat slashed, the same precise cut again. Harper taught most of the town's children and kept family records as carefully as lesson plans. Owen locks the room and fetches Nell Reed. She records a broad chalk smear across the desk and a narrow drag line through it, running from the student-record book toward its open drawer. A page is missing from that book. Its remaining index cites receipt 47; a margin note says, \"Copy kept with the original order.\" Neither the order's owner nor its location is recorded here. Owen also hands over the fundraiser attendance sheet and Harper's lesson diary, both intact. Three disturbed records now share a number. That is a link worth following, not yet an explanation.  Compare observed visits with the traces on the desk, and keep the identity of any missing document separate from guesses about it.\n\nThe investigator reads the supporting witness accounts before calling on the selected readers:\n\nWitness background for Lydia Vance: Owen Bell saw Lydia Vance enter Harper's classroom at six carrying her green lesson folder. He recognized her name written inside its cover when she left it beside the register. A broad chalk mark on the folder's edge matches the height of the smeared desk; Owen had watched her lean it there while discussing pupil privacy. Her warning was, \"A family record should not become a weapon.\" This explains regular access and a possible source of chalk transfer, but Owen left at seven and cannot account for the classroom overnight.\n\nWitness background for Xander Hale: Owen Bell recalls Harper pointing out Xander Hale's narrow whetstone while the woodworker repaired her drawer rail last Tuesday. Owen saw the stone in a leather sleeve stamped with the workshop's address; he checked that address on the repair invoice. Harper said he \"used to work with blades in another trade\" but did not name it. Owen also saw fresh blue chalk on the woodworker's cuff after measuring the rail with Harper's chalk line. That gives an ordinary source for the cuff mark, not an explanation of the missing page or the earlier blade skills.\n\nWitness background for Marla Quinn: Owen Bell signed for Marla Quinn's six-o'clock bread delivery to Harper on the morning before the death. He recognized the baker's stamped basket and the repaired brass-buckled boots described in Round 1. The delivery docket, signed by Harper, specifies the classroom door rather than the school kitchen. Owen saw the assistant wait while Harper opened the student-record drawer to find payment. This gives a witnessed reason for knowing Harper's schedule and seeing the drawer. Neither the flour on the boots nor that access proves a visit before sunrise on the fatal morning.\n\nWitness background for Jasper Crowe: Owen Bell checked Jasper Crowe's name on the fundraiser attendance sheet at nine the previous evening. He recognized the blue-strapped case and watched the musician leave it beside Harper's desk while stacking chairs. White chalk marked the case corner where it rubbed the desktop, covering part of the pale bakery streak described in Round 1. Owen identifies a source for the transfer and a reason for being in the room. He locked the public school door after the event, but did not remain to watch the classroom's separate yard entrance overnight.\n\nThe host reads the original neighbors' recorded responses:\nXander Hale's recorded response: \"I heard Owen saw Lydia Vance's green folder in Harper's classroom at six, discussing pupil privacy. Its chalk matches the desk height. I worry about access, but Owen left at seven.\"\nMarla Quinn's recorded response: \"I heard Harper said Xander Hale once worked with blades; Owen saw his narrow whetstone during her drawer repair. Chalk explains his cuff mark to me, not missing pages or blade skills.\"\nJasper Crowe's recorded response: \"I read Marla Quinn's signed six-o'clock bread delivery to Harper's classroom door. Owen saw her wait by the open records drawer. I see access, but not a fatal-morning visit.\"\nLydia Vance's recorded response: \"I read Jasper Crowe's nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak. I see how marks transfer, but Owen didn't watch the yard entrance overnight.\"\n\nThe supplied witness accounts support these comparisons:\nNell Reed recorded a chalk smear and narrow drag line through it.\nDella March identified Lydia and the topic of the bakery argument.\nFinn Moss heard a promised parcel requested but saw no handover.\nAda Bell saw the fine stones in an address-stamped sleeve.\nOwen Bell found Harper, locked the classroom and fetched Nell.\nEdith Shaw has not supplied an office account at this stage.\nTown Investigator connected three disturbed records by receipt 47.\nDella's collection of Della's Granddaughter identifies a teacher, not a threat.",
        "publicText": "Harper Wren: throat slashed with the same precise cut. Owen Bell found her; Nell Reed recorded chalk and a drag line beside a disturbed student-record book. Its index cites receipt 47 and a copy kept with an unnamed original order. Attendance and lesson records are intact.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "Before sunrise, caretaker Owen Bell finds senior teacher Harper Wren in her classroom with her throat slashed, the same precise cut again.",
          "Harper taught most of the town's children and kept family records as carefully as lesson plans.",
          "Owen locks the room and fetches Nell Reed."
        ],
        "readingGroups": [
          [
            "xander",
            "marla",
            "jasper"
          ],
          [
            "lydia"
          ],
          [
            "nell"
          ],
          [
            "della"
          ],
          [
            "finn"
          ],
          [
            "ada"
          ],
          [
            "owen"
          ],
          [
            "edith"
          ],
          [
            "investigator"
          ]
        ],
        "chain": [
          "xander",
          "marla",
          "jasper",
          "lydia",
          "nell",
          "della",
          "finn",
          "ada",
          "owen",
          "edith",
          "investigator"
        ],
        "coverageRepeat": true
      },
      {
        "title": "Round 4 - Visits and Transferred Marks",
        "narration": "Compare only the findings already read at the bakery, tavern and school. An evening delivery is not a fatal-morning visit; flour, rosin, shellac and chalk have witnessed work-related sources. Receipt 47 links disturbed records but does not yet identify their subject. Correct an accusation that mistakes a work trace or access for a witnessed killing. No new death, name, trade or weapon identification is introduced.",
        "publicText": "Correct earlier inferences using only already released evidence.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "Compare released work traces with the recorded visits.",
          "Correct unsupported accusations without a new discovery."
        ],
        "readingGroups": [
          [
            "xander",
            "jasper",
            "marla"
          ],
          [
            "lydia"
          ],
          [
            "nell"
          ],
          [
            "della"
          ],
          [
            "finn"
          ],
          [
            "ada"
          ],
          [
            "owen"
          ],
          [
            "edith"
          ],
          [
            "investigator"
          ]
        ],
        "chain": [
          "xander",
          "jasper",
          "marla",
          "lydia",
          "nell",
          "della",
          "finn",
          "ada",
          "owen",
          "edith",
          "investigator"
        ],
        "coverageRepeat": true
      },
      {
        "title": "Round 5 - The Lamplighter's Murder",
        "narration": "Before the morning market opens, Nell Reed finds Tobias Wick beside an extinguished streetlamp with his throat slashed in the same precise manner. Tobias walked every lane at night and kept route notes about what he saw. Lamp oil has spilled in a perfect circle around the lamp base. Nell records its position before moving the fallen oil flask; the shape of the spill alone cannot identify who was there. A page is torn from Tobias's old route notebook. The surviving index bears receipt 47 and the instruction, \"Retain duplicate with original order.\" Nell gathers the bakery closing-duty sheet, Ronan's appointment book and Harper's lesson diary for comparison with the earlier witness accounts. Their entries can explain a visit or correct a timing assumption, but they are not blanket alibis. The subject of the old records is still missing.  Let each account introduce its own new finding. Then compare the four scenes and ask which traces are ordinary work and which remain unexplained.\n\nThe investigator reads the supporting witness accounts before calling on the selected readers:\n\nWitness background for Marla Quinn: Nell Reed compares Marla Quinn's flour-marked repaired boot from Round 1 with the bakery closing-duty sheet. Elias initialed her nine-o'clock task: scrub the rear threshold, then deliver the waste pail to the market. The entry explains why the crescent heel and flour appeared at the doorway; it is not evidence that the print was made during the killing. Market seller Della March also records that the assistant reported Tobias arguing with an unidentified figure beside the oil stall last night. Della heard the report, not the argument, so she cannot identify that figure.\n\nWitness background for Jasper Crowe: Della March saw Jasper Crowe follow Tobias from the tavern to the market lamp at ten last night. She identified the musician by his blue-strapped case and by the tune he had just played at her stall. Tobias asked him to hold the oil flask while adjusting the wick; Della saw a drop spill onto his right sleeve. The stain therefore has an observed source, not merely an assumed link to lamplighting. Della closed her shutter before Tobias resumed his route. The musician's presence and oil stain establish contact, but not where either man went afterward.\n\nWitness background for Lydia Vance: Nell Reed finds Lydia Vance's warning to Tobias entered in his intact route book: \"Children's family affairs do not belong in street notes.\" The entry describes her green folder and the school gate, where Owen Bell confirms he saw them speak. Nell compares it with Harper's lesson diary, which schedules their weekly meetings to prepare lessons and handle family requests. These sources explain the teacher's meetings and concern about records without supplying an overnight alibi. They do not explain why the older page indexed under receipt 47 was torn out.\n\nWitness background for Xander Hale: Nell Reed saw Xander Hale beneath the workshop lamp yesterday evening, holding a straight razor rather than a woodworking chisel. She recognized him from the shelf-repair invoice she had collected at the tavern and spoke to him face to face. The open blade reflected the lamp; the ivory handle had a triangular chip beside its hinge. He closed it and put it into the address-stamped leather sleeve whose fine stones Ada Bell described in Round 2. Nell can identify the owner, object and distinctive damage, but she did not see an attack. The blade should be compared with the repeated precise cuts, not treated as a confession.\n\nThe host reads the original neighbors' recorded responses:\nXander Hale's recorded response: \"I read Marla Quinn's nine-o'clock closing duty: scrub the rear threshold, then take waste to market. I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone.\"\nMarla Quinn's recorded response: \"I heard Della saw Jasper Crowe follow Tobias to the market lamp at ten. He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward.\"\nJasper Crowe's recorded response: \"I read Lydia Vance's warning to Tobias: children's family affairs don't belong in street notes. Her weekly lesson meetings explain contact to me, not an overnight alibi or receipt 47's torn page.\"\nLydia Vance's recorded response: \"I heard Nell saw Xander Hale's straight razor: ivory handle, triangular chip beside its hinge. It went into his stamped sleeve. I worry about those precise cuts, not a confession.\"\n\nThe supplied witness accounts support these comparisons:\nNell Reed saw the chipped ivory razor enter the stamped sleeve.\nDella March saw Jasper holding the flask before oil spilled on his sleeve.\nFinn Moss left for the delivery cart without witnessing the bakery death.\nAda Bell saw the blue-strapped case on Ronan's counter at ten.\nOwen Bell left at seven without watching the separate yard entrance overnight.\nEdith Shaw has not supplied an office account at this stage.\nTown Investigator preserved the earlier work records for timing comparisons.\nDella's school collection of Della's Granddaughter does not identify a murderer.",
        "publicText": "Tobias Wick: throat slashed with the same precise cut. Nell Reed found him beside an extinguished lamp and a circle of spilled oil. A torn night-route page is indexed under receipt 47. Earlier work and appointment records are ready for comparison, not complete alibis.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "Before the morning market opens, Nell Reed finds Tobias Wick beside an extinguished streetlamp with his throat slashed in the same precise manner.",
          "Tobias walked every lane at night and kept route notes about what he saw.",
          "Lamp oil has spilled in a perfect circle around the lamp base."
        ],
        "readingGroups": [
          [
            "xander",
            "marla",
            "jasper"
          ],
          [
            "lydia"
          ],
          [
            "nell"
          ],
          [
            "della"
          ],
          [
            "finn"
          ],
          [
            "ada"
          ],
          [
            "owen"
          ],
          [
            "edith"
          ],
          [
            "investigator"
          ]
        ],
        "chain": [
          "xander",
          "marla",
          "jasper",
          "lydia",
          "nell",
          "della",
          "finn",
          "ada",
          "owen",
          "edith",
          "investigator"
        ],
        "coverageRepeat": true
      },
      {
        "title": "Round 6 - Work Traces and the Identified Tool",
        "narration": "Compare the already released closing-duty sheet, private-appointment records, school visits and Nell's chipped-razor sighting. A work record can explain a trace without supplying an overnight alibi. The identified razor is more specific than an unexplained color or stain, but its sighting is not a confession. Correct earlier accusations based only on flour, chalk or spilled oil. No new death or old identity is introduced.",
        "publicText": "Correct earlier inferences using only already released evidence.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "Compare released work traces with the recorded visits.",
          "Correct unsupported accusations without a new discovery."
        ],
        "readingGroups": [
          [
            "xander",
            "jasper",
            "marla"
          ],
          [
            "lydia"
          ],
          [
            "nell"
          ],
          [
            "della"
          ],
          [
            "finn"
          ],
          [
            "ada"
          ],
          [
            "owen"
          ],
          [
            "edith"
          ],
          [
            "investigator"
          ]
        ],
        "chain": [
          "xander",
          "jasper",
          "marla",
          "lydia",
          "nell",
          "della",
          "finn",
          "ada",
          "owen",
          "edith",
          "investigator"
        ],
        "coverageRepeat": true
      },
      {
        "title": "Round 7 - The Mayor's Murder",
        "narration": "Office clerk Edith Shaw finds Mayor Aldric Thorne in his office chair with his throat slashed, the same precise cut. A polished straight razor lies on the desk, its ivory handle chipped beside the hinge. Edith calls Nell Reed and identifies the locked cabinet from which the papers on the desk came; its numbered index and broken wax seal allow the investigator to trace their source. A single old court document, signed by Thorne, orders the imprisonment of BENJAMIN BARKER and bears receipt 47. This is the first time that name enters the investigation. With it are the duplicate records referred to in Harper's index and Tobias's notebook. The investigator reads them aloud: Elias signed a false delivery entry placing Barker at a theft; Ronan signed a fabricated account of a confession; Harper altered a household record to support the charge; Tobias supplied a false night-route sighting. A retained letter from Thorne orders the changes, admits that he wanted Barker's wife and describes using imprisonment to separate them. The household record states that she was taken into Thorne's household under coercion, not by free choice. Barker's licensed occupation is barber. A likeness, address and tool inventory are attached, but the investigator leaves their identification to the witnesses whose accounts you are about to hear. These documents establish the original injustice and the four victims' roles. They do not announce which current neighbor committed the murders.  Hear every account before the final vote.\n\nThe investigator reads the supporting witness accounts before calling on the selected readers:\n\nWitness background for Jasper Crowe: Edith Shaw asks Jasper Crowe to explain a rumor he heard at the tavern about the woodworker once using a different name. He identifies its source as Ronan's remark about an old license, not personal knowledge of the imprisonment. Edith compares the signature on his ten-o'clock drink receipt with the appointment book preserved in Round 2; it confirms his earlier visit, while a separate eleven-o'clock entry admits a private visitor. His rosin flake explains a substance on the counter, but neither the rumor nor the flake identifies that later visitor or makes him a signer of the false statements in the court file.\n\nWitness background for Lydia Vance: Edith Shaw compares Lydia Vance's account of seeing the Mayor hide an old paper with the cabinet index recovered today. The teacher dates the sighting to a school-funding appointment entered in Edith's diary; Edith confirms she admitted her for that appointment and saw Thorne close the folder. The teacher could read receipt 47, but not the name hidden beneath his hand. This explains why the teacher questioned intrusive family records. Her chalk-marked folder and weekly lesson meetings establish access to school papers, not a signature on the falsified statements read from the court file.\n\nWitness background for Xander Hale: Edith Shaw identifies the court file's licensed likeness as Xander Hale; she compares the workshop address printed beside it with the signed shelf-repair invoice preserved in Round 2. The licensed name is Benjamin Barker. The barber's tool inventory describes an ivory razor with a chip beside the hinge, matching the blade Nell Reed saw in his hand in Round 4 and the one now on Thorne's desk. The fine stones and Harper's earlier-trade remark fit the documented occupation. The duplicate records identify the four people who helped Thorne destroy his former life. This joins identity, blade ownership and motive; the room must still decide its final accusation.\n\nWitness background for Marla Quinn: Edith Shaw checks Marla Quinn's account of an old visit by Thorne to the workshop home. The assistant remembers delivering a baker's basket there as a child; the retained delivery copy records the date and the house number. Edith compares those details with Thorne's appointment diary and confirms the visit. The account links a remembered visit to a documented place, but the assistant did not hear the conversation. Her repaired flour-marked boot still fits the closing chore established in Round 4, not a proven killing. Neither her childhood observation nor her recent bread delivery makes her one of the signers identified in the old file.\n\nThe host reads the original neighbors' recorded responses:\nXander Hale's recorded response: \"I heard Jasper Crowe's different-name rumor came from Ronan's old-license remark. His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin.\"\nMarla Quinn's recorded response: \"I learned Lydia Vance saw Thorne hide receipt 47 during her confirmed school-funding appointment. She couldn't read the name. I see why she questioned family records, not proof she falsified them.\"\nJasper Crowe's recorded response: \"I heard Edith match Xander Hale's licensed likeness and workshop address: Benjamin Barker, barber. His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse.\"\nLydia Vance's recorded response: \"I heard Edith confirm Marla Quinn's childhood delivery during Thorne's old workshop-home visit. She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot.\"\n\nThe supplied witness accounts support these comparisons:\nNell Reed identified the damaged razor in the earlier sighting.\nDella March's boot identification established work access, not print timing.\nFinn Moss's case account established an evening visit, not a witnessed murder.\nAda Bell's account left later private visitors possible.\nOwen Bell's accounts did not establish an overnight alibi.\nEdith Shaw matched the licensed likeness and address to Xander.\nTown Investigator read the retained duplicate records and Thorne's letter.\nDella's identification through Della's Granddaughter does not implicate Lydia in the old falsification.",
        "publicText": "Mayor Aldric Thorne: throat slashed; a polished razor with a chipped ivory handle on his desk. Edith Shaw identifies the cabinet and record index. Thorne's signed imprisonment order names Benjamin Barker under receipt 47. Duplicate records and his letter expose the four victims' false statements and his coercion. Witness identification follows in the player readings.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "Office clerk Edith Shaw finds Mayor Aldric Thorne in his office chair with his throat slashed, the same precise cut.",
          "A polished straight razor lies on the desk, its ivory handle chipped beside the hinge.",
          "Edith calls Nell Reed and identifies the locked cabinet from which the papers on the desk came; its numbered index and broken wax seal allow the investigator to trace their source."
        ],
        "readingGroups": [
          [
            "xander",
            "marla",
            "jasper"
          ],
          [
            "lydia"
          ],
          [
            "nell"
          ],
          [
            "della"
          ],
          [
            "finn"
          ],
          [
            "ada"
          ],
          [
            "owen"
          ],
          [
            "edith"
          ],
          [
            "investigator"
          ]
        ],
        "chain": [
          "xander",
          "marla",
          "jasper",
          "lydia",
          "nell",
          "della",
          "finn",
          "ada",
          "owen",
          "edith",
          "investigator"
        ],
        "coverageRepeat": true
      }
    ],
    "characters": [
      {
        "id": "xander",
        "name": "Xander Hale",
        "role": "Woodworker",
        "relationship": "A neighbor asked by the town investigator to help compare witness accounts of the Blackwater Row murders.",
        "tieIn": "A quiet craftsperson who repairs furniture and makes wooden fittings in a workshop off the market lane.",
        "optional": false,
        "ghost": null,
        "guest": "",
        "guestNote": "",
        "publicBlurb": "A quiet craftsperson who repairs furniture and makes wooden fittings in a workshop off the market lane.",
        "rounds": [
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I heard Nell saw {marla} leave the bakery's back door at nine with her red-handled brush. Her repaired, flour-packed heel resembles those prints. I still need their timing checked.",
              "observation": "I heard Nell saw {marla} leave the bakery's back door at nine with her red-handled brush.",
              "contradictingDetail": "Her repaired, flour-packed heel resembles those prints. I still need their timing checked."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I heard Ada saw {jasper}'s blue-strapped case on Ronan's counter at ten. His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors.",
              "observation": "I heard Ada saw {jasper}'s blue-strapped case on Ronan's counter at ten.",
              "contradictingDetail": "His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I read {marla}'s signed six-o'clock bread delivery to Harper's classroom door. Owen saw her wait by the open records drawer. I see access, but not a fatal-morning visit.",
              "observation": "I read {marla}'s signed six-o'clock bread delivery to Harper's classroom door.",
              "contradictingDetail": "Owen saw her wait by the open records drawer. I see access, but not a fatal-morning visit."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I heard {jasper}'s case rubbed the chalky desk over its flour streak. I must distinguish transferred work marks from evidence that he removed the student-record page.",
              "observation": "I heard {jasper}'s case rubbed the chalky desk over its flour streak.",
              "contradictingDetail": "I must distinguish transferred work marks from evidence that he removed the student-record page."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I read {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market. I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone.",
              "observation": "I read {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market.",
              "contradictingDetail": "I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I read {jasper}'s visit to the lamp in Della's account. I must not treat spilled oil on his sleeve as proof of a precise cut or an account of his later movements.",
              "observation": "I read {jasper}'s visit to the lamp in Della's account.",
              "contradictingDetail": "I must not treat spilled oil on his sleeve as proof of a precise cut or an account of his later movements."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I heard Edith confirm {marla}'s childhood delivery during Thorne's old workshop-home visit. She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot.",
              "observation": "I heard Edith confirm {marla}'s childhood delivery during Thorne's old workshop-home visit.",
              "contradictingDetail": "She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot."
            }
          }
        ]
      },
      {
        "id": "marla",
        "name": "Marla Quinn",
        "role": "Baker's assistant",
        "relationship": "Assistant to the first victim, the baker Elias Brim; asked to help compare witness accounts.",
        "tieIn": "Elias Brim's assistant, responsible for bread deliveries and the evening cleanup. A familiar face at doorsteps across town.",
        "optional": false,
        "ghost": null,
        "guest": "",
        "guestNote": "",
        "publicBlurb": "Elias Brim's assistant, responsible for bread deliveries and the evening cleanup. A familiar face at doorsteps across town.",
        "rounds": [
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I heard Finn saw {jasper} behind the bakery at nine-thirty with his blue-strapped case. A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave.",
              "observation": "I heard Finn saw {jasper} behind the bakery at nine-thirty with his blue-strapped case.",
              "contradictingDetail": "A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I read {xander}'s shelf invoice; Ada saw fine sharpening stones in his address-stamped sleeve. His repair cloth held amber shellac. I see another possible smear source, not proof he touched that mug.",
              "observation": "I read {xander}'s shelf invoice; Ada saw fine sharpening stones in his address-stamped sleeve.",
              "contradictingDetail": "His repair cloth held amber shellac. I see another possible smear source, not proof he touched that mug."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I read {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak. I see how marks transfer, but Owen didn't watch the yard entrance overnight.",
              "observation": "I read {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak.",
              "contradictingDetail": "I see how marks transfer, but Owen didn't watch the yard entrance overnight."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard {xander}'s drawer repair explained chalk on his cuff. I must not mistake a work mark for an explanation of the missing pages or his earlier blade skills.",
              "observation": "I heard {xander}'s drawer repair explained chalk on his cuff.",
              "contradictingDetail": "I must not mistake a work mark for an explanation of the missing pages or his earlier blade skills."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I heard Della saw {jasper} follow Tobias to the market lamp at ten. He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward.",
              "observation": "I heard Della saw {jasper} follow Tobias to the market lamp at ten.",
              "contradictingDetail": "He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard Nell identify {xander}'s chipped ivory razor. I must compare that identifiable tool with the repeated cuts, not call the sighting a confession.",
              "observation": "I heard Nell identify {xander}'s chipped ivory razor.",
              "contradictingDetail": "I must compare that identifiable tool with the repeated cuts, not call the sighting a confession."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I heard {jasper}'s different-name rumor came from Ronan's old-license remark. His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin.",
              "observation": "I heard {jasper}'s different-name rumor came from Ronan's old-license remark.",
              "contradictingDetail": "His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin."
            }
          }
        ]
      },
      {
        "id": "jasper",
        "name": "Jasper Crowe",
        "role": "Tavern musician",
        "relationship": "Musician at the tavern of the second victim, Ronan Pike; asked to help compare witness accounts.",
        "tieIn": "A musician at Ronan Pike's tavern who also plays for town events. Often out late carrying his instrument between jobs.",
        "optional": false,
        "ghost": null,
        "guest": "",
        "guestNote": "",
        "publicBlurb": "A musician at Ronan Pike's tavern who also plays for town events. Often out late carrying his instrument between jobs.",
        "rounds": [
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard Della saw Elias refuse to enter {xander}'s workshop over an old receipt. He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon.",
              "observation": "I heard Della saw Elias refuse to enter {xander}'s workshop over an old receipt.",
              "contradictingDetail": "He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I heard Della heard {marla} dispute Ronan's flour bill at seven. She showed a receipt and left toward the bakery. I can't confirm payment or a later return.",
              "observation": "I heard Della heard {marla} dispute Ronan's flour bill at seven.",
              "contradictingDetail": "She showed a receipt and left toward the bakery. I can't confirm payment or a later return."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair. Chalk explains his cuff mark to me, not missing pages or blade skills.",
              "observation": "I heard Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair.",
              "contradictingDetail": "Chalk explains his cuff mark to me, not missing pages or blade skills."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I read {marla}'s signed bread delivery at six. I must distinguish an evening delivery from a fatal-morning visit; access alone does not explain the missing page.",
              "observation": "I read {marla}'s signed bread delivery at six.",
              "contradictingDetail": "I must distinguish an evening delivery from a fatal-morning visit; access alone does not explain the missing page."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge. It went into his stamped sleeve. I worry about those precise cuts, not a confession.",
              "observation": "I heard Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge.",
              "contradictingDetail": "It went into his stamped sleeve. I worry about those precise cuts, not a confession."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I read {marla}'s closing duty to scrub the rear threshold. I must correct my earlier suspicion: flour in her repaired heel can come from work, not a witnessed killing.",
              "observation": "I read {marla}'s closing duty to scrub the rear threshold.",
              "contradictingDetail": "I must correct my earlier suspicion: flour in her repaired heel can come from work, not a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard Edith match {xander}'s licensed likeness and workshop address: Benjamin Barker, barber. His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse.",
              "observation": "I heard Edith match {xander}'s licensed likeness and workshop address: Benjamin Barker, barber.",
              "contradictingDetail": "His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse."
            }
          }
        ]
      },
      {
        "id": "lydia",
        "name": "Lydia Vance",
        "role": "Schoolteacher",
        "relationship": "Teacher working alongside the third victim, senior teacher Harper Wren; asked to help compare witness accounts.",
        "tieIn": "A teacher working alongside senior teacher Harper Wren. Attentive to local families and protective of their privacy.",
        "publicBlurb": "A teacher working alongside senior teacher Harper Wren. Attentive to local families and protective of their privacy.",
        "optional": false,
        "guest": "",
        "guestNote": "",
        "ghost": null,
        "rounds": [
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I learned Della saw Elias refuse to enter {xander}'s workshop over an old receipt. He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon.",
              "observation": "I learned Della saw Elias refuse to enter {xander}'s workshop over an old receipt.",
              "contradictingDetail": "He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I learned Della heard {marla} dispute Ronan's flour bill at seven. She showed a receipt and left toward the bakery. I can't confirm payment or a later return.",
              "observation": "I learned Della heard {marla} dispute Ronan's flour bill at seven.",
              "contradictingDetail": "She showed a receipt and left toward the bakery. I can't confirm payment or a later return."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I checked {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak. I see how marks transfer, but Owen didn't watch the yard entrance overnight.",
              "observation": "I checked {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak.",
              "contradictingDetail": "I see how marks transfer, but Owen didn't watch the yard entrance overnight."
            }
          },
          {
            "readAloud": {
              "accuses": "nell",
              "text": "I heard the account: {nell} recorded a chalk smear and narrow drag line through it. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: {nell} recorded a chalk smear and narrow drag line through it.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "della",
              "text": "I heard the account: {della} saw Jasper holding the flask before oil spilled on his sleeve. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {della} saw Jasper holding the flask before oil spilled on his sleeve.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "finn",
              "text": "I heard the account: {finn} left for the delivery cart without witnessing the bakery death. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: {finn} left for the delivery cart without witnessing the bakery death.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "ada",
              "text": "I heard the account: {ada}'s account left later private visitors possible. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {ada}'s account left later private visitors possible.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          }
        ]
      },
      {
        "id": "nell",
        "name": "Nell Reed",
        "role": "Night watchwoman",
        "relationship": "An existing person in the supplied Blackwater Row accounts.",
        "tieIn": "Records the scene findings and supplies the razor sighting.",
        "publicBlurb": "Records the scene findings and supplies the razor sighting.",
        "optional": false,
        "guest": "",
        "guestNote": "",
        "ghost": null,
        "rounds": [
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I learned Nell saw {marla} leave the bakery's back door at nine with her red-handled brush. Her repaired, flour-packed heel resembles those prints. I still need their timing checked.",
              "observation": "I learned Nell saw {marla} leave the bakery's back door at nine with her red-handled brush.",
              "contradictingDetail": "Her repaired, flour-packed heel resembles those prints. I still need their timing checked."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I learned Ada saw {jasper}'s blue-strapped case on Ronan's counter at ten. His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors.",
              "observation": "I learned Ada saw {jasper}'s blue-strapped case on Ronan's counter at ten.",
              "contradictingDetail": "His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors."
            }
          },
          {
            "readAloud": {
              "accuses": "lydia",
              "text": "I learned Owen saw {lydia}'s green folder in Harper's classroom at six, discussing pupil privacy. Its chalk matches the desk height. I worry about access, but Owen left at seven.",
              "observation": "I learned Owen saw {lydia}'s green folder in Harper's classroom at six, discussing pupil privacy.",
              "contradictingDetail": "Its chalk matches the desk height. I worry about access, but Owen left at seven."
            }
          },
          {
            "readAloud": {
              "accuses": "della",
              "text": "I heard the account: {della} identified Lydia and the topic of the bakery argument. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: {della} identified Lydia and the topic of the bakery argument.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "finn",
              "text": "I heard the account: {finn} left for the delivery cart without witnessing the bakery death. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {finn} left for the delivery cart without witnessing the bakery death.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "ada",
              "text": "I heard the account: {ada} saw the blue-strapped case on Ronan's counter at ten. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: {ada} saw the blue-strapped case on Ronan's counter at ten.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "owen",
              "text": "I heard the account: {owen}'s accounts did not establish an overnight alibi. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {owen}'s accounts did not establish an overnight alibi.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          }
        ]
      },
      {
        "id": "della",
        "name": "Della March",
        "role": "Cobbler",
        "relationship": "An existing person in the supplied Blackwater Row accounts.",
        "tieIn": "Identifies the repaired boot and the neighbors in her recorded accounts.",
        "publicBlurb": "Identifies the repaired boot and the neighbors in her recorded accounts.",
        "optional": false,
        "guest": "",
        "guestNote": "",
        "ghost": null,
        "rounds": [
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I learned Finn saw {jasper} behind the bakery at nine-thirty with his blue-strapped case. A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave.",
              "observation": "I learned Finn saw {jasper} behind the bakery at nine-thirty with his blue-strapped case.",
              "contradictingDetail": "A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave."
            }
          },
          {
            "readAloud": {
              "accuses": "lydia",
              "text": "I learned Ada heard {lydia} warn Ronan about recording families at eight. She touched his book, leaving possible chalk. I can't prove a removed page or a later return.",
              "observation": "I learned Ada heard {lydia} warn Ronan about recording families at eight.",
              "contradictingDetail": "She touched his book, leaving possible chalk. I can't prove a removed page or a later return."
            }
          },
          {
            "readAloud": {
              "accuses": "nell",
              "text": "I heard the account: {nell} recorded a chalk smear and narrow drag line through it. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {nell} recorded a chalk smear and narrow drag line through it.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "finn",
              "text": "I heard the account: {finn} heard a promised parcel requested but saw no handover. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: {finn} heard a promised parcel requested but saw no handover.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "ada",
              "text": "I heard the account: {ada} saw the blue-strapped case on Ronan's counter at ten. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {ada} saw the blue-strapped case on Ronan's counter at ten.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "owen",
              "text": "I heard the account: {owen} left at seven without watching the separate yard entrance overnight. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: {owen} left at seven without watching the separate yard entrance overnight.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "edith",
              "text": "I heard the account: {edith} matched the licensed likeness and address to Xander. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {edith} matched the licensed likeness and address to Xander.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          }
        ]
      },
      {
        "id": "finn",
        "name": "Finn Moss",
        "role": "Delivery porter",
        "relationship": "An existing person in the supplied Blackwater Row accounts.",
        "tieIn": "Finds Elias and reports the musician waiting behind the bakery.",
        "publicBlurb": "Finds Elias and reports the musician waiting behind the bakery.",
        "optional": false,
        "guest": "",
        "guestNote": "",
        "ghost": null,
        "rounds": [
          {
            "readAloud": {
              "accuses": "lydia",
              "text": "I learned Della saw {lydia} argue with Elias that morning, her green lesson folder tucked under her arm. A bread bill held family history. I wonder why he folded that paper.",
              "observation": "I learned Della saw {lydia} argue with Elias that morning, her green lesson folder tucked under her arm.",
              "contradictingDetail": "A bread bill held family history. I wonder why he folded that paper."
            }
          },
          {
            "readAloud": {
              "accuses": "nell",
              "text": "I heard the account: {nell} recorded a wiped mug without usable fingerprints. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {nell} recorded a wiped mug without usable fingerprints.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "della",
              "text": "I heard the account: {della} identified Lydia and the topic of the bakery argument. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {della} identified Lydia and the topic of the bakery argument.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "ada",
              "text": "I heard the account: {ada} saw the fine stones in an address-stamped sleeve. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: {ada} saw the fine stones in an address-stamped sleeve.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "owen",
              "text": "I heard the account: {owen} left at seven without watching the separate yard entrance overnight. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {owen} left at seven without watching the separate yard entrance overnight.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "edith",
              "text": "I heard the account: {edith} has not supplied an office account at this stage. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: {edith} has not supplied an office account at this stage.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "investigator",
              "text": "I heard the account: {investigator} read the retained duplicate records and Thorne's letter. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {investigator} read the retained duplicate records and Thorne's letter.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          }
        ]
      },
      {
        "id": "ada",
        "name": "Ada Bell",
        "role": "Tavern cleaner",
        "relationship": "An existing person in the supplied Blackwater Row accounts.",
        "tieIn": "Finds Ronan and reports the tavern objects and appointments.",
        "publicBlurb": "Finds Ronan and reports the tavern objects and appointments.",
        "optional": false,
        "guest": "",
        "guestNote": "",
        "ghost": null,
        "rounds": [
          {
            "readAloud": {
              "accuses": "nell",
              "text": "I heard the account: {nell} recorded flour prints with a crescent gap in the right heel. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {nell} recorded flour prints with a crescent gap in the right heel.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "della",
              "text": "I heard the account: {della} heard Marla dispute the flour bill and leave toward the bakery. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {della} heard Marla dispute the flour bill and leave toward the bakery.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "finn",
              "text": "I heard the account: {finn} heard a promised parcel requested but saw no handover. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {finn} heard a promised parcel requested but saw no handover.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "owen",
              "text": "I heard the account: {owen} found Harper, locked the classroom and fetched Nell. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: {owen} found Harper, locked the classroom and fetched Nell.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "edith",
              "text": "I heard the account: {edith} has not supplied an office account at this stage. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {edith} has not supplied an office account at this stage.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "investigator",
              "text": "I heard the account: {investigator} preserved the earlier work records for timing comparisons. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: {investigator} preserved the earlier work records for timing comparisons.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I learned Edith match {xander}'s licensed likeness and workshop address: Benjamin Barker, barber. His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse.",
              "observation": "I learned Edith match {xander}'s licensed likeness and workshop address: Benjamin Barker, barber.",
              "contradictingDetail": "His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse."
            }
          }
        ]
      },
      {
        "id": "owen",
        "name": "Owen Bell",
        "role": "School caretaker",
        "relationship": "An existing person in the supplied Blackwater Row accounts.",
        "tieIn": "Finds Harper and supplies the school visit accounts and records.",
        "publicBlurb": "Finds Harper and supplies the school visit accounts and records.",
        "optional": false,
        "guest": "",
        "guestNote": "",
        "ghost": null,
        "rounds": [
          {
            "readAloud": {
              "accuses": "della",
              "text": "I heard the account: {della} recognized the repaired boot from its collection yesterday. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {della} recognized the repaired boot from its collection yesterday.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "finn",
              "text": "I heard the account: {finn} did not witness the bakery death or the musician leaving. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {finn} did not witness the bakery death or the musician leaving.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "ada",
              "text": "I heard the account: {ada} saw the fine stones in an address-stamped sleeve. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {ada} saw the fine stones in an address-stamped sleeve.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "edith",
              "text": "I heard the account: {edith} has not supplied an office account at this stage. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: {edith} has not supplied an office account at this stage.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "investigator",
              "text": "I heard the account: {investigator} preserved the earlier work records for timing comparisons. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {investigator} preserved the earlier work records for timing comparisons.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I learned Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge. It went into his stamped sleeve. I worry about those precise cuts, not a confession.",
              "observation": "I learned Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge.",
              "contradictingDetail": "It went into his stamped sleeve. I worry about those precise cuts, not a confession."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I learned Edith confirm {marla}'s childhood delivery during Thorne's old workshop-home visit. She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot.",
              "observation": "I learned Edith confirm {marla}'s childhood delivery during Thorne's old workshop-home visit.",
              "contradictingDetail": "She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot."
            }
          }
        ]
      },
      {
        "id": "edith",
        "name": "Edith Shaw",
        "role": "Office clerk",
        "relationship": "An existing person in the supplied Blackwater Row accounts.",
        "tieIn": "Finds Thorne and traces the final documents to the office cabinet.",
        "publicBlurb": "Finds Thorne and traces the final documents to the office cabinet.",
        "optional": false,
        "guest": "",
        "guestNote": "",
        "ghost": null,
        "rounds": [
          {
            "readAloud": {
              "accuses": "finn",
              "text": "I heard the account: {finn} found Elias and called Nell before anyone entered the yard. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {finn} found Elias and called Nell before anyone entered the yard.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "ada",
              "text": "I heard the account: {ada} found Ronan and left the mug untouched. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {ada} found Ronan and left the mug untouched.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "owen",
              "text": "I heard the account: {owen} found Harper, locked the classroom and fetched Nell. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {owen} found Harper, locked the classroom and fetched Nell.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "investigator",
              "text": "I heard the account: {investigator} connected three disturbed records by receipt 47. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: {investigator} connected three disturbed records by receipt 47.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I learned Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge. It went into his stamped sleeve. I worry about those precise cuts, not a confession.",
              "observation": "I learned Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge.",
              "contradictingDetail": "It went into his stamped sleeve. I worry about those precise cuts, not a confession."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I checked {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market. I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone.",
              "observation": "I checked {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market.",
              "contradictingDetail": "I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I learned {jasper}'s different-name rumor came from Ronan's old-license remark. His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin.",
              "observation": "I learned {jasper}'s different-name rumor came from Ronan's old-license remark.",
              "contradictingDetail": "His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin."
            }
          }
        ]
      },
      {
        "id": "investigator",
        "name": "Town Investigator",
        "role": "Investigator",
        "relationship": "An existing person in the supplied Blackwater Row accounts.",
        "tieIn": "Compares the supplied findings and records. No additional discoveries are authored for this role.",
        "publicBlurb": "Compares the supplied findings and records. No additional discoveries are authored for this role.",
        "optional": false,
        "guest": "",
        "guestNote": "",
        "ghost": null,
        "rounds": [
          {
            "readAloud": {
              "accuses": "ada",
              "text": "I heard the account: {ada} has not supplied a tavern account at this stage. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {ada} has not supplied a tavern account at this stage.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "owen",
              "text": "I heard the account: {owen} has not supplied a classroom account at this stage. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {owen} has not supplied a classroom account at this stage.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "edith",
              "text": "I heard the account: {edith} has not supplied an office account at this stage. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {edith} has not supplied an office account at this stage.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I learned Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair. Chalk explains his cuff mark to me, not missing pages or blade skills.",
              "observation": "I learned Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair.",
              "contradictingDetail": "Chalk explains his cuff mark to me, not missing pages or blade skills."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I checked {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market. I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone.",
              "observation": "I checked {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market.",
              "contradictingDetail": "I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I learned Della saw {jasper} follow Tobias to the market lamp at ten. He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward.",
              "observation": "I learned Della saw {jasper} follow Tobias to the market lamp at ten.",
              "contradictingDetail": "He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward."
            }
          },
          {
            "readAloud": {
              "accuses": "lydia",
              "text": "I heard {lydia} saw Thorne hide receipt 47 during her confirmed school-funding appointment. She couldn't read the name. I see why she questioned family records, not proof she falsified them.",
              "observation": "I heard {lydia} saw Thorne hide receipt 47 during her confirmed school-funding appointment.",
              "contradictingDetail": "She couldn't read the name. I see why she questioned family records, not proof she falsified them."
            }
          }
        ]
      }
    ],
    "finale": {
      "narration": "All seven chapters and the final witness accounts have now been read. Compare the identified blade, the licensed likeness and address, and the duplicate records with the earlier observations. Decide which neighbor accounts for the complete chain, not just one suspicious trace. A reason for revenge can explain a crime without excusing it. Make your final accusation before the investigator announces the solution.",
      "votePrompt": "Who do you accuse based on the evidence heard so far?"
    },
    "solution": {
      "killerId": "xander",
      "explanation": "Xander Hale is Benjamin Barker, formerly Blackwater Row's trusted barber, and he committed all five murders. Thorne's letter and court file, first read in Round 7, establish that the Mayor wanted Barker's wife, framed him, ordered his imprisonment and forced her into his household. Elias's false delivery entry, Ronan's invented confession, Harper's altered household record and Tobias's false night sighting helped destroy Barker's married life. After release, Barker returned as the woodworker Xander Hale. The fine stones in his address-stamped sleeve and Harper's earlier-trade remark established a blade skill without naming it. Nell's direct observation of the chipped ivory razor in Round 5 supplied identifiable ownership; Edith's Round 7 comparison joined that razor, the licensed likeness and the repair invoice to the old identity. Receipt 47 linked the disturbed records; retained duplicates explained the target selection. Marla's repaired flour-marked boot had a documented closing-chore source. Jasper's case and rosin and Lydia's folder and chalk had witnessed work-related sources; their movements raised questions but did not explain the complete identity, weapon and motive chain. No stain alone proved a killing. Barker killed the four accomplices before reaching his final target, the Mayor. This was deliberate revenge, not justice.",
      "revealNarration": "The investigator closes the court file. \"The killer is {xander}. His former name was Benjamin Barker, and his former trade was barber. Nell identified the damaged razor in his hand; Edith matched the license and address to his current work. The earlier victims supplied the false statements that destroyed his former life. Thorne was his final target.\"\n\nThe host may read Barker's final words: \"Once this town knew me as Benjamin Barker. I had a trade, a wife and a home. Thorne wanted what was not his, and four respectable voices made his lie sound like law. When I returned, I called myself Xander Hale and worked in wood. I thought a new name could bury the old one. Instead I carried it through every door. I chose revenge, and I killed them. It did not restore my wife's freedom or the years we lost. Nothing they did makes these murders right.\"\n\nBlackwater Row must now reckon with both the original injustice and the five deaths that followed."
    },
    "masterPreserving": true,
    "conversion": {
      "source": "Committed four-player Blackwater Row revision 3.",
      "changes": [
        {
          "original": "Five discovery chapters and four playable neighbors.",
          "replacement": "Five unchanged discovery sequences with two intervening comparison chapters and a three-player core.",
          "reason": "Seven-round requirement and smallest-edition master. Identity remains in the last discovery chapter; no murders or facts are added."
        },
        {
          "original": "Per-chapter four-player reader handoffs and twenty player responses.",
          "replacement": "Named recorded responses in shared narration and count-specific group order.",
          "reason": "Preserve every witness source and original response while selecting a three-player loop."
        },
        {
          "original": "Solution timing references to Round 4 and Round 5.",
          "replacement": "Corresponding seven-chapter references to Round 5 and Round 7.",
          "reason": "Inserted comparison rounds shift chapter numbers without advancing evidence."
        }
      ],
      "originalResponses": [
        {
          "id": "xander",
          "rounds": [
            {
              "readAloud": {
                "accuses": "marla",
                "text": "I heard Nell saw {marla} leave the bakery's back door at nine with her red-handled brush. Her repaired, flour-packed heel resembles those prints. I still need their timing checked.",
                "observation": "I heard Nell saw {marla} leave the bakery's back door at nine with her red-handled brush.",
                "contradictingDetail": "Her repaired, flour-packed heel resembles those prints. I still need their timing checked."
              }
            },
            {
              "readAloud": {
                "accuses": "jasper",
                "text": "I heard Ada saw {jasper}'s blue-strapped case on Ronan's counter at ten. His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors.",
                "observation": "I heard Ada saw {jasper}'s blue-strapped case on Ronan's counter at ten.",
                "contradictingDetail": "His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors."
              }
            },
            {
              "readAloud": {
                "accuses": "lydia",
                "text": "I heard Owen saw {lydia}'s green folder in Harper's classroom at six, discussing pupil privacy. Its chalk matches the desk height. I worry about access, but Owen left at seven.",
                "observation": "I heard Owen saw {lydia}'s green folder in Harper's classroom at six, discussing pupil privacy.",
                "contradictingDetail": "Its chalk matches the desk height. I worry about access, but Owen left at seven."
              }
            },
            {
              "readAloud": {
                "accuses": "marla",
                "text": "I read {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market. I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone.",
                "observation": "I read {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market.",
                "contradictingDetail": "I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone."
              }
            },
            {
              "readAloud": {
                "accuses": "jasper",
                "text": "I heard {jasper}'s different-name rumor came from Ronan's old-license remark. His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin.",
                "observation": "I heard {jasper}'s different-name rumor came from Ronan's old-license remark.",
                "contradictingDetail": "His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin."
              }
            }
          ]
        },
        {
          "id": "marla",
          "rounds": [
            {
              "readAloud": {
                "accuses": "jasper",
                "text": "I heard Finn saw {jasper} behind the bakery at nine-thirty with his blue-strapped case. A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave.",
                "observation": "I heard Finn saw {jasper} behind the bakery at nine-thirty with his blue-strapped case.",
                "contradictingDetail": "A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave."
              }
            },
            {
              "readAloud": {
                "accuses": "lydia",
                "text": "I heard Ada heard {lydia} warn Ronan about recording families at eight. She touched his book, leaving possible chalk. I can't prove a removed page or a later return.",
                "observation": "I heard Ada heard {lydia} warn Ronan about recording families at eight.",
                "contradictingDetail": "She touched his book, leaving possible chalk. I can't prove a removed page or a later return."
              }
            },
            {
              "readAloud": {
                "accuses": "xander",
                "text": "I heard Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair. Chalk explains his cuff mark to me, not missing pages or blade skills.",
                "observation": "I heard Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair.",
                "contradictingDetail": "Chalk explains his cuff mark to me, not missing pages or blade skills."
              }
            },
            {
              "readAloud": {
                "accuses": "jasper",
                "text": "I heard Della saw {jasper} follow Tobias to the market lamp at ten. He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward.",
                "observation": "I heard Della saw {jasper} follow Tobias to the market lamp at ten.",
                "contradictingDetail": "He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward."
              }
            },
            {
              "readAloud": {
                "accuses": "lydia",
                "text": "I learned {lydia} saw Thorne hide receipt 47 during her confirmed school-funding appointment. She couldn't read the name. I see why she questioned family records, not proof she falsified them.",
                "observation": "I learned {lydia} saw Thorne hide receipt 47 during her confirmed school-funding appointment.",
                "contradictingDetail": "She couldn't read the name. I see why she questioned family records, not proof she falsified them."
              }
            }
          ]
        },
        {
          "id": "jasper",
          "rounds": [
            {
              "readAloud": {
                "accuses": "lydia",
                "text": "I heard Della saw {lydia} argue with Elias that morning, her green lesson folder tucked under her arm. A bread bill held family history. I wonder why he folded that paper.",
                "observation": "I heard Della saw {lydia} argue with Elias that morning, her green lesson folder tucked under her arm.",
                "contradictingDetail": "A bread bill held family history. I wonder why he folded that paper."
              }
            },
            {
              "readAloud": {
                "accuses": "xander",
                "text": "I read {xander}'s shelf invoice; Ada saw fine sharpening stones in his address-stamped sleeve. His repair cloth held amber shellac. I see another possible smear source, not proof he touched that mug.",
                "observation": "I read {xander}'s shelf invoice; Ada saw fine sharpening stones in his address-stamped sleeve.",
                "contradictingDetail": "His repair cloth held amber shellac. I see another possible smear source, not proof he touched that mug."
              }
            },
            {
              "readAloud": {
                "accuses": "marla",
                "text": "I read {marla}'s signed six-o'clock bread delivery to Harper's classroom door. Owen saw her wait by the open records drawer. I see access, but not a fatal-morning visit.",
                "observation": "I read {marla}'s signed six-o'clock bread delivery to Harper's classroom door.",
                "contradictingDetail": "Owen saw her wait by the open records drawer. I see access, but not a fatal-morning visit."
              }
            },
            {
              "readAloud": {
                "accuses": "lydia",
                "text": "I read {lydia}'s warning to Tobias: children's family affairs don't belong in street notes. Her weekly lesson meetings explain contact to me, not an overnight alibi or receipt 47's torn page.",
                "observation": "I read {lydia}'s warning to Tobias: children's family affairs don't belong in street notes.",
                "contradictingDetail": "Her weekly lesson meetings explain contact to me, not an overnight alibi or receipt 47's torn page."
              }
            },
            {
              "readAloud": {
                "accuses": "xander",
                "text": "I heard Edith match {xander}'s licensed likeness and workshop address: Benjamin Barker, barber. His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse.",
                "observation": "I heard Edith match {xander}'s licensed likeness and workshop address: Benjamin Barker, barber.",
                "contradictingDetail": "His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse."
              }
            }
          ]
        },
        {
          "id": "lydia",
          "rounds": [
            {
              "readAloud": {
                "accuses": "xander",
                "text": "I heard Della saw Elias refuse to enter {xander}'s workshop over an old receipt. He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon.",
                "observation": "I heard Della saw Elias refuse to enter {xander}'s workshop over an old receipt.",
                "contradictingDetail": "He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon."
              }
            },
            {
              "readAloud": {
                "accuses": "marla",
                "text": "I heard Della heard {marla} dispute Ronan's flour bill at seven. She showed a receipt and left toward the bakery. I can't confirm payment or a later return.",
                "observation": "I heard Della heard {marla} dispute Ronan's flour bill at seven.",
                "contradictingDetail": "She showed a receipt and left toward the bakery. I can't confirm payment or a later return."
              }
            },
            {
              "readAloud": {
                "accuses": "jasper",
                "text": "I read {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak. I see how marks transfer, but Owen didn't watch the yard entrance overnight.",
                "observation": "I read {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak.",
                "contradictingDetail": "I see how marks transfer, but Owen didn't watch the yard entrance overnight."
              }
            },
            {
              "readAloud": {
                "accuses": "xander",
                "text": "I heard Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge. It went into his stamped sleeve. I worry about those precise cuts, not a confession.",
                "observation": "I heard Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge.",
                "contradictingDetail": "It went into his stamped sleeve. I worry about those precise cuts, not a confession."
              }
            },
            {
              "readAloud": {
                "accuses": "marla",
                "text": "I heard Edith confirm {marla}'s childhood delivery during Thorne's old workshop-home visit. She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot.",
                "observation": "I heard Edith confirm {marla}'s childhood delivery during Thorne's old workshop-home visit.",
                "contradictingDetail": "She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot."
              }
            }
          ]
        }
      ]
    }
  },
  "12": {
    "schemaVersion": 2,
    "fixedPlayerCount": 12,
    "discloseKiller": false,
    "clueRouting": "rotating",
    "edition": {
      "family": "blackwater-scalable",
      "id": "blackwater-scalable-12-players",
      "playerCount": 12,
      "revision": 1
    },
    "title": "The Barber of Blackwater Row",
    "atmosphere": "victorian",
    "setting": "Blackwater Row, a riverside town of workshops, narrow lanes and gaslit streets in the late nineteenth century.",
    "intro": "Evening settles over Blackwater Row. Three neighbors help the town investigator compare the supplied accounts: Xander Hale, the woodworker; Marla Quinn, the baker's assistant; and Jasper Crowe, the tavern musician. The host reads every recorded witness account before the players respond. Other named people remain in the evidence even when they are not playable. Discuss only the chapter just heard; nobody invents a history, witnesses a new discovery or improvises a private part.",
    "hiddenThread": "Receipt 47 recurs in every victim's disturbed records and finally names the Mayor's old imprisonment order against Benjamin Barker.",
    "coverageRepeatNote": "The trio covers all six directed pairs in the first two rounds. Later repeats add released evidence or explicitly correct an unsupported earlier inference. Each supplemental reader targets every other selected character before repeating, never in consecutive rounds. Separate singleton readings preserve the master loop and evidence timing.",
    "specialMechanics": [
      "Receipt 47 ledger: each murder surfaces another record indexed under receipt 47 (delivery log, tavern scrap, student-record index, night-route page). Compare them across rounds; the Mayor's signed order in Round 7 finally connects the series to the old case."
    ],
    "victim": {
      "name": "Elias Brim",
      "description": "The town baker, known for dependable bread deliveries and careful records."
    },
    "rounds": [
      {
        "title": "Round 1 - The Baker's Murder",
        "narration": "At dawn, delivery porter Finn Moss finds Elias Brim behind his bakery with his throat slashed. The investigator reports one clean, precise cut; the death happened off-screen. Elias supplied nearly every doorstep and recorded deliveries and closing chores in separate books. Finn calls night watchwoman Nell Reed before anyone enters the yard. She records a chain of flour prints from the back door to the wet cobbles. Each right print has a crescent-shaped gap at the heel; the cobbles preserve nothing beyond it. A page is torn from an older delivery log. Its surviving edge carries the date and part of receipt 47, but not a customer name or the purpose of the entry. The closing-duty sheet is intact and is kept for later comparison. These are the findings at this scene, not an identification of the killer. The investigator has collected four separate accounts about the neighbors.  Hear all four before discussing which details establish access and which merely raise suspicion.\n\nThe investigator reads the supporting witness accounts before calling on the selected readers:\n\nWitness background for Marla Quinn: Nell Reed saw Marla Quinn leave the bakery back door at nine, carrying her red-handled scrubbing brush. Nell recognized the brass buckle and crescent-shaped repair in the right heel of her work boots because cobbler Della March had shown her that repair at collection yesterday. Flour was packed into the repaired heel. The shape resembles the yard prints recorded this morning. This ties the boots to bakery work and the doorway, but does not date when each print was made. The closing-duty sheet has not yet been checked against the sighting.\n\nWitness background for Jasper Crowe: Finn Moss saw Jasper Crowe waiting behind the bakery at half past nine, with a blue-strapped instrument case propped against the wall. Finn recognized the musician from the tavern and the case from carrying it after last week's performance. A pale streak ran across its lower corner where it touched a flour sack outside the door. Finn heard him ask Elias for a promised parcel, but did not see a parcel handed over or hear what it contained. Finn left for the delivery cart; he did not witness the death or the musician's departure.\n\nWitness background for Lydia Vance: Della March saw Lydia Vance arguing with Elias at the bakery front counter that morning. She recognized the teacher from collecting her granddaughter from school and saw the same green lesson folder under her arm. Della heard the teacher ask why a bread bill included a household's personal history. Elias folded a paper and refused to answer. The teacher left a chalky thumb mark on the counter when she leaned forward. Della identifies the person and the topic, but heard no threat and never saw the contents of the folded paper.\n\nWitness background for Xander Hale: Della March delivered a wooden chair to Xander Hale's workshop last week and saw Elias at the open door. She recognized both men from their regular work at her market stall. Elias refused to enter and said, \"I will not bring that old receipt here again.\" The woodworker stopped sanding, gripped the chair rail and asked which book Elias meant. Della saw fresh amber shellac on his apron beside the repair cloth, but no weapon. She can identify the reaction and the receipt dispute; she cannot identify the old transaction or turn that reaction into proof of murder.\n\nThe host reads the original neighbors' recorded responses:\nXander Hale's recorded response: \"I heard Nell saw Marla Quinn leave the bakery's back door at nine with her red-handled brush. Her repaired, flour-packed heel resembles those prints. I still need their timing checked.\"\nMarla Quinn's recorded response: \"I heard Finn saw Jasper Crowe behind the bakery at nine-thirty with his blue-strapped case. A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave.\"\nJasper Crowe's recorded response: \"I heard Della saw Lydia Vance argue with Elias that morning, her green lesson folder tucked under her arm. A bread bill held family history. I wonder why he folded that paper.\"\nLydia Vance's recorded response: \"I heard Della saw Elias refuse to enter Xander Hale's workshop over an old receipt. He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon.\"\n\nThe supplied witness accounts support these comparisons:\nNell Reed recorded flour prints with a crescent gap in the right heel.\nDella March recognized the repaired boot from its collection yesterday.\nFinn Moss found Elias and called Nell before anyone entered the yard.\nAda Bell has not supplied a tavern account at this stage.\nOwen Bell has not supplied a classroom account at this stage.\nEdith Shaw has not supplied an office account at this stage.\nTown Investigator reported one precise cut at the bakery.\nDella recognized Lydia through collecting Della's Granddaughter from school.",
        "publicText": "Elias Brim: throat slashed with one precise cut. Finn Moss found the body; Nell Reed recorded flour prints with a crescent gap in the right heel. An old delivery-log page is torn; only receipt 47 survives at its edge. The closing-duty sheet is intact.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "At dawn, delivery porter Finn Moss finds Elias Brim behind his bakery with his throat slashed.",
          "The investigator reports one clean, precise cut; the death happened off-screen.",
          "Elias supplied nearly every doorstep and recorded deliveries and closing chores in separate books."
        ],
        "readingGroups": [
          [
            "xander",
            "marla",
            "jasper"
          ],
          [
            "lydia"
          ],
          [
            "nell"
          ],
          [
            "della"
          ],
          [
            "finn"
          ],
          [
            "ada"
          ],
          [
            "owen"
          ],
          [
            "edith"
          ],
          [
            "investigator"
          ],
          [
            "pupil"
          ]
        ],
        "chain": [
          "xander",
          "marla",
          "jasper",
          "lydia",
          "nell",
          "della",
          "finn",
          "ada",
          "owen",
          "edith",
          "investigator",
          "pupil"
        ],
        "coverageRepeat": false
      },
      {
        "title": "Round 2 - The Barkeep's Murder",
        "narration": "The next morning, cleaner Ada Bell finds Ronan Pike slumped over his tavern counter with his throat slashed. The investigator records the same precise cut as at the bakery. Ronan kept accounts of debts and stayed late for private appointments. Ada does not touch the mug beside him; Nell Reed records that it has been wiped and has no usable fingerprints. A thin amber smear remains beneath its handle. No owner has been established for the mug or the smear. Beneath Ronan's account book lies a scrap bearing receipt 47 and four lines of dates. No names or explanation survive on the scrap. The matching number links two sets of records, but does not identify their subject. Ronan's service tally and appointment book are preserved separately so that the last drink served will not be confused with the last visitor admitted. Four witness accounts are ready.  Listen for who saw an object, how they identified its owner and whether their timing actually reaches the death.\n\nThe investigator reads the supporting witness accounts before calling on the selected readers:\n\nWitness background for Jasper Crowe: Ada Bell saw Jasper Crowe put his instrument case on Ronan's counter at ten and leave after the last public drink was served. She recognized the case by its repaired blue strap, which she had sewn herself. He uses amber rosin on his bow; Ada collected a flake from the spot where the case rested. Its color resembles the smear beneath the wiped mug, but color alone cannot establish that they are the same material. Ronan locked the public door afterward; Ada did not watch the side entrance or the later appointments.\n\nWitness background for Lydia Vance: Ada Bell heard Lydia Vance tell Ronan at eight, \"Those are dangerous notes; people did not give you permission to record their families.\" Ada recognized the green lesson folder under the teacher's arm from her school-cleaning rounds. The teacher tapped Ronan's account book, leaving a white powder trace on its dark cover. Ada collected it as a possible chalk transfer, not a laboratory identification. The warning concerns records, but Ada saw no page removed. The teacher walked out through the public door; Ada could not observe who returned later.\n\nWitness background for Xander Hale: Ronan's repair invoice records Xander Hale replacing the tavern shelf last week. Ada Bell identified him from the signed invoice and saw him open a leather tool sleeve stamped with the same workshop address. Inside were sharpening stones Ronan called \"too fine for woodworking\": one was much narrower and smoother than the broad stone used on the shelf chisel. Ada saw him wipe the sleeve with an amber shellac-stained cloth from his repair kit. That establishes ownership of the stones and a second possible source of amber residue; it does not prove who handled the wiped mug on the night of the murder.\n\nWitness background for Marla Quinn: Della March heard Marla Quinn dispute an unpaid flour bill with Ronan outside the tavern at seven. She recognized the baker's assistant by the stamped delivery basket she was carrying. Ronan held a bill with a torn lower corner; the assistant produced a coin receipt, but Della was too far away to compare its amount. She saw the assistant leave with the basket toward the bakery. The argument supplies a specific grievance and an observed departure, not proof of payment or a witnessed return to the counter where Ronan died.\n\nThe host reads the original neighbors' recorded responses:\nXander Hale's recorded response: \"I heard Ada saw Jasper Crowe's blue-strapped case on Ronan's counter at ten. His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors.\"\nMarla Quinn's recorded response: \"I heard Ada heard Lydia Vance warn Ronan about recording families at eight. She touched his book, leaving possible chalk. I can't prove a removed page or a later return.\"\nJasper Crowe's recorded response: \"I read Xander Hale's shelf invoice; Ada saw fine sharpening stones in his address-stamped sleeve. His repair cloth held amber shellac. I see another possible smear source, not proof he touched that mug.\"\nLydia Vance's recorded response: \"I heard Della heard Marla Quinn dispute Ronan's flour bill at seven. She showed a receipt and left toward the bakery. I can't confirm payment or a later return.\"\n\nThe supplied witness accounts support these comparisons:\nNell Reed recorded a wiped mug without usable fingerprints.\nDella March heard Marla dispute the flour bill and leave toward the bakery.\nFinn Moss did not witness the bakery death or the musician leaving.\nAda Bell found Ronan and left the mug untouched.\nOwen Bell has not supplied a classroom account at this stage.\nEdith Shaw has not supplied an office account at this stage.\nTown Investigator reported the same precise cut at the tavern.\nDella's school collection of Della's Granddaughter explains her recognition of Lydia.",
        "publicText": "Ronan Pike: throat slashed with the same precise cut. Ada Bell found him. A wiped mug has no usable fingerprints and an unidentified amber smear beneath its handle. A dated scrap bears receipt 47 but no names. Service and appointment records are preserved.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "The next morning, cleaner Ada Bell finds Ronan Pike slumped over his tavern counter with his throat slashed.",
          "The investigator records the same precise cut as at the bakery.",
          "Ronan kept accounts of debts and stayed late for private appointments."
        ],
        "readingGroups": [
          [
            "xander",
            "jasper",
            "marla"
          ],
          [
            "lydia"
          ],
          [
            "nell"
          ],
          [
            "della"
          ],
          [
            "finn"
          ],
          [
            "ada"
          ],
          [
            "owen"
          ],
          [
            "edith"
          ],
          [
            "investigator"
          ],
          [
            "pupil"
          ]
        ],
        "chain": [
          "xander",
          "jasper",
          "marla",
          "lydia",
          "nell",
          "della",
          "finn",
          "ada",
          "owen",
          "edith",
          "investigator",
          "pupil"
        ],
        "coverageRepeat": false
      },
      {
        "title": "Round 3 - The Schoolteacher's Murder",
        "narration": "Before sunrise, caretaker Owen Bell finds senior teacher Harper Wren in her classroom with her throat slashed, the same precise cut again. Harper taught most of the town's children and kept family records as carefully as lesson plans. Owen locks the room and fetches Nell Reed. She records a broad chalk smear across the desk and a narrow drag line through it, running from the student-record book toward its open drawer. A page is missing from that book. Its remaining index cites receipt 47; a margin note says, \"Copy kept with the original order.\" Neither the order's owner nor its location is recorded here. Owen also hands over the fundraiser attendance sheet and Harper's lesson diary, both intact. Three disturbed records now share a number. That is a link worth following, not yet an explanation.  Compare observed visits with the traces on the desk, and keep the identity of any missing document separate from guesses about it.\n\nThe investigator reads the supporting witness accounts before calling on the selected readers:\n\nWitness background for Lydia Vance: Owen Bell saw Lydia Vance enter Harper's classroom at six carrying her green lesson folder. He recognized her name written inside its cover when she left it beside the register. A broad chalk mark on the folder's edge matches the height of the smeared desk; Owen had watched her lean it there while discussing pupil privacy. Her warning was, \"A family record should not become a weapon.\" This explains regular access and a possible source of chalk transfer, but Owen left at seven and cannot account for the classroom overnight.\n\nWitness background for Xander Hale: Owen Bell recalls Harper pointing out Xander Hale's narrow whetstone while the woodworker repaired her drawer rail last Tuesday. Owen saw the stone in a leather sleeve stamped with the workshop's address; he checked that address on the repair invoice. Harper said he \"used to work with blades in another trade\" but did not name it. Owen also saw fresh blue chalk on the woodworker's cuff after measuring the rail with Harper's chalk line. That gives an ordinary source for the cuff mark, not an explanation of the missing page or the earlier blade skills.\n\nWitness background for Marla Quinn: Owen Bell signed for Marla Quinn's six-o'clock bread delivery to Harper on the morning before the death. He recognized the baker's stamped basket and the repaired brass-buckled boots described in Round 1. The delivery docket, signed by Harper, specifies the classroom door rather than the school kitchen. Owen saw the assistant wait while Harper opened the student-record drawer to find payment. This gives a witnessed reason for knowing Harper's schedule and seeing the drawer. Neither the flour on the boots nor that access proves a visit before sunrise on the fatal morning.\n\nWitness background for Jasper Crowe: Owen Bell checked Jasper Crowe's name on the fundraiser attendance sheet at nine the previous evening. He recognized the blue-strapped case and watched the musician leave it beside Harper's desk while stacking chairs. White chalk marked the case corner where it rubbed the desktop, covering part of the pale bakery streak described in Round 1. Owen identifies a source for the transfer and a reason for being in the room. He locked the public school door after the event, but did not remain to watch the classroom's separate yard entrance overnight.\n\nThe host reads the original neighbors' recorded responses:\nXander Hale's recorded response: \"I heard Owen saw Lydia Vance's green folder in Harper's classroom at six, discussing pupil privacy. Its chalk matches the desk height. I worry about access, but Owen left at seven.\"\nMarla Quinn's recorded response: \"I heard Harper said Xander Hale once worked with blades; Owen saw his narrow whetstone during her drawer repair. Chalk explains his cuff mark to me, not missing pages or blade skills.\"\nJasper Crowe's recorded response: \"I read Marla Quinn's signed six-o'clock bread delivery to Harper's classroom door. Owen saw her wait by the open records drawer. I see access, but not a fatal-morning visit.\"\nLydia Vance's recorded response: \"I read Jasper Crowe's nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak. I see how marks transfer, but Owen didn't watch the yard entrance overnight.\"\n\nThe supplied witness accounts support these comparisons:\nNell Reed recorded a chalk smear and narrow drag line through it.\nDella March identified Lydia and the topic of the bakery argument.\nFinn Moss heard a promised parcel requested but saw no handover.\nAda Bell saw the fine stones in an address-stamped sleeve.\nOwen Bell found Harper, locked the classroom and fetched Nell.\nEdith Shaw has not supplied an office account at this stage.\nTown Investigator connected three disturbed records by receipt 47.\nDella's collection of Della's Granddaughter identifies a teacher, not a threat.",
        "publicText": "Harper Wren: throat slashed with the same precise cut. Owen Bell found her; Nell Reed recorded chalk and a drag line beside a disturbed student-record book. Its index cites receipt 47 and a copy kept with an unnamed original order. Attendance and lesson records are intact.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "Before sunrise, caretaker Owen Bell finds senior teacher Harper Wren in her classroom with her throat slashed, the same precise cut again.",
          "Harper taught most of the town's children and kept family records as carefully as lesson plans.",
          "Owen locks the room and fetches Nell Reed."
        ],
        "readingGroups": [
          [
            "xander",
            "marla",
            "jasper"
          ],
          [
            "lydia"
          ],
          [
            "nell"
          ],
          [
            "della"
          ],
          [
            "finn"
          ],
          [
            "ada"
          ],
          [
            "owen"
          ],
          [
            "edith"
          ],
          [
            "investigator"
          ],
          [
            "pupil"
          ]
        ],
        "chain": [
          "xander",
          "marla",
          "jasper",
          "lydia",
          "nell",
          "della",
          "finn",
          "ada",
          "owen",
          "edith",
          "investigator",
          "pupil"
        ],
        "coverageRepeat": true
      },
      {
        "title": "Round 4 - Visits and Transferred Marks",
        "narration": "Compare only the findings already read at the bakery, tavern and school. An evening delivery is not a fatal-morning visit; flour, rosin, shellac and chalk have witnessed work-related sources. Receipt 47 links disturbed records but does not yet identify their subject. Correct an accusation that mistakes a work trace or access for a witnessed killing. No new death, name, trade or weapon identification is introduced.",
        "publicText": "Correct earlier inferences using only already released evidence.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "Compare released work traces with the recorded visits.",
          "Correct unsupported accusations without a new discovery."
        ],
        "readingGroups": [
          [
            "xander",
            "jasper",
            "marla"
          ],
          [
            "lydia"
          ],
          [
            "nell"
          ],
          [
            "della"
          ],
          [
            "finn"
          ],
          [
            "ada"
          ],
          [
            "owen"
          ],
          [
            "edith"
          ],
          [
            "investigator"
          ],
          [
            "pupil"
          ]
        ],
        "chain": [
          "xander",
          "jasper",
          "marla",
          "lydia",
          "nell",
          "della",
          "finn",
          "ada",
          "owen",
          "edith",
          "investigator",
          "pupil"
        ],
        "coverageRepeat": true
      },
      {
        "title": "Round 5 - The Lamplighter's Murder",
        "narration": "Before the morning market opens, Nell Reed finds Tobias Wick beside an extinguished streetlamp with his throat slashed in the same precise manner. Tobias walked every lane at night and kept route notes about what he saw. Lamp oil has spilled in a perfect circle around the lamp base. Nell records its position before moving the fallen oil flask; the shape of the spill alone cannot identify who was there. A page is torn from Tobias's old route notebook. The surviving index bears receipt 47 and the instruction, \"Retain duplicate with original order.\" Nell gathers the bakery closing-duty sheet, Ronan's appointment book and Harper's lesson diary for comparison with the earlier witness accounts. Their entries can explain a visit or correct a timing assumption, but they are not blanket alibis. The subject of the old records is still missing.  Let each account introduce its own new finding. Then compare the four scenes and ask which traces are ordinary work and which remain unexplained.\n\nThe investigator reads the supporting witness accounts before calling on the selected readers:\n\nWitness background for Marla Quinn: Nell Reed compares Marla Quinn's flour-marked repaired boot from Round 1 with the bakery closing-duty sheet. Elias initialed her nine-o'clock task: scrub the rear threshold, then deliver the waste pail to the market. The entry explains why the crescent heel and flour appeared at the doorway; it is not evidence that the print was made during the killing. Market seller Della March also records that the assistant reported Tobias arguing with an unidentified figure beside the oil stall last night. Della heard the report, not the argument, so she cannot identify that figure.\n\nWitness background for Jasper Crowe: Della March saw Jasper Crowe follow Tobias from the tavern to the market lamp at ten last night. She identified the musician by his blue-strapped case and by the tune he had just played at her stall. Tobias asked him to hold the oil flask while adjusting the wick; Della saw a drop spill onto his right sleeve. The stain therefore has an observed source, not merely an assumed link to lamplighting. Della closed her shutter before Tobias resumed his route. The musician's presence and oil stain establish contact, but not where either man went afterward.\n\nWitness background for Lydia Vance: Nell Reed finds Lydia Vance's warning to Tobias entered in his intact route book: \"Children's family affairs do not belong in street notes.\" The entry describes her green folder and the school gate, where Owen Bell confirms he saw them speak. Nell compares it with Harper's lesson diary, which schedules their weekly meetings to prepare lessons and handle family requests. These sources explain the teacher's meetings and concern about records without supplying an overnight alibi. They do not explain why the older page indexed under receipt 47 was torn out.\n\nWitness background for Xander Hale: Nell Reed saw Xander Hale beneath the workshop lamp yesterday evening, holding a straight razor rather than a woodworking chisel. She recognized him from the shelf-repair invoice she had collected at the tavern and spoke to him face to face. The open blade reflected the lamp; the ivory handle had a triangular chip beside its hinge. He closed it and put it into the address-stamped leather sleeve whose fine stones Ada Bell described in Round 2. Nell can identify the owner, object and distinctive damage, but she did not see an attack. The blade should be compared with the repeated precise cuts, not treated as a confession.\n\nThe host reads the original neighbors' recorded responses:\nXander Hale's recorded response: \"I read Marla Quinn's nine-o'clock closing duty: scrub the rear threshold, then take waste to market. I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone.\"\nMarla Quinn's recorded response: \"I heard Della saw Jasper Crowe follow Tobias to the market lamp at ten. He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward.\"\nJasper Crowe's recorded response: \"I read Lydia Vance's warning to Tobias: children's family affairs don't belong in street notes. Her weekly lesson meetings explain contact to me, not an overnight alibi or receipt 47's torn page.\"\nLydia Vance's recorded response: \"I heard Nell saw Xander Hale's straight razor: ivory handle, triangular chip beside its hinge. It went into his stamped sleeve. I worry about those precise cuts, not a confession.\"\n\nThe supplied witness accounts support these comparisons:\nNell Reed saw the chipped ivory razor enter the stamped sleeve.\nDella March saw Jasper holding the flask before oil spilled on his sleeve.\nFinn Moss left for the delivery cart without witnessing the bakery death.\nAda Bell saw the blue-strapped case on Ronan's counter at ten.\nOwen Bell left at seven without watching the separate yard entrance overnight.\nEdith Shaw has not supplied an office account at this stage.\nTown Investigator preserved the earlier work records for timing comparisons.\nDella's school collection of Della's Granddaughter does not identify a murderer.",
        "publicText": "Tobias Wick: throat slashed with the same precise cut. Nell Reed found him beside an extinguished lamp and a circle of spilled oil. A torn night-route page is indexed under receipt 47. Earlier work and appointment records are ready for comparison, not complete alibis.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "Before the morning market opens, Nell Reed finds Tobias Wick beside an extinguished streetlamp with his throat slashed in the same precise manner.",
          "Tobias walked every lane at night and kept route notes about what he saw.",
          "Lamp oil has spilled in a perfect circle around the lamp base."
        ],
        "readingGroups": [
          [
            "xander",
            "marla",
            "jasper"
          ],
          [
            "lydia"
          ],
          [
            "nell"
          ],
          [
            "della"
          ],
          [
            "finn"
          ],
          [
            "ada"
          ],
          [
            "owen"
          ],
          [
            "edith"
          ],
          [
            "investigator"
          ],
          [
            "pupil"
          ]
        ],
        "chain": [
          "xander",
          "marla",
          "jasper",
          "lydia",
          "nell",
          "della",
          "finn",
          "ada",
          "owen",
          "edith",
          "investigator",
          "pupil"
        ],
        "coverageRepeat": true
      },
      {
        "title": "Round 6 - Work Traces and the Identified Tool",
        "narration": "Compare the already released closing-duty sheet, private-appointment records, school visits and Nell's chipped-razor sighting. A work record can explain a trace without supplying an overnight alibi. The identified razor is more specific than an unexplained color or stain, but its sighting is not a confession. Correct earlier accusations based only on flour, chalk or spilled oil. No new death or old identity is introduced.",
        "publicText": "Correct earlier inferences using only already released evidence.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "Compare released work traces with the recorded visits.",
          "Correct unsupported accusations without a new discovery."
        ],
        "readingGroups": [
          [
            "xander",
            "jasper",
            "marla"
          ],
          [
            "lydia"
          ],
          [
            "nell"
          ],
          [
            "della"
          ],
          [
            "finn"
          ],
          [
            "ada"
          ],
          [
            "owen"
          ],
          [
            "edith"
          ],
          [
            "investigator"
          ],
          [
            "pupil"
          ]
        ],
        "chain": [
          "xander",
          "jasper",
          "marla",
          "lydia",
          "nell",
          "della",
          "finn",
          "ada",
          "owen",
          "edith",
          "investigator",
          "pupil"
        ],
        "coverageRepeat": true
      },
      {
        "title": "Round 7 - The Mayor's Murder",
        "narration": "Office clerk Edith Shaw finds Mayor Aldric Thorne in his office chair with his throat slashed, the same precise cut. A polished straight razor lies on the desk, its ivory handle chipped beside the hinge. Edith calls Nell Reed and identifies the locked cabinet from which the papers on the desk came; its numbered index and broken wax seal allow the investigator to trace their source. A single old court document, signed by Thorne, orders the imprisonment of BENJAMIN BARKER and bears receipt 47. This is the first time that name enters the investigation. With it are the duplicate records referred to in Harper's index and Tobias's notebook. The investigator reads them aloud: Elias signed a false delivery entry placing Barker at a theft; Ronan signed a fabricated account of a confession; Harper altered a household record to support the charge; Tobias supplied a false night-route sighting. A retained letter from Thorne orders the changes, admits that he wanted Barker's wife and describes using imprisonment to separate them. The household record states that she was taken into Thorne's household under coercion, not by free choice. Barker's licensed occupation is barber. A likeness, address and tool inventory are attached, but the investigator leaves their identification to the witnesses whose accounts you are about to hear. These documents establish the original injustice and the four victims' roles. They do not announce which current neighbor committed the murders.  Hear every account before the final vote.\n\nThe investigator reads the supporting witness accounts before calling on the selected readers:\n\nWitness background for Jasper Crowe: Edith Shaw asks Jasper Crowe to explain a rumor he heard at the tavern about the woodworker once using a different name. He identifies its source as Ronan's remark about an old license, not personal knowledge of the imprisonment. Edith compares the signature on his ten-o'clock drink receipt with the appointment book preserved in Round 2; it confirms his earlier visit, while a separate eleven-o'clock entry admits a private visitor. His rosin flake explains a substance on the counter, but neither the rumor nor the flake identifies that later visitor or makes him a signer of the false statements in the court file.\n\nWitness background for Lydia Vance: Edith Shaw compares Lydia Vance's account of seeing the Mayor hide an old paper with the cabinet index recovered today. The teacher dates the sighting to a school-funding appointment entered in Edith's diary; Edith confirms she admitted her for that appointment and saw Thorne close the folder. The teacher could read receipt 47, but not the name hidden beneath his hand. This explains why the teacher questioned intrusive family records. Her chalk-marked folder and weekly lesson meetings establish access to school papers, not a signature on the falsified statements read from the court file.\n\nWitness background for Xander Hale: Edith Shaw identifies the court file's licensed likeness as Xander Hale; she compares the workshop address printed beside it with the signed shelf-repair invoice preserved in Round 2. The licensed name is Benjamin Barker. The barber's tool inventory describes an ivory razor with a chip beside the hinge, matching the blade Nell Reed saw in his hand in Round 4 and the one now on Thorne's desk. The fine stones and Harper's earlier-trade remark fit the documented occupation. The duplicate records identify the four people who helped Thorne destroy his former life. This joins identity, blade ownership and motive; the room must still decide its final accusation.\n\nWitness background for Marla Quinn: Edith Shaw checks Marla Quinn's account of an old visit by Thorne to the workshop home. The assistant remembers delivering a baker's basket there as a child; the retained delivery copy records the date and the house number. Edith compares those details with Thorne's appointment diary and confirms the visit. The account links a remembered visit to a documented place, but the assistant did not hear the conversation. Her repaired flour-marked boot still fits the closing chore established in Round 4, not a proven killing. Neither her childhood observation nor her recent bread delivery makes her one of the signers identified in the old file.\n\nThe host reads the original neighbors' recorded responses:\nXander Hale's recorded response: \"I heard Jasper Crowe's different-name rumor came from Ronan's old-license remark. His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin.\"\nMarla Quinn's recorded response: \"I learned Lydia Vance saw Thorne hide receipt 47 during her confirmed school-funding appointment. She couldn't read the name. I see why she questioned family records, not proof she falsified them.\"\nJasper Crowe's recorded response: \"I heard Edith match Xander Hale's licensed likeness and workshop address: Benjamin Barker, barber. His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse.\"\nLydia Vance's recorded response: \"I heard Edith confirm Marla Quinn's childhood delivery during Thorne's old workshop-home visit. She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot.\"\n\nThe supplied witness accounts support these comparisons:\nNell Reed identified the damaged razor in the earlier sighting.\nDella March's boot identification established work access, not print timing.\nFinn Moss's case account established an evening visit, not a witnessed murder.\nAda Bell's account left later private visitors possible.\nOwen Bell's accounts did not establish an overnight alibi.\nEdith Shaw matched the licensed likeness and address to Xander.\nTown Investigator read the retained duplicate records and Thorne's letter.\nDella's identification through Della's Granddaughter does not implicate Lydia in the old falsification.",
        "publicText": "Mayor Aldric Thorne: throat slashed; a polished razor with a chipped ivory handle on his desk. Edith Shaw identifies the cabinet and record index. Thorne's signed imprisonment order names Benjamin Barker under receipt 47. Duplicate records and his letter expose the four victims' false statements and his coercion. Witness identification follows in the player readings.",
        "hostNotes": "Read the full chapter and recorded accounts aloud. Then call the original trio in its stored order, followed by supplemental readers. Deliberate and vote after everyone reads. Do not preview the old name, occupation or Mayor connection before the final discovery chapter.",
        "events": [
          "Office clerk Edith Shaw finds Mayor Aldric Thorne in his office chair with his throat slashed, the same precise cut.",
          "A polished straight razor lies on the desk, its ivory handle chipped beside the hinge.",
          "Edith calls Nell Reed and identifies the locked cabinet from which the papers on the desk came; its numbered index and broken wax seal allow the investigator to trace their source."
        ],
        "readingGroups": [
          [
            "xander",
            "marla",
            "jasper"
          ],
          [
            "lydia"
          ],
          [
            "nell"
          ],
          [
            "della"
          ],
          [
            "finn"
          ],
          [
            "ada"
          ],
          [
            "owen"
          ],
          [
            "edith"
          ],
          [
            "investigator"
          ],
          [
            "pupil"
          ]
        ],
        "chain": [
          "xander",
          "marla",
          "jasper",
          "lydia",
          "nell",
          "della",
          "finn",
          "ada",
          "owen",
          "edith",
          "investigator",
          "pupil"
        ],
        "coverageRepeat": true
      }
    ],
    "characters": [
      {
        "id": "xander",
        "name": "Xander Hale",
        "role": "Woodworker",
        "relationship": "A neighbor asked by the town investigator to help compare witness accounts of the Blackwater Row murders.",
        "tieIn": "A quiet craftsperson who repairs furniture and makes wooden fittings in a workshop off the market lane.",
        "optional": false,
        "ghost": null,
        "guest": "",
        "guestNote": "",
        "publicBlurb": "A quiet craftsperson who repairs furniture and makes wooden fittings in a workshop off the market lane.",
        "rounds": [
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I heard Nell saw {marla} leave the bakery's back door at nine with her red-handled brush. Her repaired, flour-packed heel resembles those prints. I still need their timing checked.",
              "observation": "I heard Nell saw {marla} leave the bakery's back door at nine with her red-handled brush.",
              "contradictingDetail": "Her repaired, flour-packed heel resembles those prints. I still need their timing checked."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I heard Ada saw {jasper}'s blue-strapped case on Ronan's counter at ten. His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors.",
              "observation": "I heard Ada saw {jasper}'s blue-strapped case on Ronan's counter at ten.",
              "contradictingDetail": "His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I read {marla}'s signed six-o'clock bread delivery to Harper's classroom door. Owen saw her wait by the open records drawer. I see access, but not a fatal-morning visit.",
              "observation": "I read {marla}'s signed six-o'clock bread delivery to Harper's classroom door.",
              "contradictingDetail": "Owen saw her wait by the open records drawer. I see access, but not a fatal-morning visit."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I heard {jasper}'s case rubbed the chalky desk over its flour streak. I must distinguish transferred work marks from evidence that he removed the student-record page.",
              "observation": "I heard {jasper}'s case rubbed the chalky desk over its flour streak.",
              "contradictingDetail": "I must distinguish transferred work marks from evidence that he removed the student-record page."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I read {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market. I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone.",
              "observation": "I read {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market.",
              "contradictingDetail": "I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I read {jasper}'s visit to the lamp in Della's account. I must not treat spilled oil on his sleeve as proof of a precise cut or an account of his later movements.",
              "observation": "I read {jasper}'s visit to the lamp in Della's account.",
              "contradictingDetail": "I must not treat spilled oil on his sleeve as proof of a precise cut or an account of his later movements."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I heard Edith confirm {marla}'s childhood delivery during Thorne's old workshop-home visit. She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot.",
              "observation": "I heard Edith confirm {marla}'s childhood delivery during Thorne's old workshop-home visit.",
              "contradictingDetail": "She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot."
            }
          }
        ]
      },
      {
        "id": "marla",
        "name": "Marla Quinn",
        "role": "Baker's assistant",
        "relationship": "Assistant to the first victim, the baker Elias Brim; asked to help compare witness accounts.",
        "tieIn": "Elias Brim's assistant, responsible for bread deliveries and the evening cleanup. A familiar face at doorsteps across town.",
        "optional": false,
        "ghost": null,
        "guest": "",
        "guestNote": "",
        "publicBlurb": "Elias Brim's assistant, responsible for bread deliveries and the evening cleanup. A familiar face at doorsteps across town.",
        "rounds": [
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I heard Finn saw {jasper} behind the bakery at nine-thirty with his blue-strapped case. A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave.",
              "observation": "I heard Finn saw {jasper} behind the bakery at nine-thirty with his blue-strapped case.",
              "contradictingDetail": "A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I read {xander}'s shelf invoice; Ada saw fine sharpening stones in his address-stamped sleeve. His repair cloth held amber shellac. I see another possible smear source, not proof he touched that mug.",
              "observation": "I read {xander}'s shelf invoice; Ada saw fine sharpening stones in his address-stamped sleeve.",
              "contradictingDetail": "His repair cloth held amber shellac. I see another possible smear source, not proof he touched that mug."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I read {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak. I see how marks transfer, but Owen didn't watch the yard entrance overnight.",
              "observation": "I read {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak.",
              "contradictingDetail": "I see how marks transfer, but Owen didn't watch the yard entrance overnight."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard {xander}'s drawer repair explained chalk on his cuff. I must not mistake a work mark for an explanation of the missing pages or his earlier blade skills.",
              "observation": "I heard {xander}'s drawer repair explained chalk on his cuff.",
              "contradictingDetail": "I must not mistake a work mark for an explanation of the missing pages or his earlier blade skills."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I heard Della saw {jasper} follow Tobias to the market lamp at ten. He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward.",
              "observation": "I heard Della saw {jasper} follow Tobias to the market lamp at ten.",
              "contradictingDetail": "He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard Nell identify {xander}'s chipped ivory razor. I must compare that identifiable tool with the repeated cuts, not call the sighting a confession.",
              "observation": "I heard Nell identify {xander}'s chipped ivory razor.",
              "contradictingDetail": "I must compare that identifiable tool with the repeated cuts, not call the sighting a confession."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I heard {jasper}'s different-name rumor came from Ronan's old-license remark. His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin.",
              "observation": "I heard {jasper}'s different-name rumor came from Ronan's old-license remark.",
              "contradictingDetail": "His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin."
            }
          }
        ]
      },
      {
        "id": "jasper",
        "name": "Jasper Crowe",
        "role": "Tavern musician",
        "relationship": "Musician at the tavern of the second victim, Ronan Pike; asked to help compare witness accounts.",
        "tieIn": "A musician at Ronan Pike's tavern who also plays for town events. Often out late carrying his instrument between jobs.",
        "optional": false,
        "ghost": null,
        "guest": "",
        "guestNote": "",
        "publicBlurb": "A musician at Ronan Pike's tavern who also plays for town events. Often out late carrying his instrument between jobs.",
        "rounds": [
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard Della saw Elias refuse to enter {xander}'s workshop over an old receipt. He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon.",
              "observation": "I heard Della saw Elias refuse to enter {xander}'s workshop over an old receipt.",
              "contradictingDetail": "He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I heard Della heard {marla} dispute Ronan's flour bill at seven. She showed a receipt and left toward the bakery. I can't confirm payment or a later return.",
              "observation": "I heard Della heard {marla} dispute Ronan's flour bill at seven.",
              "contradictingDetail": "She showed a receipt and left toward the bakery. I can't confirm payment or a later return."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair. Chalk explains his cuff mark to me, not missing pages or blade skills.",
              "observation": "I heard Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair.",
              "contradictingDetail": "Chalk explains his cuff mark to me, not missing pages or blade skills."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I read {marla}'s signed bread delivery at six. I must distinguish an evening delivery from a fatal-morning visit; access alone does not explain the missing page.",
              "observation": "I read {marla}'s signed bread delivery at six.",
              "contradictingDetail": "I must distinguish an evening delivery from a fatal-morning visit; access alone does not explain the missing page."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge. It went into his stamped sleeve. I worry about those precise cuts, not a confession.",
              "observation": "I heard Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge.",
              "contradictingDetail": "It went into his stamped sleeve. I worry about those precise cuts, not a confession."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I read {marla}'s closing duty to scrub the rear threshold. I must correct my earlier suspicion: flour in her repaired heel can come from work, not a witnessed killing.",
              "observation": "I read {marla}'s closing duty to scrub the rear threshold.",
              "contradictingDetail": "I must correct my earlier suspicion: flour in her repaired heel can come from work, not a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I heard Edith match {xander}'s licensed likeness and workshop address: Benjamin Barker, barber. His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse.",
              "observation": "I heard Edith match {xander}'s licensed likeness and workshop address: Benjamin Barker, barber.",
              "contradictingDetail": "His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse."
            }
          }
        ]
      },
      {
        "id": "lydia",
        "name": "Lydia Vance",
        "role": "Schoolteacher",
        "relationship": "Teacher working alongside the third victim, senior teacher Harper Wren; asked to help compare witness accounts.",
        "tieIn": "A teacher working alongside senior teacher Harper Wren. Attentive to local families and protective of their privacy.",
        "publicBlurb": "A teacher working alongside senior teacher Harper Wren. Attentive to local families and protective of their privacy.",
        "optional": false,
        "guest": "",
        "guestNote": "",
        "ghost": null,
        "rounds": [
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I learned Della saw Elias refuse to enter {xander}'s workshop over an old receipt. He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon.",
              "observation": "I learned Della saw Elias refuse to enter {xander}'s workshop over an old receipt.",
              "contradictingDetail": "He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I learned Della heard {marla} dispute Ronan's flour bill at seven. She showed a receipt and left toward the bakery. I can't confirm payment or a later return.",
              "observation": "I learned Della heard {marla} dispute Ronan's flour bill at seven.",
              "contradictingDetail": "She showed a receipt and left toward the bakery. I can't confirm payment or a later return."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I checked {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak. I see how marks transfer, but Owen didn't watch the yard entrance overnight.",
              "observation": "I checked {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak.",
              "contradictingDetail": "I see how marks transfer, but Owen didn't watch the yard entrance overnight."
            }
          },
          {
            "readAloud": {
              "accuses": "nell",
              "text": "I heard the account: {nell} recorded a chalk smear and narrow drag line through it. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: {nell} recorded a chalk smear and narrow drag line through it.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "della",
              "text": "I heard the account: {della} saw Jasper holding the flask before oil spilled on his sleeve. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {della} saw Jasper holding the flask before oil spilled on his sleeve.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "finn",
              "text": "I heard the account: {finn} left for the delivery cart without witnessing the bakery death. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: {finn} left for the delivery cart without witnessing the bakery death.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "ada",
              "text": "I heard the account: {ada}'s account left later private visitors possible. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {ada}'s account left later private visitors possible.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          }
        ]
      },
      {
        "id": "nell",
        "name": "Nell Reed",
        "role": "Night watchwoman",
        "relationship": "An existing person in the supplied Blackwater Row accounts.",
        "tieIn": "Records the scene findings and supplies the razor sighting.",
        "publicBlurb": "Records the scene findings and supplies the razor sighting.",
        "optional": false,
        "guest": "",
        "guestNote": "",
        "ghost": null,
        "rounds": [
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I learned Nell saw {marla} leave the bakery's back door at nine with her red-handled brush. Her repaired, flour-packed heel resembles those prints. I still need their timing checked.",
              "observation": "I learned Nell saw {marla} leave the bakery's back door at nine with her red-handled brush.",
              "contradictingDetail": "Her repaired, flour-packed heel resembles those prints. I still need their timing checked."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I learned Ada saw {jasper}'s blue-strapped case on Ronan's counter at ten. His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors.",
              "observation": "I learned Ada saw {jasper}'s blue-strapped case on Ronan's counter at ten.",
              "contradictingDetail": "His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors."
            }
          },
          {
            "readAloud": {
              "accuses": "lydia",
              "text": "I learned Owen saw {lydia}'s green folder in Harper's classroom at six, discussing pupil privacy. Its chalk matches the desk height. I worry about access, but Owen left at seven.",
              "observation": "I learned Owen saw {lydia}'s green folder in Harper's classroom at six, discussing pupil privacy.",
              "contradictingDetail": "Its chalk matches the desk height. I worry about access, but Owen left at seven."
            }
          },
          {
            "readAloud": {
              "accuses": "della",
              "text": "I heard the account: {della} identified Lydia and the topic of the bakery argument. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: {della} identified Lydia and the topic of the bakery argument.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "finn",
              "text": "I heard the account: {finn} left for the delivery cart without witnessing the bakery death. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {finn} left for the delivery cart without witnessing the bakery death.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "ada",
              "text": "I heard the account: {ada} saw the blue-strapped case on Ronan's counter at ten. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: {ada} saw the blue-strapped case on Ronan's counter at ten.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "owen",
              "text": "I heard the account: {owen}'s accounts did not establish an overnight alibi. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {owen}'s accounts did not establish an overnight alibi.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          }
        ]
      },
      {
        "id": "della",
        "name": "Della March",
        "role": "Cobbler",
        "relationship": "An existing person in the supplied Blackwater Row accounts.",
        "tieIn": "Identifies the repaired boot and the neighbors in her recorded accounts.",
        "publicBlurb": "Identifies the repaired boot and the neighbors in her recorded accounts.",
        "optional": false,
        "guest": "",
        "guestNote": "",
        "ghost": null,
        "rounds": [
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I learned Finn saw {jasper} behind the bakery at nine-thirty with his blue-strapped case. A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave.",
              "observation": "I learned Finn saw {jasper} behind the bakery at nine-thirty with his blue-strapped case.",
              "contradictingDetail": "A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave."
            }
          },
          {
            "readAloud": {
              "accuses": "lydia",
              "text": "I learned Ada heard {lydia} warn Ronan about recording families at eight. She touched his book, leaving possible chalk. I can't prove a removed page or a later return.",
              "observation": "I learned Ada heard {lydia} warn Ronan about recording families at eight.",
              "contradictingDetail": "She touched his book, leaving possible chalk. I can't prove a removed page or a later return."
            }
          },
          {
            "readAloud": {
              "accuses": "nell",
              "text": "I heard the account: {nell} recorded a chalk smear and narrow drag line through it. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {nell} recorded a chalk smear and narrow drag line through it.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "finn",
              "text": "I heard the account: {finn} heard a promised parcel requested but saw no handover. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: {finn} heard a promised parcel requested but saw no handover.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "ada",
              "text": "I heard the account: {ada} saw the blue-strapped case on Ronan's counter at ten. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {ada} saw the blue-strapped case on Ronan's counter at ten.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "owen",
              "text": "I heard the account: {owen} left at seven without watching the separate yard entrance overnight. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: {owen} left at seven without watching the separate yard entrance overnight.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "edith",
              "text": "I heard the account: {edith} matched the licensed likeness and address to Xander. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {edith} matched the licensed likeness and address to Xander.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          }
        ]
      },
      {
        "id": "finn",
        "name": "Finn Moss",
        "role": "Delivery porter",
        "relationship": "An existing person in the supplied Blackwater Row accounts.",
        "tieIn": "Finds Elias and reports the musician waiting behind the bakery.",
        "publicBlurb": "Finds Elias and reports the musician waiting behind the bakery.",
        "optional": false,
        "guest": "",
        "guestNote": "",
        "ghost": null,
        "rounds": [
          {
            "readAloud": {
              "accuses": "lydia",
              "text": "I learned Della saw {lydia} argue with Elias that morning, her green lesson folder tucked under her arm. A bread bill held family history. I wonder why he folded that paper.",
              "observation": "I learned Della saw {lydia} argue with Elias that morning, her green lesson folder tucked under her arm.",
              "contradictingDetail": "A bread bill held family history. I wonder why he folded that paper."
            }
          },
          {
            "readAloud": {
              "accuses": "nell",
              "text": "I heard the account: {nell} recorded a wiped mug without usable fingerprints. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {nell} recorded a wiped mug without usable fingerprints.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "della",
              "text": "I heard the account: {della} identified Lydia and the topic of the bakery argument. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {della} identified Lydia and the topic of the bakery argument.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "ada",
              "text": "I heard the account: {ada} saw the fine stones in an address-stamped sleeve. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: {ada} saw the fine stones in an address-stamped sleeve.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "owen",
              "text": "I heard the account: {owen} left at seven without watching the separate yard entrance overnight. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {owen} left at seven without watching the separate yard entrance overnight.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "edith",
              "text": "I heard the account: {edith} has not supplied an office account at this stage. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: {edith} has not supplied an office account at this stage.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "investigator",
              "text": "I heard the account: {investigator} read the retained duplicate records and Thorne's letter. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {investigator} read the retained duplicate records and Thorne's letter.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          }
        ]
      },
      {
        "id": "ada",
        "name": "Ada Bell",
        "role": "Tavern cleaner",
        "relationship": "An existing person in the supplied Blackwater Row accounts.",
        "tieIn": "Finds Ronan and reports the tavern objects and appointments.",
        "publicBlurb": "Finds Ronan and reports the tavern objects and appointments.",
        "optional": false,
        "guest": "",
        "guestNote": "",
        "ghost": null,
        "rounds": [
          {
            "readAloud": {
              "accuses": "nell",
              "text": "I heard the account: {nell} recorded flour prints with a crescent gap in the right heel. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {nell} recorded flour prints with a crescent gap in the right heel.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "della",
              "text": "I heard the account: {della} heard Marla dispute the flour bill and leave toward the bakery. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {della} heard Marla dispute the flour bill and leave toward the bakery.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "finn",
              "text": "I heard the account: {finn} heard a promised parcel requested but saw no handover. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {finn} heard a promised parcel requested but saw no handover.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "owen",
              "text": "I heard the account: {owen} found Harper, locked the classroom and fetched Nell. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: {owen} found Harper, locked the classroom and fetched Nell.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "edith",
              "text": "I heard the account: {edith} has not supplied an office account at this stage. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {edith} has not supplied an office account at this stage.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "investigator",
              "text": "I heard the account: {investigator} preserved the earlier work records for timing comparisons. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: {investigator} preserved the earlier work records for timing comparisons.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "pupil",
              "text": "I heard the account: Della's identification through {pupil} does not implicate Lydia in the old falsification. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: Della's identification through {pupil} does not implicate Lydia in the old falsification.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          }
        ]
      },
      {
        "id": "owen",
        "name": "Owen Bell",
        "role": "School caretaker",
        "relationship": "An existing person in the supplied Blackwater Row accounts.",
        "tieIn": "Finds Harper and supplies the school visit accounts and records.",
        "publicBlurb": "Finds Harper and supplies the school visit accounts and records.",
        "optional": false,
        "guest": "",
        "guestNote": "",
        "ghost": null,
        "rounds": [
          {
            "readAloud": {
              "accuses": "della",
              "text": "I heard the account: {della} recognized the repaired boot from its collection yesterday. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {della} recognized the repaired boot from its collection yesterday.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "finn",
              "text": "I heard the account: {finn} did not witness the bakery death or the musician leaving. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {finn} did not witness the bakery death or the musician leaving.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "ada",
              "text": "I heard the account: {ada} saw the fine stones in an address-stamped sleeve. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {ada} saw the fine stones in an address-stamped sleeve.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "edith",
              "text": "I heard the account: {edith} has not supplied an office account at this stage. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: {edith} has not supplied an office account at this stage.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "investigator",
              "text": "I heard the account: {investigator} preserved the earlier work records for timing comparisons. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {investigator} preserved the earlier work records for timing comparisons.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "pupil",
              "text": "I heard the account: Della's school collection of {pupil} does not identify a murderer. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: Della's school collection of {pupil} does not identify a murderer.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I learned Edith match {xander}'s licensed likeness and workshop address: Benjamin Barker, barber. His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse.",
              "observation": "I learned Edith match {xander}'s licensed likeness and workshop address: Benjamin Barker, barber.",
              "contradictingDetail": "His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse."
            }
          }
        ]
      },
      {
        "id": "edith",
        "name": "Edith Shaw",
        "role": "Office clerk",
        "relationship": "An existing person in the supplied Blackwater Row accounts.",
        "tieIn": "Finds Thorne and traces the final documents to the office cabinet.",
        "publicBlurb": "Finds Thorne and traces the final documents to the office cabinet.",
        "optional": false,
        "guest": "",
        "guestNote": "",
        "ghost": null,
        "rounds": [
          {
            "readAloud": {
              "accuses": "finn",
              "text": "I heard the account: {finn} found Elias and called Nell before anyone entered the yard. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {finn} found Elias and called Nell before anyone entered the yard.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "ada",
              "text": "I heard the account: {ada} found Ronan and left the mug untouched. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {ada} found Ronan and left the mug untouched.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "owen",
              "text": "I heard the account: {owen} found Harper, locked the classroom and fetched Nell. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {owen} found Harper, locked the classroom and fetched Nell.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "investigator",
              "text": "I heard the account: {investigator} connected three disturbed records by receipt 47. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: {investigator} connected three disturbed records by receipt 47.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "pupil",
              "text": "I heard the account: Della's school collection of {pupil} does not identify a murderer. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: Della's school collection of {pupil} does not identify a murderer.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I learned Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge. It went into his stamped sleeve. I worry about those precise cuts, not a confession.",
              "observation": "I learned Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge.",
              "contradictingDetail": "It went into his stamped sleeve. I worry about those precise cuts, not a confession."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I learned Edith confirm {marla}'s childhood delivery during Thorne's old workshop-home visit. She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot.",
              "observation": "I learned Edith confirm {marla}'s childhood delivery during Thorne's old workshop-home visit.",
              "contradictingDetail": "She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot."
            }
          }
        ]
      },
      {
        "id": "investigator",
        "name": "Town Investigator",
        "role": "Investigator",
        "relationship": "An existing person in the supplied Blackwater Row accounts.",
        "tieIn": "Compares the supplied findings and records. No additional discoveries are authored for this role.",
        "publicBlurb": "Compares the supplied findings and records. No additional discoveries are authored for this role.",
        "optional": false,
        "guest": "",
        "guestNote": "",
        "ghost": null,
        "rounds": [
          {
            "readAloud": {
              "accuses": "ada",
              "text": "I heard the account: {ada} has not supplied a tavern account at this stage. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {ada} has not supplied a tavern account at this stage.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "owen",
              "text": "I heard the account: {owen} has not supplied a classroom account at this stage. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {owen} has not supplied a classroom account at this stage.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "edith",
              "text": "I heard the account: {edith} has not supplied an office account at this stage. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {edith} has not supplied an office account at this stage.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "pupil",
              "text": "I heard the account: Della's collection of {pupil} identifies a teacher, not a threat. I must correct any inference that turns an account into a witnessed killing.",
              "observation": "I heard the account: Della's collection of {pupil} identifies a teacher, not a threat.",
              "contradictingDetail": "I must correct any inference that turns an account into a witnessed killing."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I learned Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge. It went into his stamped sleeve. I worry about those precise cuts, not a confession.",
              "observation": "I learned Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge.",
              "contradictingDetail": "It went into his stamped sleeve. I worry about those precise cuts, not a confession."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I checked {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market. I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone.",
              "observation": "I checked {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market.",
              "contradictingDetail": "I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I learned {jasper}'s different-name rumor came from Ronan's old-license remark. His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin.",
              "observation": "I learned {jasper}'s different-name rumor came from Ronan's old-license remark.",
              "contradictingDetail": "His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin."
            }
          }
        ]
      },
      {
        "id": "pupil",
        "name": "Della's Granddaughter",
        "role": "School pupil",
        "relationship": "An existing person in the supplied Blackwater Row accounts.",
        "tieIn": "The granddaughter Della collects from school in her recorded identification of Lydia. This role responds to public accounts; no new eyewitness claims are assigned.",
        "publicBlurb": "The granddaughter Della collects from school in her recorded identification of Lydia. This role responds to public accounts; no new eyewitness claims are assigned.",
        "optional": false,
        "guest": "",
        "guestNote": "",
        "ghost": null,
        "rounds": [
          {
            "readAloud": {
              "accuses": "owen",
              "text": "I heard the account: {owen} has not supplied a classroom account at this stage. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {owen} has not supplied a classroom account at this stage.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "edith",
              "text": "I heard the account: {edith} has not supplied an office account at this stage. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {edith} has not supplied an office account at this stage.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "investigator",
              "text": "I heard the account: {investigator} connected three disturbed records by receipt 47. But I must judge what was actually witnessed, not assume a killing was seen.",
              "observation": "I heard the account: {investigator} connected three disturbed records by receipt 47.",
              "contradictingDetail": "But I must judge what was actually witnessed, not assume a killing was seen."
            }
          },
          {
            "readAloud": {
              "accuses": "xander",
              "text": "I learned Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair. Chalk explains his cuff mark to me, not missing pages or blade skills.",
              "observation": "I learned Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair.",
              "contradictingDetail": "Chalk explains his cuff mark to me, not missing pages or blade skills."
            }
          },
          {
            "readAloud": {
              "accuses": "marla",
              "text": "I checked {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market. I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone.",
              "observation": "I checked {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market.",
              "contradictingDetail": "I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone."
            }
          },
          {
            "readAloud": {
              "accuses": "jasper",
              "text": "I learned Della saw {jasper} follow Tobias to the market lamp at ten. He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward.",
              "observation": "I learned Della saw {jasper} follow Tobias to the market lamp at ten.",
              "contradictingDetail": "He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward."
            }
          },
          {
            "readAloud": {
              "accuses": "lydia",
              "text": "I heard {lydia} saw Thorne hide receipt 47 during her confirmed school-funding appointment. She couldn't read the name. I see why she questioned family records, not proof she falsified them.",
              "observation": "I heard {lydia} saw Thorne hide receipt 47 during her confirmed school-funding appointment.",
              "contradictingDetail": "She couldn't read the name. I see why she questioned family records, not proof she falsified them."
            }
          }
        ]
      }
    ],
    "finale": {
      "narration": "All seven chapters and the final witness accounts have now been read. Compare the identified blade, the licensed likeness and address, and the duplicate records with the earlier observations. Decide which neighbor accounts for the complete chain, not just one suspicious trace. A reason for revenge can explain a crime without excusing it. Make your final accusation before the investigator announces the solution.",
      "votePrompt": "Who do you accuse based on the evidence heard so far?"
    },
    "solution": {
      "killerId": "xander",
      "explanation": "Xander Hale is Benjamin Barker, formerly Blackwater Row's trusted barber, and he committed all five murders. Thorne's letter and court file, first read in Round 7, establish that the Mayor wanted Barker's wife, framed him, ordered his imprisonment and forced her into his household. Elias's false delivery entry, Ronan's invented confession, Harper's altered household record and Tobias's false night sighting helped destroy Barker's married life. After release, Barker returned as the woodworker Xander Hale. The fine stones in his address-stamped sleeve and Harper's earlier-trade remark established a blade skill without naming it. Nell's direct observation of the chipped ivory razor in Round 5 supplied identifiable ownership; Edith's Round 7 comparison joined that razor, the licensed likeness and the repair invoice to the old identity. Receipt 47 linked the disturbed records; retained duplicates explained the target selection. Marla's repaired flour-marked boot had a documented closing-chore source. Jasper's case and rosin and Lydia's folder and chalk had witnessed work-related sources; their movements raised questions but did not explain the complete identity, weapon and motive chain. No stain alone proved a killing. Barker killed the four accomplices before reaching his final target, the Mayor. This was deliberate revenge, not justice.",
      "revealNarration": "The investigator closes the court file. \"The killer is {xander}. His former name was Benjamin Barker, and his former trade was barber. Nell identified the damaged razor in his hand; Edith matched the license and address to his current work. The earlier victims supplied the false statements that destroyed his former life. Thorne was his final target.\"\n\nThe host may read Barker's final words: \"Once this town knew me as Benjamin Barker. I had a trade, a wife and a home. Thorne wanted what was not his, and four respectable voices made his lie sound like law. When I returned, I called myself Xander Hale and worked in wood. I thought a new name could bury the old one. Instead I carried it through every door. I chose revenge, and I killed them. It did not restore my wife's freedom or the years we lost. Nothing they did makes these murders right.\"\n\nBlackwater Row must now reckon with both the original injustice and the five deaths that followed."
    },
    "masterPreserving": true,
    "conversion": {
      "source": "Committed four-player Blackwater Row revision 3.",
      "changes": [
        {
          "original": "Five discovery chapters and four playable neighbors.",
          "replacement": "Five unchanged discovery sequences with two intervening comparison chapters and a three-player core.",
          "reason": "Seven-round requirement and smallest-edition master. Identity remains in the last discovery chapter; no murders or facts are added."
        },
        {
          "original": "Per-chapter four-player reader handoffs and twenty player responses.",
          "replacement": "Named recorded responses in shared narration and count-specific group order.",
          "reason": "Preserve every witness source and original response while selecting a three-player loop."
        },
        {
          "original": "Solution timing references to Round 4 and Round 5.",
          "replacement": "Corresponding seven-chapter references to Round 5 and Round 7.",
          "reason": "Inserted comparison rounds shift chapter numbers without advancing evidence."
        }
      ],
      "originalResponses": [
        {
          "id": "xander",
          "rounds": [
            {
              "readAloud": {
                "accuses": "marla",
                "text": "I heard Nell saw {marla} leave the bakery's back door at nine with her red-handled brush. Her repaired, flour-packed heel resembles those prints. I still need their timing checked.",
                "observation": "I heard Nell saw {marla} leave the bakery's back door at nine with her red-handled brush.",
                "contradictingDetail": "Her repaired, flour-packed heel resembles those prints. I still need their timing checked."
              }
            },
            {
              "readAloud": {
                "accuses": "jasper",
                "text": "I heard Ada saw {jasper}'s blue-strapped case on Ronan's counter at ten. His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors.",
                "observation": "I heard Ada saw {jasper}'s blue-strapped case on Ronan's counter at ten.",
                "contradictingDetail": "His amber rosin resembles that mug smear. I can't identify material by color, or rule out later visitors."
              }
            },
            {
              "readAloud": {
                "accuses": "lydia",
                "text": "I heard Owen saw {lydia}'s green folder in Harper's classroom at six, discussing pupil privacy. Its chalk matches the desk height. I worry about access, but Owen left at seven.",
                "observation": "I heard Owen saw {lydia}'s green folder in Harper's classroom at six, discussing pupil privacy.",
                "contradictingDetail": "Its chalk matches the desk height. I worry about access, but Owen left at seven."
              }
            },
            {
              "readAloud": {
                "accuses": "marla",
                "text": "I read {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market. I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone.",
                "observation": "I read {marla}'s nine-o'clock closing duty: scrub the rear threshold, then take waste to market.",
                "contradictingDetail": "I see why her heel left flour. Her reported argument near Tobias doesn't identify anyone."
              }
            },
            {
              "readAloud": {
                "accuses": "jasper",
                "text": "I heard {jasper}'s different-name rumor came from Ronan's old-license remark. His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin.",
                "observation": "I heard {jasper}'s different-name rumor came from Ronan's old-license remark.",
                "contradictingDetail": "His receipt confirms ten; a private visitor came at eleven. I can't blame him from a rumor or rosin."
              }
            }
          ]
        },
        {
          "id": "marla",
          "rounds": [
            {
              "readAloud": {
                "accuses": "jasper",
                "text": "I heard Finn saw {jasper} behind the bakery at nine-thirty with his blue-strapped case. A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave.",
                "observation": "I heard Finn saw {jasper} behind the bakery at nine-thirty with his blue-strapped case.",
                "contradictingDetail": "A flour sack marked it. I wonder about his promised parcel; Finn didn't see him leave."
              }
            },
            {
              "readAloud": {
                "accuses": "lydia",
                "text": "I heard Ada heard {lydia} warn Ronan about recording families at eight. She touched his book, leaving possible chalk. I can't prove a removed page or a later return.",
                "observation": "I heard Ada heard {lydia} warn Ronan about recording families at eight.",
                "contradictingDetail": "She touched his book, leaving possible chalk. I can't prove a removed page or a later return."
              }
            },
            {
              "readAloud": {
                "accuses": "xander",
                "text": "I heard Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair. Chalk explains his cuff mark to me, not missing pages or blade skills.",
                "observation": "I heard Harper said {xander} once worked with blades; Owen saw his narrow whetstone during her drawer repair.",
                "contradictingDetail": "Chalk explains his cuff mark to me, not missing pages or blade skills."
              }
            },
            {
              "readAloud": {
                "accuses": "jasper",
                "text": "I heard Della saw {jasper} follow Tobias to the market lamp at ten. He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward.",
                "observation": "I heard Della saw {jasper} follow Tobias to the market lamp at ten.",
                "contradictingDetail": "He held the flask; oil spilled on his right sleeve. I still don't know where either went afterward."
              }
            },
            {
              "readAloud": {
                "accuses": "lydia",
                "text": "I learned {lydia} saw Thorne hide receipt 47 during her confirmed school-funding appointment. She couldn't read the name. I see why she questioned family records, not proof she falsified them.",
                "observation": "I learned {lydia} saw Thorne hide receipt 47 during her confirmed school-funding appointment.",
                "contradictingDetail": "She couldn't read the name. I see why she questioned family records, not proof she falsified them."
              }
            }
          ]
        },
        {
          "id": "jasper",
          "rounds": [
            {
              "readAloud": {
                "accuses": "lydia",
                "text": "I heard Della saw {lydia} argue with Elias that morning, her green lesson folder tucked under her arm. A bread bill held family history. I wonder why he folded that paper.",
                "observation": "I heard Della saw {lydia} argue with Elias that morning, her green lesson folder tucked under her arm.",
                "contradictingDetail": "A bread bill held family history. I wonder why he folded that paper."
              }
            },
            {
              "readAloud": {
                "accuses": "xander",
                "text": "I read {xander}'s shelf invoice; Ada saw fine sharpening stones in his address-stamped sleeve. His repair cloth held amber shellac. I see another possible smear source, not proof he touched that mug.",
                "observation": "I read {xander}'s shelf invoice; Ada saw fine sharpening stones in his address-stamped sleeve.",
                "contradictingDetail": "His repair cloth held amber shellac. I see another possible smear source, not proof he touched that mug."
              }
            },
            {
              "readAloud": {
                "accuses": "marla",
                "text": "I read {marla}'s signed six-o'clock bread delivery to Harper's classroom door. Owen saw her wait by the open records drawer. I see access, but not a fatal-morning visit.",
                "observation": "I read {marla}'s signed six-o'clock bread delivery to Harper's classroom door.",
                "contradictingDetail": "Owen saw her wait by the open records drawer. I see access, but not a fatal-morning visit."
              }
            },
            {
              "readAloud": {
                "accuses": "lydia",
                "text": "I read {lydia}'s warning to Tobias: children's family affairs don't belong in street notes. Her weekly lesson meetings explain contact to me, not an overnight alibi or receipt 47's torn page.",
                "observation": "I read {lydia}'s warning to Tobias: children's family affairs don't belong in street notes.",
                "contradictingDetail": "Her weekly lesson meetings explain contact to me, not an overnight alibi or receipt 47's torn page."
              }
            },
            {
              "readAloud": {
                "accuses": "xander",
                "text": "I heard Edith match {xander}'s licensed likeness and workshop address: Benjamin Barker, barber. His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse.",
                "observation": "I heard Edith match {xander}'s licensed likeness and workshop address: Benjamin Barker, barber.",
                "contradictingDetail": "His chipped ivory razor matches both sightings. I see blade ownership and motive, but we still must accuse."
              }
            }
          ]
        },
        {
          "id": "lydia",
          "rounds": [
            {
              "readAloud": {
                "accuses": "xander",
                "text": "I heard Della saw Elias refuse to enter {xander}'s workshop over an old receipt. He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon.",
                "observation": "I heard Della saw Elias refuse to enter {xander}'s workshop over an old receipt.",
                "contradictingDetail": "He gripped the chair rail, asking which book. I see a troubling reaction, not proof or a weapon."
              }
            },
            {
              "readAloud": {
                "accuses": "marla",
                "text": "I heard Della heard {marla} dispute Ronan's flour bill at seven. She showed a receipt and left toward the bakery. I can't confirm payment or a later return.",
                "observation": "I heard Della heard {marla} dispute Ronan's flour bill at seven.",
                "contradictingDetail": "She showed a receipt and left toward the bakery. I can't confirm payment or a later return."
              }
            },
            {
              "readAloud": {
                "accuses": "jasper",
                "text": "I read {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak. I see how marks transfer, but Owen didn't watch the yard entrance overnight.",
                "observation": "I read {jasper}'s nine-o'clock fundraiser attendance; his blue-strapped case rubbed Harper's chalky desk over its flour streak.",
                "contradictingDetail": "I see how marks transfer, but Owen didn't watch the yard entrance overnight."
              }
            },
            {
              "readAloud": {
                "accuses": "xander",
                "text": "I heard Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge. It went into his stamped sleeve. I worry about those precise cuts, not a confession.",
                "observation": "I heard Nell saw {xander}'s straight razor: ivory handle, triangular chip beside its hinge.",
                "contradictingDetail": "It went into his stamped sleeve. I worry about those precise cuts, not a confession."
              }
            },
            {
              "readAloud": {
                "accuses": "marla",
                "text": "I heard Edith confirm {marla}'s childhood delivery during Thorne's old workshop-home visit. She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot.",
                "observation": "I heard Edith confirm {marla}'s childhood delivery during Thorne's old workshop-home visit.",
                "contradictingDetail": "She heard no conversation. I see a documented visit, not a false-statement signer or proof against her repaired boot."
              }
            }
          ]
        }
      ]
    }
  }
};
